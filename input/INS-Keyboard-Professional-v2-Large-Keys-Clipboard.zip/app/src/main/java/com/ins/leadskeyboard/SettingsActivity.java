package com.ins.leadskeyboard;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.provider.Settings;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
public class SettingsActivity extends Activity {
 EditText url; SharedPreferences prefs;
 @Override public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("ins_keyboard",MODE_PRIVATE);
  LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(28,36,28,28);
  TextView title=new TextView(this);title.setText("INS CUSTOM KEYBOARD");title.setTextSize(23);title.setTextColor(0xffb4232f);root.addView(title);
  TextView desc=new TextView(this);desc.setText("INS Lead Management HTTPS website URL එක ඇතුළත් කරන්න.");desc.setTextSize(16);root.addView(desc);
  url=new EditText(this);url.setSingleLine(true);url.setHint("https://your-ins-leads-site.com");url.setText(prefs.getString("app_url",""));root.addView(url);
  Button save=new Button(this);save.setText("Save Website URL");save.setOnClickListener(v->{String s=url.getText().toString().trim();if(!s.startsWith("https://")){url.setError("HTTPS URL එකක් ඇතුළත් කරන්න");return;}prefs.edit().putString("app_url",s).apply();Toast.makeText(this,"URL saved",Toast.LENGTH_SHORT).show();});root.addView(save);
  Button enable=new Button(this);enable.setText("1. Enable INS Keyboard");enable.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));root.addView(enable);
  Button choose=new Button(this);choose.setText("2. Select INS Keyboard");choose.setOnClickListener(v->((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showInputMethodPicker());root.addView(choose);
  TextView note=new TextView(this);note.setText("\nSetup: Save URL → Enable INS Keyboard → Select INS Keyboard. Open WhatsApp, copy the phone number, then tap INS LEADS.");root.addView(note);setContentView(root);
 }
}
