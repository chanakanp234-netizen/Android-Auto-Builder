package com.ins.leadskeyboard;

import android.inputmethodservice.InputMethodService;
import android.view.*;
import android.view.inputmethod.InputConnection;
import android.content.*;
import android.content.ClipboardManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.widget.*;
import android.text.TextUtils;
import org.json.JSONArray;
import java.util.ArrayList;

public class InsInputMethodService extends InputMethodService {
    private LinearLayout root;
    private boolean caps = false;
    private boolean clipboardScreen = false;
    private ClipboardManager clipboard;
    private ClipboardManager.OnPrimaryClipChangedListener clipListener;
    private final ArrayList<String> history = new ArrayList<>();
    private final int bg = Color.rgb(24, 26, 30);
    private final int keyBg = Color.rgb(48, 50, 55);
    private final int specialBg = Color.rgb(67, 71, 80);
    private final int accent = Color.rgb(190, 35, 55);
    private final int white = Color.rgb(248, 249, 251);
    private static final String PREFS = "ins_keyboard";
    private static final String CLIPS = "clipboard_history";
    private static final int MAX_CLIPS = 30;

    @Override public void onCreate() {
        super.onCreate();
        clipboard = (ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        loadHistory();
        clipListener = () -> captureClipboard();
        if (clipboard != null) clipboard.addPrimaryClipChangedListener(clipListener);
    }

    @Override public View onCreateInputView() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(5), dp(5), dp(5), dp(7));
        root.setBackgroundColor(bg);
        showKeyboard();
        return root;
    }

    @Override public void onStartInputView(android.view.inputmethod.EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        if (root != null) showKeyboard();
    }

    @Override public void onDestroy() {
        if (clipboard != null && clipListener != null) clipboard.removePrimaryClipChangedListener(clipListener);
        super.onDestroy();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), Color.argb(28,255,255,255));
        return d;
    }

    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER);
        return l;
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setIncludeFontPadding(true);
        return t;
    }

    private Button makeButton(String label, int color, int height, int size) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(white);
        b.setTextSize(size);
        b.setAllCaps(false);
        b.setTypeface(null, Typeface.NORMAL);
        b.setPadding(dp(2), 0, dp(2), 0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setBackground(shape(color, 9));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(height), 1);
        p.setMargins(dp(3), dp(3), dp(3), dp(3));
        b.setLayoutParams(p);
        return b;
    }

    private void showKeyboard() {
        if (root == null) return;
        clipboardScreen = false;
        root.removeAllViews();

        LinearLayout toolbar = horizontal();
        Button leads = makeButton("INS LEADS", accent, 43, 13);
        leads.setTypeface(null, Typeface.BOLD);
        leads.setOnClickListener(v -> openLeads());
        toolbar.addView(leads);

        Button clip = makeButton("▤  Clipboard", specialBg, 43, 12);
        clip.setOnClickListener(v -> showClipboard());
        toolbar.addView(clip);

        Button hide = makeButton("⌄", specialBg, 43, 18);
        hide.setLayoutParams(new LinearLayout.LayoutParams(dp(48), dp(43)));
        hide.setOnClickListener(v -> requestHideSelf(0));
        toolbar.addView(hide);
        root.addView(toolbar);

        LinearLayout suggestions = horizontal();
        String[] suggestionsText = {"☺", "GIF", "▤", "EN", "🎙", "⚙"};
        for (String s : suggestionsText) {
            Button b = makeButton(s, bg, 35, 14);
            b.setOnClickListener(v -> {
                if ("▤".equals(s)) showClipboard();
                else if ("⚙".equals(s)) openSettings();
                else if ("🎙".equals(s)) Toast.makeText(this, "Voice input depends on your phone's speech service.", Toast.LENGTH_SHORT).show();
            });
            suggestions.addView(b);
        }
        root.addView(suggestions);

        addKeyRow("1234567890", 57, false);
        addKeyRow("qwertyuiop", 57, false);
        addKeyRow("asdfghjkl", 57, false);

        LinearLayout r = horizontal();
        addSpecial(r, "⇧", 57, () -> { caps = !caps; showKeyboard(); });
        addLetters(r, "zxcvbnm", 57);
        addSpecial(r, "⌫", 57, () -> { InputConnection ic=getCurrentInputConnection(); if(ic!=null) ic.deleteSurroundingText(1,0); });
        root.addView(r);

        LinearLayout bottom = horizontal();
        addSpecial(bottom, "?123", 57, () -> Toast.makeText(this, "Symbols layout will be added in the next keyboard update.", Toast.LENGTH_SHORT).show());
        addSpecial(bottom, "☺", 57, () -> Toast.makeText(this, "Emoji are available from your phone's emoji panel.", Toast.LENGTH_SHORT).show());
        addSpecial(bottom, ",", 57, () -> commit(","));
        Button space = makeButton("English  •  Space", keyBg, 57, 14);
        space.setLayoutParams(new LinearLayout.LayoutParams(0, dp(57), 4));
        space.setOnClickListener(v -> commit(" "));
        bottom.addView(space);
        addSpecial(bottom, ".", 57, () -> commit("."));
        addSpecial(bottom, "↵", 57, () -> commit("\n"));
        root.addView(bottom);
    }

    private void addKeyRow(String keys, int height, boolean unused) {
        LinearLayout row = horizontal();
        for (char c : keys.toCharArray()) {
            final String key = String.valueOf(c);
            Button b = makeButton(key, keyBg, height, 21);
            b.setTypeface(null, Typeface.NORMAL);
            b.setOnClickListener(v -> commit(caps ? key.toUpperCase() : key));
            row.addView(b);
        }
        root.addView(row);
    }

    private void addLetters(LinearLayout row, String keys, int height) {
        for (char c : keys.toCharArray()) {
            final String key = String.valueOf(c);
            Button b = makeButton(key, keyBg, height, 21);
            b.setOnClickListener(v -> commit(caps ? key.toUpperCase() : key));
            row.addView(b);
        }
    }

    private void addSpecial(LinearLayout row, String label, int height, Runnable action) {
        Button b = makeButton(label, specialBg, height, label.length() > 1 ? 12 : 20);
        b.setOnClickListener(v -> action.run());
        row.addView(b);
    }

    private void commit(String value) {
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) ic.commitText(value, 1);
    }

    private void showClipboard() {
        if (root == null) return;
        clipboardScreen = true;
        captureClipboard();
        root.removeAllViews();

        LinearLayout header = horizontal();
        Button back = makeButton("← Keyboard", specialBg, 46, 13);
        back.setOnClickListener(v -> showKeyboard());
        header.addView(back);
        Button clear = makeButton("Clear all", accent, 46, 13);
        clear.setOnClickListener(v -> {
            history.clear();
            saveHistory();
            showClipboard();
        });
        header.addView(clear);
        root.addView(header);

        TextView title = text("CLIPBOARD HISTORY  •  " + history.size() + "/" + MAX_CLIPS, 13, white);
        title.setPadding(0, dp(5), 0, dp(5));
        root.addView(title);

        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        if (history.isEmpty()) {
            TextView empty = text("Copied text will appear here while INS Keyboard is open.", 14, Color.LTGRAY);
            empty.setPadding(dp(16), dp(22), dp(16), dp(22));
            list.addView(empty);
        } else {
            for (int i = history.size()-1; i >= 0; i--) {
                final int index = i;
                String value = history.get(i);
                LinearLayout item = new LinearLayout(this);
                item.setOrientation(LinearLayout.HORIZONTAL);
                item.setGravity(Gravity.CENTER_VERTICAL);
                item.setPadding(dp(8), dp(4), dp(4), dp(4));
                item.setBackground(shape(keyBg, 10));
                LinearLayout.LayoutParams itemParams = new LinearLayout.LayoutParams(-1, -2);
                itemParams.setMargins(dp(2), dp(3), dp(2), dp(3));
                item.setLayoutParams(itemParams);

                TextView content = text(value, 14, white);
                content.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
                content.setMaxLines(3);
                content.setEllipsize(TextUtils.TruncateAt.END);
                content.setPadding(dp(8), dp(7), dp(5), dp(7));
                item.addView(content, new LinearLayout.LayoutParams(0, -2, 1));

                Button paste = makeButton("Paste", accent, 42, 12);
                paste.setLayoutParams(new LinearLayout.LayoutParams(dp(66), dp(42)));
                paste.setOnClickListener(v -> { commit(value); });
                item.addView(paste);

                Button delete = makeButton("×", specialBg, 42, 20);
                delete.setLayoutParams(new LinearLayout.LayoutParams(dp(42), dp(42)));
                delete.setOnClickListener(v -> {
                    if (index >= 0 && index < history.size()) history.remove(index);
                    saveHistory();
                    showClipboard();
                });
                item.addView(delete);
                list.addView(item);
            }
        }
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
    }

    private void captureClipboard() {
        if (clipboard == null || !clipboard.hasPrimaryClip()) return;
        try {
            CharSequence text = clipboard.getPrimaryClip().getItemAt(0).coerceToText(this);
            if (text == null) return;
            String value = text.toString().trim();
            if (value.isEmpty()) return;
            if (!history.isEmpty() && history.get(history.size()-1).equals(value)) return;
            history.add(value);
            while (history.size() > MAX_CLIPS) history.remove(0);
            saveHistory();
            if (clipboardScreen) showClipboard();
        } catch (Exception ignored) { }
    }

    private void loadHistory() {
        history.clear();
        String raw = getSharedPreferences(PREFS, MODE_PRIVATE).getString(CLIPS, "[]");
        try {
            JSONArray a = new JSONArray(raw);
            for (int i=0; i<a.length(); i++) history.add(a.optString(i, ""));
        } catch (Exception ignored) { }
    }

    private void saveHistory() {
        JSONArray a = new JSONArray();
        for (String s : history) a.put(s);
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(CLIPS, a.toString()).apply();
    }

    private void openSettings() {
        try {
            Intent i = new Intent(this, SettingsActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception ignored) { }
    }

    private void openLeads() {
        String site = getSharedPreferences(PREFS, MODE_PRIVATE).getString("app_url", "");
        if (site.isEmpty()) {
            Toast.makeText(this, "පළමුව Keyboard App එකේ Website URL එක Save කරන්න", Toast.LENGTH_LONG).show();
            openSettings();
            return;
        }
        String phone = "";
        try {
            if (clipboard != null && clipboard.hasPrimaryClip() && clipboard.getPrimaryClip().getItemCount() > 0) {
                CharSequence c = clipboard.getPrimaryClip().getItemAt(0).coerceToText(this);
                if (c != null) phone = c.toString().replaceAll("[^0-9+]", "");
            }
        } catch (Exception ignored) { }
        try {
            Uri.Builder u = Uri.parse(site).buildUpon();
            if (!phone.isEmpty()) u.appendQueryParameter("phone", phone);
            u.appendQueryParameter("ins_keyboard", "1");
            Intent i = new Intent(Intent.ACTION_VIEW, u.build());
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "INS site එක විවෘත කළ නොහැක", Toast.LENGTH_SHORT).show();
        }
    }
}
