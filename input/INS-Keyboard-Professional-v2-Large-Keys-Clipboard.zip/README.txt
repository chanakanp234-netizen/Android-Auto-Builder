INS CUSTOM KEYBOARD - ANDROID AUTO BUILDER INPUT

This is a minimal native Android Gradle project for the xtobi/Android-Auto-Builder repository.
ZIP ROOT CONTENTS:
- settings.gradle
- build.gradle
- gradle.properties
- gradlew
- gradlew.bat
- gradle/wrapper/gradle-wrapper.properties
- app/...

HOW TO USE:
1. Upload this ZIP as a single file into your fork's input/ folder.
2. Commit the ZIP to the main branch.
3. The builder workflow should start automatically.
4. Open Actions and download the android-debug-apk artifact after a successful run.

Prototype scope:
- Android IME with a simple English keyboard and INS LEADS toolbar button.
- INS LEADS reads clipboard text locally, extracts digits/+ and opens configured HTTPS URL with ?phone=...&ins_keyboard=1.
- Enter the final website URL in SettingsActivity after installing.
- Sinhala typing/prediction is not implemented.
- WhatsApp reply text insertion and group-link management are not implemented yet.
- Clipboard reading behavior must be tested on real Android versions/devices.
- No Supabase credentials or secrets are bundled.

BUILD NOTE:
This ZIP uses a self-bootstrapping gradlew shell script. On GitHub Actions it downloads
Gradle 8.9 into the runner cache and invokes it, so gradle-wrapper.jar is not needed.
The repository workflow requires gradlew, gradle/wrapper/gradle-wrapper.properties,
settings.gradle and an app module.

V2 PROFESSIONAL UI UPDATE:
- Larger separated key buttons with dark theme and number row.
- INS Leads shortcut, Clipboard screen, saved clipboard history (up to 30 text clips).
- Tap a saved clipboard item to paste it; delete individual items or clear all.
- Clipboard capture occurs when Android notifies the keyboard that primary clipboard changed while the IME is active.
NOTE: Android clipboard privacy restrictions mean this is not a background clipboard monitor. It does not promise to capture every copy made while the keyboard is not active.
- Wijesekara Sinhala layout, predictive text, full emoji panel, themes/settings controls and advanced symbol pages are not yet implemented in this update.
