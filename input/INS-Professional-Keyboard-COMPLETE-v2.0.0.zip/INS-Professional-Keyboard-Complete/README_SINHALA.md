# INS Professional Keyboard – Complete Android Project

මෙය INS Keyboard සඳහා අලුතින් සකස් කළ Android Studio / Gradle source project එකකි.

## ඇතුළත් විශේෂාංග
- English QWERTY keyboard සහ වෙනම විශාල key buttons
- ඉහළ Number row එක
- Sinhala mode toggle සහ Wijesekara-inspired Sinhala key layers
- Shift, symbols, backspace, space, enter
- Clipboard history (උපරිම items 30ක්), tap කර paste කිරීම, long-press / ✕ මඟින් තනි item delete කිරීම, Clear All
- INS LEADS shortcut: Settings හි save කළ HTTPS URL එක විවෘත කර clipboard එකේ තිබෙන Sri Lankan mobile number එක `phone` query parameter එකක් ලෙස යැවීමට උත්සාහ කරයි
- Dark / Light theme සහ keyboard height settings
- Android navigation bar inset සඳහා bottom padding

## Build
1. Android Studio තුළ මෙම folder එක Open කරන්න.
2. Android Gradle Plugin 8.7.3 සහ Gradle 8.9, JDK 17 භාවිත කරන්න.
3. SDK Platform 35 install කර Gradle Sync කරන්න.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).

GitHub Actions Android Auto Builder එකට upload කරන විට project root එකේ `settings.gradle`, `build.gradle`, `gradlew`, `gradle/wrapper/gradle-wrapper.properties`, `app/` යන දේවල් තිබිය යුතුය. Builder workflow එක Gradle 8.9 distribution එක බාගත කරයි.

## App identity / upgrade
- applicationId: `com.ins.leadskeyboard` (පැරණි INS Keyboard package එකට සමානයි)
- versionCode: 3, versionName: 2.0.0
- පෙර APK එක වෙනත් debug signing key එකකින් install කර ඇත්නම් Android package conflict පෙන්විය හැක. එවිට පැරණි INS Keyboard uninstall කර මෙම APK එක install කරන්න. පසුව update කිරීම සඳහා එකම private signing key එක දිගටම භාවිත කළ යුතුය. Public GitHub repository එකකට keystore/password දාන්න එපා.

## වැදගත් සීමා
- Android IME එකකට වෙනත් apps වල clipboard එක පසුබිමේ සෑම විටම කියවීමට අවසර නැත. Clipboard history එක Keyboard එක visible/active විට ලැබෙන clipboard change events මත පදනම් වේ. Android version සහ app privacy restrictions අනුව event ලැබීම වෙනස් විය හැක.
- Sinhala mapping එක මෙහි initial Wijesekara-style implementation එකකි. SLS 1134 key-by-key conformance සහ Sinhala conjunct / vowel placement තවම native Sinhala keyboard engine එකකින් validate කර නැත. Release කිරීමට පෙර Sinhala typing test කළ යුතුය.
- Voice typing සඳහා Android device එකේ speech input provider එක අවශ්‍යය.
- මෙම ZIP එක source project එකකි; APK එකක් නොවේ. Build සහ physical-device tests තවම කළ යුතුය.
