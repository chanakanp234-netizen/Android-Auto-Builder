package com.ins.leadskeyboard;

import android.app.Service;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

public class LeadsBubbleService extends Service {
    private WindowManager wm;
    private View bubble;
    private WindowManager.LayoutParams params;
    private float downX, downY;
    private int startX, startY;
    private boolean moved;

    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "INS LEADS floating button සඳහා Display over other apps අවසරය ලබාදෙන්න", Toast.LENGTH_LONG).show();
            stopSelf(); return;
        }
        startPersistentNotification();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        TextView v = new TextView(this);
        v.setText("INS"); v.setTextColor(Color.WHITE); v.setTextSize(15); v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xff315fbd, 0xff6846a8});
        bg.setShape(GradientDrawable.OVAL); bg.setStroke(dp(2), 0x99ffffff);
        v.setBackground(bg); v.setElevation(dp(8));
        bubble = v;
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(dp(54), dp(54), type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = getSharedPreferences("ins_keyboard", MODE_PRIVATE).getInt("bubble_x", dp(12));
        params.y = getSharedPreferences("ins_keyboard", MODE_PRIVATE).getInt("bubble_y", dp(220));
        bubble.setOnTouchListener((view, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downX = event.getRawX(); downY = event.getRawY(); startX = params.x; startY = params.y; moved = false; return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = event.getRawX() - downX, dy = event.getRawY() - downY;
                    if (Math.abs(dx) > dp(4) || Math.abs(dy) > dp(4)) moved = true;
                    params.x = startX + (int) dx; params.y = startY + (int) dy;
                    try { wm.updateViewLayout(bubble, params); } catch (Exception ignored) {}
                    return true;
                case MotionEvent.ACTION_UP:
                    if (moved) getSharedPreferences("ins_keyboard", MODE_PRIVATE).edit().putInt("bubble_x", params.x).putInt("bubble_y", params.y).apply();
                    else openLeads();
                    return true;
            }
            return false;
        });
        try { wm.addView(bubble, params); } catch (Exception e) { stopSelf(); }
    }


    private void startPersistentNotification() {
        String channelId = "ins_leads_floating";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(channelId, "INS LEADS Floating Button", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Keeps the INS LEADS floating shortcut available over other apps");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, channelId) : new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.ic_menu_edit)
                .setContentTitle("INS LEADS is active")
                .setContentText("Floating button is available. Tap it to open student registration.")
                .setOngoing(true);
        startForeground(3510, builder.build());
    }

    private void openLeads() {
        String site = getSharedPreferences("ins_keyboard", MODE_PRIVATE).getString("app_url", "");
        if (TextUtils.isEmpty(site) || !site.startsWith("https://")) {
            Toast.makeText(this, "පළමුව INS Keyboard Settings තුළ Website URL එක Save කරන්න", Toast.LENGTH_LONG).show();
            Intent settings = new Intent(this, SettingsActivity.class); settings.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(settings); return;
        }
        Uri.Builder u = Uri.parse(site).buildUpon().appendQueryParameter("ins_keyboard", "1");
        try {
            android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0) {
                CharSequence c = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
                if (c != null) {
                    java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?:\\+?94|0)?\\s*7[0-9][\\s-]?[0-9]{3}[\\s-]?[0-9]{4}").matcher(c);
                    if (m.find()) u.appendQueryParameter("phone", m.group().replaceAll("[^0-9+]", ""));
                }
            }
        } catch (Exception ignored) {}
        try { Intent i = new Intent(Intent.ACTION_VIEW, u.build()); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); }
        catch (Exception e) { Toast.makeText(this, "INS Leads website එක විවෘත කළ නොහැක", Toast.LENGTH_SHORT).show(); }
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }
    @Override public void onDestroy() { if (wm != null && bubble != null) try { wm.removeView(bubble); } catch (Exception ignored) {} super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
}
