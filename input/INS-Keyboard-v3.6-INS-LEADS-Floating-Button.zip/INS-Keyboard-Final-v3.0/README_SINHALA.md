# INS Smart Keyboard v3.5.0

## UI and behavior updates
- Professional dark Gboard-style keyboard, based on the user's second screenshot.
- QWERTY rows, number row, toolbar and bottom controls retain the reference layout proportions.
- Keyboard height follows the reference-sized mobile layout; it is not hard-capped to half the screen.
- Larger shift, backspace, symbols and enter controls.
- ?123 opens the first symbols page; the 2/2 control opens the second symbols page; ABC returns to letters.
- Toolbar language control changes visibly between EN and සිං.
- Basic Roman-to-Sinhala composition; common words such as amma, api and mage are mapped explicitly.
- Clipboard history, paste, refresh, clear, text-edit menu, emoji, settings and INS LEADS shortcut retained.

## Build
Use the included `gradlew` bootstrap script with Android SDK configured. APK build and on-device IME validation are still required before release.

## INS LEADS Floating Button (AssistiveTouch style)
1. Install the app and open INS Keyboard Settings.
2. Save the INS Leads website URL (must begin with https://).
3. Tap `Enable INS LEADS Floating Button`.
4. Android will open the `Display over other apps` permission page. Allow INS Keyboard.
5. Return to INS Keyboard Settings and tap Enable again.
6. A small circular INS bubble appears above other apps. Drag it to move; tap it to open the configured INS Leads website. If a phone number is copied, the app attempts to pass it as the `phone` query parameter.
7. Use `Disable INS LEADS Floating Button` to remove it.

The floating shortcut runs as a foreground service with a persistent notification. It does not read screen contents or capture typed text. Android overlay permission is required and can be revoked at any time in system settings.

## Validation status
- Manifest XML parsed successfully.
- New Java source brace-balance and integration checks passed.
- Android APK build was attempted but could not run because Gradle distribution download was unavailable in this environment. Build and test on a real Android device before release.
