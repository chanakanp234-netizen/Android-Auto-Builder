# INS Professional Keyboard – Android Source Project

මෙය INS Keyboard හි වැඩිදියුණු කළ Android IME source project එකයි.

## ඇතුළත් දේ
- SwiftKey ආකාරයේ dark/light keyboard interface
- English QWERTY සහ Sinhala Wijesekara-based QWERTY mapping
- Shift layer, number row, symbols, emoji insert, clipboard paste
- Sinhala / English mode switch, quick-word strip
- Keyboard height settings (compact / standard / tall)
- INS Leads shortcut: clipboard එකේ තිබෙන Sri Lankan mobile number pattern එක සොයා configured HTTPS website එකට `phone` query parameter එකක් යවයි
- Keyboard settings screen එකෙන් INS site URL එක සුරැකීම

## Build
This project is designed for the GitHub Android Auto Builder repository. Upload this ZIP as one file inside `input/` and commit to `main`. The builder runs `./gradlew assembleDebug` and publishes the APK artifact.

## Sinhala mapping note
Key positions follow the publicly documented SLS 1134 / Wijesekara-based QWERTY mapping. Mobile IME uses a simplified touch layout: base and shift layers are available; advanced Ctrl+Alt layers, full conjunct editing, predictive Sinhala dictionary and autocorrect are not yet implemented. Pre-base vowel signs are buffered and placed after the following consonant in Unicode order.

## Privacy and limitations
- Keystrokes are not logged or transmitted.
- Clipboard is read only when the user taps INS Leads or Clipboard.
- INS Leads requires a configured HTTPS website URL and a compatible lead form that reads the `phone` query parameter.
- This source has not yet been built and tested on the user's phone. Build in GitHub Actions, install the resulting APK, then test Sinhala typing in WhatsApp, Messages and the INS website.
- Voice typing uses the Android keyboard/voice provider if available; this app does not record audio itself.
