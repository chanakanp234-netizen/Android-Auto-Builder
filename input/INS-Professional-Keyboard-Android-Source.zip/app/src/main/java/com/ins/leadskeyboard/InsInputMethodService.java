package com.ins.leadskeyboard;

import android.inputmethodservice.InputMethodService;
import android.view.*;
import android.view.inputmethod.*;
import android.content.*;
import android.content.ClipboardManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.widget.*;
import android.text.TextUtils;
import java.util.*;

public class InsInputMethodService extends InputMethodService {
    private LinearLayout root;
    private boolean sinhala=false, shifted=false, symbols=false;
    private String pendingMark="";
    private int bg, keyBg, keyFg, specialBg, accent;
    private final String[] EN1={"qwertyuiop","asdfghjkl","zxcvbnm"};
    // SLS 1134 / Wijesekara-based QWERTY mapping. Lower/upper states follow the standard key layers.
    private final String[][] SI={
      {"ු|ූ","අ|උ","ැ|ෑ","ර|ඍ","එ|ඔ","හ|ශ","ම|ඹ","ස|ෂ","ද|ධ","ච|ඡ"},
      {"්|ෟ","ි|ී","ා|ෘ","ෙ|ෆ","ට|ඨ","ය|්‍ය","ව|ළු","න|ණ","ක|ඛ"},
      {"ඤ|ඥ","ං|ඃ","ජ|ඦ","ඩ|ඬ","ඉ|ඊ","බ|භ","ප|ඵ"}
    };
    private final String[] SI_KEYS={"qwertyuiop","asdfghjkl","zxcvbnm"};
    private final String[] QUICK_SI={"මම","ඔබ","අපි"};
    private final String[] QUICK_EN={"the","you","and"};
    private int keyHeight=50;

    @Override public View onCreateInputView(){ buildKeyboard(); return root; }
    @Override public void onStartInputView(EditorInfo info, boolean restarting){super.onStartInputView(info,restarting);buildKeyboard();}
    private void colors(){boolean dark=getSharedPreferences("ins_keyboard",MODE_PRIVATE).getBoolean("dark",true); if(dark){bg=0xff17191d;keyBg=0xff292c31;keyFg=0xfff5f6f8;specialBg=0xff3a3e45;accent=0xffb4232f;}else{bg=0xffe9edf2;keyBg=Color.WHITE;keyFg=0xff202938;specialBg=0xffd5dce6;accent=0xffb4232f;} int h=getSharedPreferences("ins_keyboard",MODE_PRIVATE).getInt("height",1);keyHeight=h==0?44:(h==2?57:50);}
    private void buildKeyboard(){
        colors(); root=new LinearLayout(this);root.setOrientation(1);root.setPadding(4,4,4,5);root.setBackgroundColor(bg);
        LinearLayout tools=row(); addTool(tools,"▣",()->pasteClipboard());addTool(tools,"GIF",()->insert("😊"));addTool(tools,"▤",()->pasteClipboard());addTool(tools,sinhala?"සිං":"EN",()->{sinhala=!sinhala;symbols=false;pendingMark="";buildKeyboard();});addTool(tools,"🎙",()->Toast.makeText(this,"Voice typing is provided by Android if available",Toast.LENGTH_SHORT).show());addTool(tools,"⚙",()->openSettings());addTool(tools,"INS",()->openLeads());root.addView(tools);
        LinearLayout suggestions=row();String[] quick=sinhala?QUICK_SI:QUICK_EN;for(String w:quick){Button b=key(w,keyBg,keyFg,13);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,36,1);p.setMargins(2,1,2,2);suggestions.addView(b,p);b.setOnClickListener(v->insert(w+" "));}root.addView(suggestions);
        addNumberRow();
        if(symbols) buildSymbols(); else buildLetters();
        LinearLayout bottom=row(); addSpecial(bottom,"?123",54,()->{symbols=!symbols;pendingMark="";buildKeyboard();});addSpecial(bottom,"☺",42,()->insert("😊"));addSpecial(bottom,sinhala?"සිං":"EN",52,()->{sinhala=!sinhala;pendingMark="";buildKeyboard();});
        Button space=key("English / සිංහල",keyBg,keyFg,13);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,keyHeight,1);sp.setMargins(2,3,2,3);bottom.addView(space,sp);space.setOnClickListener(v->insert(" "));
        addSpecial(bottom,".,?",48,()->insert("."));addSpecial(bottom,"↵",54,()->{InputConnection ic=getCurrentInputConnection();if(ic!=null)ic.commitText("\n",1);});root.addView(bottom);
    }
    private void buildLetters(){
        for(int r=0;r<3;r++){
            LinearLayout line=row(); String letters=SI_KEYS[r];
            if(r==2) addSpecial(line,"⇧",48,()->{shifted=!shifted;buildKeyboard();});
            for(int i=0;i<letters.length();i++){
                final int rr=r,ii=i; String label;
                if(sinhala){String[] pair=SI[r][i].split("\\|");label=shifted?pair[1]:pair[0];}
                else label=String.valueOf(letters.charAt(i));
                Button b=key(label,keyBg,keyFg,sinhala?17:19);
                LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,keyHeight,1);p.setMargins(2,3,2,3);line.addView(b,p);
                b.setOnClickListener(v->{if(sinhala){String[] pair=SI[rr][ii].split("\\|");handleSinhala(pair[shifted?1:0]);}else{String value=String.valueOf(letters.charAt(ii));insert(shifted?value.toUpperCase(Locale.ROOT):value);}if(shifted){shifted=false;buildKeyboard();}});
            }
            if(r==2) addSpecial(line,"⌫",58,()->backspace());
            root.addView(line);
        }
    }
    private void buildSymbols(){String[][] rows={{"1","2","3","4","5","6","7","8","9","0"},{"@","#","$","%","&","-","+","(",")","/"},{"*","\"","'",":",";","!","?",",",".","="}};for(String[] rr:rows){LinearLayout l=row();for(String s:rr){Button b=key(s,keyBg,keyFg,18);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,keyHeight,1);p.setMargins(2,3,2,3);l.addView(b,p);b.setOnClickListener(v->insert(s));}root.addView(l);}LinearLayout l=row();addSpecial(l,"ABC",70,()->{symbols=false;buildKeyboard();});addSpecial(l,"⌫",58,()->backspace());root.addView(l);}
    private void addNumberRow(){LinearLayout l=row();for(String n:new String[]{"1","2","3","4","5","6","7","8","9","0"}){Button b=key(n,specialBg,keyFg,16);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,34,1);p.setMargins(2,1,2,2);l.addView(b,p);b.setOnClickListener(v->insert(n));}root.addView(l);}
    private void handleSinhala(String s){
        // Pre-base dependent vowel signs are held until the next base consonant, then committed in Unicode order.
        if(s.equals("ැ")||s.equals("ෑ")||s.equals("ෙ")){pendingMark=s;return;}
        if(s.equals("්‍ය")){insert("්\u200dය");return;}
        if(s.equals("ළු")){insert("ළු");return;}
        if(!pendingMark.isEmpty()){String mark=pendingMark;pendingMark="";insert(s+mark);return;}
        insert(s);
    }
    private void insert(String s){InputConnection ic=getCurrentInputConnection();if(ic!=null)ic.commitText(s,1);}
    private void backspace(){InputConnection ic=getCurrentInputConnection();if(ic==null)return;if(!pendingMark.isEmpty()){pendingMark="";return;}ic.deleteSurroundingText(1,0);}
    private void pasteClipboard(){try{ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);if(cm!=null&&cm.hasPrimaryClip()&&cm.getPrimaryClip().getItemCount()>0){CharSequence t=cm.getPrimaryClip().getItemAt(0).coerceToText(this);if(t!=null)insert(t.toString());}}catch(Exception e){Toast.makeText(this,"Clipboard unavailable",Toast.LENGTH_SHORT).show();}}
    private void openLeads(){String site=getSharedPreferences("ins_keyboard",MODE_PRIVATE).getString("app_url","");if(TextUtils.isEmpty(site)){Toast.makeText(this,"Settings තුළ Website URL එක Save කරන්න",Toast.LENGTH_LONG).show();openSettings();return;}String phone="";try{ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);if(cm!=null&&cm.hasPrimaryClip()&&cm.getPrimaryClip().getItemCount()>0){CharSequence c=cm.getPrimaryClip().getItemAt(0).coerceToText(this);if(c!=null){String raw=c.toString();java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?:\\+?94|0)?\\s*7[0-9][\\s-]?[0-9]{3}[\\s-]?[0-9]{4}").matcher(raw);if(m.find())phone=m.group().replaceAll("[^0-9+]","");}}}catch(Exception ignored){}try{Uri.Builder u=Uri.parse(site).buildUpon();if(!phone.isEmpty())u.appendQueryParameter("phone",phone);u.appendQueryParameter("ins_keyboard","1");Intent i=new Intent(Intent.ACTION_VIEW,u.build());i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);}catch(Exception e){Toast.makeText(this,"INS website could not open",Toast.LENGTH_SHORT).show();}}
    private void openSettings(){Intent i=new Intent(this,SettingsActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER);return l;}
    private Button key(String text,int color,int fg,int size){Button b=new Button(this);b.setText(text);b.setTextColor(fg);b.setTextSize(size);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);b.setPadding(0,0,0,0);b.setMinWidth(0);b.setMinimumWidth(0);b.setMinHeight(0);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));return b;}
    private void addTool(LinearLayout row,String label,Runnable action){Button b=key(label,specialBg,keyFg,label.length()>3?11:17);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,40,1);p.setMargins(2,1,2,3);row.addView(b,p);b.setOnClickListener(v->action.run());}
    private void addSpecial(LinearLayout row,String label,int width,Runnable action){Button b=key(label,specialBg,keyFg,15);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(width,keyHeight);p.setMargins(2,3,2,3);row.addView(b,p);b.setOnClickListener(v->action.run());}
}
