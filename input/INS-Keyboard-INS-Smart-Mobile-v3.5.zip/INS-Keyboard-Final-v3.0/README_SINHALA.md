# INS Smart Keyboard v3.5.0

## UI and behavior updates
- Professional dark Gboard-style keyboard, based on the user's second screenshot.
- QWERTY rows, number row, toolbar and bottom controls retain the reference layout proportions.
- Keyboard height follows the reference-sized mobile layout; it is not hard-capped to half the screen.
- Larger shift, backspace, symbols and enter controls.
- ?123 opens the first symbols page; the 2/2 control opens the second symbols page; ABC returns to letters.
- Toolbar language control changes visibly between EN and සිං.
- Basic Roman-to-Sinhala composition; common words such as amma, api and mage are mapped explicitly.
- Clipboard history, paste, refresh, clear, text-edit menu, emoji, settings and INS LEADS shortcut retained.

## Build
Use the included `gradlew` bootstrap script with Android SDK configured. APK build and on-device IME validation are still required before release.
