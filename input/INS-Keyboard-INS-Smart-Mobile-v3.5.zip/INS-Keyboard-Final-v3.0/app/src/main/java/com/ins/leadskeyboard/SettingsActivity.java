package com.ins.leadskeyboard;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class SettingsActivity extends Activity {
    private SharedPreferences prefs;
    private EditText url;
    private final int red=Color.rgb(195,34,58);
    @Override public void onCreate(Bundle state){
        super.onCreate(state);prefs=getSharedPreferences("ins_keyboard",MODE_PRIVATE);
        LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(24,28,24,24);page.setBackgroundColor(0xff101217);
        TextView title=new TextView(this);title.setText("INS SMART KEYBOARD");title.setTextSize(23);title.setTextColor(0xff7daeff);title.setTypeface(null,1);page.addView(title);
        TextView sub=new TextView(this);sub.setText("Professional dark keys  •  Sinhala  •  English  •  Clipboard");sub.setTextSize(14);sub.setTextColor(0xffb8bfce);sub.setPadding(0,6,0,22);page.addView(sub);
        addLabel(page,"INS Lead Management Website URL");url=new EditText(this);url.setSingleLine(true);url.setHint("https://your-ins-leads-site.com");url.setText(prefs.getString("app_url",""));page.addView(url);
        Button save=action("Save Website URL");save.setOnClickListener(v->{String s=url.getText().toString().trim();if(!s.startsWith("https://")){url.setError("HTTPS URL එකක් ඇතුළත් කරන්න");return;}prefs.edit().putString("app_url",s).apply();Toast.makeText(this,"Website URL saved",Toast.LENGTH_SHORT).show();});page.addView(save);
        addLabel(page,"Keyboard design");TextView design=new TextView(this);design.setText("Smart dark theme  •  Gboard-style layout  •  Larger touch buttons");design.setTextSize(14);design.setTextColor(0xfff5f6fa);design.setPadding(14,14,14,14);design.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff292c34));design.setBackgroundColor(0xff292c34);page.addView(design);
        addLabel(page,"Keyboard height  •  Compact / Standard / Tall");SeekBar height=new SeekBar(this);height.setMax(2);height.setProgress(prefs.getInt("height",2));height.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean user){if(user)prefs.edit().putInt("height",p).apply();}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});page.addView(height);
        Button enable=action("1. Enable INS Keyboard");enable.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));page.addView(enable);
        Button select=action("2. Select INS Keyboard");select.setOnClickListener(v->((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showInputMethodPicker());page.addView(select);
        TextView privacy=new TextView(this);privacy.setText("Privacy: INS Keyboard does not transmit typed text. Clipboard history is stored locally on this phone and can be deleted from Clipboard.");privacy.setTextSize(12);privacy.setTextColor(0xffaab2c2);privacy.setPadding(0,20,0,0);page.addView(privacy);
        setContentView(page);
    }
    private void addLabel(LinearLayout p,String s){TextView t=new TextView(this);t.setText(s);t.setTextSize(15);t.setTextColor(0xffe9edf5);t.setPadding(0,18,0,5);p.addView(t);}
    private Button action(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff315f9e));return b;}
}
