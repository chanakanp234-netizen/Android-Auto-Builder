package com.ins.leadskeyboard;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.inputmethodservice.InputMethodService;
import android.net.Uri;
import android.os.Build;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import java.util.ArrayList;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class InsInputMethodService extends InputMethodService {
    private LinearLayout root;
    private boolean sinhala=false, shifted=false, symbols=false, clipboardPage=false;
    private String pendingMark="";
    private String romanBuffer="";
    private int bg,keyBg,keyFg,specialBg,accent,keyHeight;
    private ClipboardManager clipboard;
    private ClipboardManager.OnPrimaryClipChangedListener clipListener;
    private final String[] rows={"qwertyuiop","asdfghjkl","zxcvbnm"};
    // Wijesekara-inspired Sinhala key layers. Users can switch language from the toolbar.
    private final String[][] si={
        {"ු|ූ","අ|උ","ැ|ෑ","ර|ඍ","එ|ඔ","හ|ශ","ම|ඹ","ස|ෂ","ද|ධ","ච|ඡ"},
        {"්|ෟ","ි|ී","ා|ෘ","ෙ|ෆ","ට|ඨ","ය|්‍ය","ව|ළු","න|ණ","ක|ඛ"},
        {"ඤ|ඥ","ං|ඃ","ජ|ඦ","ඩ|ඬ","ඉ|ඊ","බ|භ","ප|ඵ"}
    };

    @Override public void onCreate() {
        super.onCreate();
        clipboard=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        clipListener=()->captureClipboard();
    }
    @Override public View onCreateInputView(){ buildKeyboard(); return root; }
    @Override public void onStartInputView(EditorInfo info, boolean restarting){
        super.onStartInputView(info,restarting);
        if(clipboard!=null) clipboard.addPrimaryClipChangedListener(clipListener);
        buildKeyboard();
    }
    @Override public void onFinishInputView(boolean finishingInput){
        if(clipboard!=null && clipListener!=null) clipboard.removePrimaryClipChangedListener(clipListener);
        super.onFinishInputView(finishingInput);
    }

    private void colors(){
        // Smart dark professional theme, following the user's Gboard-style reference.
        bg=0xff090b10;
        keyBg=0xff24262c;
        keyFg=0xfff5f6fa;
        specialBg=0xff343740;
        accent=0xff3978d6;
        int screenDp=(int)(getResources().getDisplayMetrics().heightPixels / getResources().getDisplayMetrics().density);
        // Match the reference keyboard's natural height; do not force a 50% cap.
        keyHeight=Math.max(48,Math.min(62,(screenDp-310)/3));
    }
    private void buildKeyboard(){
        colors();
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(4),dp(4),dp(4),dp(5));
        int screenH=getResources().getDisplayMetrics().heightPixels;
        int desiredHeight=Math.min(dp(470),Math.max(dp(370),(int)(screenH*0.39f)));
        root.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, desiredHeight));
        root.setBackgroundColor(0xff090b10);
        if(Build.VERSION.SDK_INT>=20){
            root.setOnApplyWindowInsetsListener((v,insets)->{
                int bottom=0;
                if(Build.VERSION.SDK_INT>=30) bottom=insets.getInsets(WindowInsets.Type.navigationBars()).bottom;
                else if(Build.VERSION.SDK_INT>=20) bottom=insets.getSystemWindowInsetBottom();
                v.setPadding(5,5,5,Math.max(8,bottom)); return insets;
            });
        }
        if(clipboardPage){ captureClipboard(); buildClipboardPage(); return; }
        // One compact toolbar preserves vertical room for larger, easier-to-touch letter keys.
        LinearLayout top=row();
        addWide(top,"INS LEADS",0xffd83c70,()->openLeads(),1.22f);
        addWide(top,"▤ Clipboard",0xff454a58,()->{captureClipboard();clipboardPage=true;buildKeyboard();},0.92f);
        addWide(top,sinhala?"සිං":"EN",0xff287e80,()->toggleLanguage(),0.58f);
        addWide(top,"☺",0xff454a58,()->insert("😊"),0.48f);
        addWide(top,"Aa",0xff454a58,()->showTextEditMenu(top),0.48f);
        addWide(top,"⚙",0xff454a58,()->openSettings(),0.48f);
        root.addView(top,lp(-1,dp(48)));
        addNumberRow();
        if(symbols) buildSymbols(); else buildLetters();
        LinearLayout bottom=row(); addSpecial(bottom,symbols?"ABC":"?123",66,()->{symbols=!symbols;shifted=false;buildKeyboard();}); addSpecial(bottom,"🌐",48,()->toggleLanguage());
        Button space=key(sinhala?"සිං  •  Space":"English  •  Space",0xff3a3d46,keyFg,13); bottom.addView(space,weight(1,Math.max(50,keyHeight-8),2)); space.setOnClickListener(v->{if(sinhala)commitSinhalaWord();insert(" ");});
        addSpecial(bottom,",.?",54,()->{insert(",");}); addSpecial(bottom,"↵",58,()->sendEnter()); root.addView(bottom,lp(-1,dp(keyHeight+8)));
    }
    private void showTextEditMenu(View anchor){
        PopupMenu menu=new PopupMenu(this,anchor);
        menu.getMenu().add("Select all").setOnMenuItemClickListener(item->{InputConnection ic=getCurrentInputConnection();if(ic!=null)ic.performContextMenuAction(android.R.id.selectAll);return true;});
        menu.getMenu().add("Copy").setOnMenuItemClickListener(item->{InputConnection ic=getCurrentInputConnection();if(ic!=null)ic.performContextMenuAction(android.R.id.copy);return true;});
        menu.getMenu().add("Cut").setOnMenuItemClickListener(item->{InputConnection ic=getCurrentInputConnection();if(ic!=null)ic.performContextMenuAction(android.R.id.cut);return true;});
        menu.getMenu().add("Paste").setOnMenuItemClickListener(item->{pasteClipboard();return true;});
        menu.show();
    }
    private void pasteClipboard(){
        try{if(clipboard!=null&&clipboard.hasPrimaryClip()){ClipData clip=clipboard.getPrimaryClip();if(clip!=null&&clip.getItemCount()>0){CharSequence text=clip.getItemAt(0).coerceToText(this);if(text!=null)insert(text.toString());}}}catch(Exception e){Toast.makeText(this,"Clipboard paste unavailable",Toast.LENGTH_SHORT).show();}
    }
    private void buildClipboardPage(){
        LinearLayout head=row(); addWide(head,"← Back",0xff3b3f49,()->{clipboardPage=false;buildKeyboard();},1); addWide(head,"⟳ Refresh",0xff287e80,()->{captureClipboard();buildKeyboard();},1); addWide(head,"Clear All",0xffa93250,()->{saveHistory(new JSONArray());buildKeyboard();},1); root.addView(head,lp(-1,52));
        TextView title=new TextView(this);title.setText("Clipboard history  •  up to 30 items\nTap to paste  •  Long-press to delete");title.setTextColor(keyFg);title.setTextSize(14);title.setPadding(10,12,10,12);root.addView(title);
        ScrollView scroll=new ScrollView(this); LinearLayout list=new LinearLayout(this);list.setOrientation(1);
        JSONArray data=loadHistory();
        for(int i=0;i<data.length();i++){
            final String item=data.optString(i,""); if(item.isEmpty())continue;
            LinearLayout line=row(); TextView txt=new TextView(this);txt.setText(item);txt.setTextColor(keyFg);txt.setTextSize(15);txt.setMaxLines(3);txt.setPadding(12,12,8,12);txt.setBackgroundTintList(ColorStateList.valueOf(0xff292c34));txt.setBackgroundColor(0xff292c34);line.addView(txt,weight(1,-2,1));
            Button del=key("✕",specialBg,keyFg,18);line.addView(del,lp(54,54));del.setOnClickListener(v->{removeHistory(item);buildKeyboard();});
            txt.setOnClickListener(v->{insert(item);clipboardPage=false;buildKeyboard();}); txt.setOnLongClickListener(v->{removeHistory(item);buildKeyboard();return true;});
            LinearLayout.LayoutParams p=lp(-1,-2);p.setMargins(2,3,2,3);list.addView(line,p);
        }
        if(data.length()==0){TextView empty=new TextView(this);empty.setText("No copied messages yet. Copy text while INS Keyboard is open.");empty.setTextColor(keyFg);empty.setPadding(16,24,16,24);list.addView(empty);}
        scroll.addView(list);scroll.setBackgroundColor(0xff111319);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
    }
    private void buildLetters(){
        for(int r=0;r<3;r++){
            LinearLayout line=row(); String letters=rows[r];
            if(r==2)addSpecial(line,"⇧",76,()->{shifted=!shifted;buildKeyboard();});
            for(int i=0;i<letters.length();i++){
                final int rr=r,ii=i; String label;
                if(sinhala){label=String.valueOf(letters.charAt(i)); label=shifted?label.toUpperCase(Locale.ROOT):label;}
                else {String c=String.valueOf(letters.charAt(i));label=shifted?c.toUpperCase(Locale.ROOT):c;}
                Button b=key(label,keyBg,keyFg,sinhala?19:22);line.addView(b,weight(1,dp(keyHeight+3),2));
                b.setOnClickListener(v->{{String c=String.valueOf(letters.charAt(ii)); if(sinhala) typeRoman(c); else insert(shifted?c.toUpperCase(Locale.ROOT):c);}if(shifted){shifted=false;buildKeyboard();}});
            }
            if(r==2)addSpecial(line,"⌫",58,()->backspace());
            root.addView(line,lp(-1,dp(keyHeight+7)));
        }
    }
    private void buildSymbols(){
        String[][] first={{"1","2","3","4","5","6","7","8","9","0"},{"@","#","$","%","&","-","+","(",")","/"},{"*","\"","'",":",";","!","?",",",".","="}};
        String[][] second={{"~","`","|","•","√","π","÷","×","¶","∆"},{"£","¢","€","¥","^","°","=","{","}","\\"},{"%","©","®","™","✓","[","]","<",">","?"}};
        String[][] data=shifted?second:first;
        for(String[] rr:data){LinearLayout line=row();for(String value:rr){final String symbol=value;Button b=key(symbol,0xff292c34,keyFg,21);line.addView(b,weight(1,dp(keyHeight+5),2));b.setOnClickListener(v->insert(symbol));}root.addView(line,lp(-1,dp(keyHeight+9)));}
        LinearLayout line=row();addSpecial(line,"ABC",66,()->{symbols=false;shifted=false;buildKeyboard();});addSpecial(line,shifted?"1/2":"2/2",56,()->{shifted=!shifted;buildKeyboard();});addSpecial(line,"⌫",62,()->backspace());root.addView(line,lp(-1,dp(keyHeight+9)));
    }
    private void toggleLanguage(){
        if(sinhala && !romanBuffer.isEmpty()) commitSinhalaWord();
        sinhala=!sinhala; pendingMark=""; romanBuffer=""; shifted=false; buildKeyboard();
    }
    private void addNumberRow(){LinearLayout line=row();for(String n:new String[]{"1","2","3","4","5","6","7","8","9","0"}){Button b=key(n,0xff292c34,keyFg,20);line.addView(b,weight(1,dp(48),2));b.setOnClickListener(v->insert(n));}root.addView(line,lp(-1,dp(52)));}
    private void typeRoman(String c){
        InputConnection ic=getCurrentInputConnection(); if(ic==null)return;
        romanBuffer += c.toLowerCase(Locale.ROOT);
        ic.setComposingText(romanToSinhala(romanBuffer),1);
    }
    private void commitSinhalaWord(){
        InputConnection ic=getCurrentInputConnection(); if(ic!=null && !romanBuffer.isEmpty()) ic.commitText(romanToSinhala(romanBuffer),1);
        romanBuffer="";
    }
    private String romanToSinhala(String input){
        // Syllable-aware practical transliteration. Common Sinhala words are handled explicitly first.
        String lower=input.toLowerCase(Locale.ROOT);
        String[][] common={{"amma","අම්මා"},{"thaththa","තාත්තා"},{"ayya","අයියා"},{"akka","අක්කා"},{"nangi","නංගි"},{"malli","මල්ලි"},{"api","අපි"},{"oya","ඔයා"},{"mage","මගේ"},{"mata","මට"},{"hari","හරි"},{"kohomada","කොහොමද"},{"istuthi","ස්තුතියි"},{"suba","සුබ"},{"gedara","ගෙදර"},{"lamai","ළමයි"},{"karanna","කරන්න"},{"puluwan","පුළුවන්"},{"onna","ඔන්න"},{"dan","දැන්"}};
        for(String[] pair:common) if(lower.equals(pair[0])) return pair[1];
        // Longest digraphs first, then consonant/vowel rules.
        String[][] digraphs={
            {"kh","ඛ"},{"gh","ඝ"},{"ch","ච"},{"sh","ශ"},{"th","ථ"},{"dh","ධ"},{"ph","ඵ"},{"bh","භ"},
            {"ng","ං"},{"ny","ඤ"},{"aa","ා"},{"ii","ී"},{"uu","ූ"},{"ee","ේ"},{"oo","ෝ"},
            {"ṭh","ඨ"},{"ḍh","ඪ"},{"ll","ල්ල"},{"nn","න්න"}
        };
        StringBuilder out=new StringBuilder(); int i=0; boolean afterConsonant=false;
        while(i<input.length()){
            String hit=null,val=null;
            for(String[] pair:digraphs){if(input.startsWith(pair[0],i)){hit=pair[0];val=pair[1];break;}}
            if(hit!=null){
                if(val.matches("[ාීූේෝ]")){out.append(val);afterConsonant=false;}
                else {out.append(val);afterConsonant=true;}
                i+=hit.length(); continue;
            }
            char ch=input.charAt(i++);
            String vowel=null;
            switch(ch){case 'a':vowel="අ";break;case 'i':vowel="ඉ";break;case 'u':vowel="උ";break;case 'e':vowel="එ";break;case 'o':vowel="ඔ";break;}
            if(vowel!=null){
                if(afterConsonant){String sign=ch=='a'?"":ch=='i'?"ි":ch=='u'?"ු":ch=='e'?"ෙ":"ො";out.append(sign);}
                else out.append(vowel);
                afterConsonant=false; continue;
            }
            String cons=null;
            switch(ch){
                case 'k':cons="ක";break;case 'g':cons="ග";break;case 'c':cons="ච";break;case 'j':cons="ජ";break;
                case 't':cons="ත";break;case 'd':cons="ද";break;case 'n':cons="න";break;case 'p':cons="ප";break;
                case 'b':cons="බ";break;case 'm':cons="ම";break;case 'y':cons="ය";break;case 'r':cons="ර";break;
                case 'l':cons="ල";break;case 'v':case 'w':cons="ව";break;case 's':cons="ස";break;case 'h':cons="හ";break;
                case 'f':cons="ෆ";break;case 'q':cons="ක";break;case 'x':cons="ක්ස්";break;
            }
            if(cons!=null){
                if(afterConsonant) out.append("්");
                out.append(cons); afterConsonant=true;
            } else if(Character.isWhitespace(ch) || ".,!?;:()[]{}-_/\\'\"".indexOf(ch)>=0){
                out.append(ch); afterConsonant=false;
            } else { out.append(ch); afterConsonant=false; }
        }
        return out.toString();
    }
    private void insert(String s){InputConnection ic=getCurrentInputConnection();if(ic!=null){if(sinhala && !romanBuffer.isEmpty())commitSinhalaWord();ic.commitText(s,1);}}
    private void backspace(){InputConnection ic=getCurrentInputConnection();if(ic==null)return;if(sinhala && !romanBuffer.isEmpty()){romanBuffer=romanBuffer.substring(0,romanBuffer.length()-1);if(romanBuffer.isEmpty())ic.finishComposingText();else ic.setComposingText(romanToSinhala(romanBuffer),1);return;}if(!pendingMark.isEmpty()){pendingMark="";return;}CharSequence selected=ic.getSelectedText(0);if(!TextUtils.isEmpty(selected))ic.commitText("",1);else ic.deleteSurroundingText(1,0);}
    private void sendEnter(){InputConnection ic=getCurrentInputConnection();if(ic==null)return;if(sinhala)commitSinhalaWord();int action=getCurrentInputEditorInfo()!=null?getCurrentInputEditorInfo().imeOptions&EditorInfo.IME_MASK_ACTION:EditorInfo.IME_ACTION_NONE;if(action!=EditorInfo.IME_ACTION_NONE&&action!=EditorInfo.IME_ACTION_UNSPECIFIED)ic.performEditorAction(action);else ic.commitText("\n",1);}
    private void captureClipboard(){
        try{if(clipboard==null||!clipboard.hasPrimaryClip())return;ClipData clip=clipboard.getPrimaryClip();if(clip==null||clip.getItemCount()==0)return;CharSequence cs=clip.getItemAt(0).coerceToText(this);if(cs==null)return;String text=cs.toString().trim();if(text.isEmpty())return;JSONArray old=loadHistory();ArrayList<String> items=new ArrayList<>();items.add(text);for(int i=0;i<old.length()&&items.size()<30;i++){String s=old.optString(i,"");if(!s.equals(text)&&!s.isEmpty())items.add(s);}JSONArray out=new JSONArray();for(String s:items)out.put(s);saveHistory(out);}catch(Exception ignored){}
    }
    private JSONArray loadHistory(){try{return new JSONArray(getSharedPreferences("ins_keyboard",MODE_PRIVATE).getString("clipboard_history","[]"));}catch(Exception e){return new JSONArray();}}
    private void saveHistory(JSONArray a){getSharedPreferences("ins_keyboard",MODE_PRIVATE).edit().putString("clipboard_history",a.toString()).apply();}
    private void removeHistory(String item){JSONArray old=loadHistory(),out=new JSONArray();for(int i=0;i<old.length();i++){String s=old.optString(i,"");if(!s.equals(item))out.put(s);}saveHistory(out);}
    private void openLeads(){String site=getSharedPreferences("ins_keyboard",MODE_PRIVATE).getString("app_url","");if(TextUtils.isEmpty(site)){Toast.makeText(this,"Settings තුළ Website URL එක Save කරන්න",Toast.LENGTH_LONG).show();openSettings();return;}String phone="";try{if(clipboard!=null&&clipboard.hasPrimaryClip()){CharSequence c=clipboard.getPrimaryClip().getItemAt(0).coerceToText(this);if(c!=null){Matcher m=Pattern.compile("(?:\\+?94|0)?\\s*7[0-9][\\s-]?[0-9]{3}[\\s-]?[0-9]{4}").matcher(c.toString());if(m.find())phone=m.group().replaceAll("[^0-9+]","");}}}catch(Exception ignored){}try{Uri.Builder u=Uri.parse(site).buildUpon();if(!phone.isEmpty())u.appendQueryParameter("phone",phone);u.appendQueryParameter("ins_keyboard","1");Intent i=new Intent(Intent.ACTION_VIEW,u.build());i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);}catch(Exception e){Toast.makeText(this,"INS website could not open",Toast.LENGTH_SHORT).show();}}
    private void openSettings(){Intent i=new Intent(this,SettingsActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER);return l;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private LinearLayout.LayoutParams weight(float w,int h,int margin){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,h,w);p.setMargins(margin+1,4,margin+1,4);return p;}
    private int[] keyPalette={0xff292c34,0xff292c34,0xff292c34,0xff292c34,0xff292c34,0xff292c34};
    private int letterColor(int row,int col){return 0xff292c34;}
    private int numberColor(int n){return 0xff292c34;}
    private String keySymbolLabel(String s){return s;}
    private Button key(String text,int color,int fg,int size){
        Button b=new Button(this); b.setText(text); b.setTextColor(fg); b.setTextSize(size);
        b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);
        b.setPadding(1,0,1,0); b.setMinWidth(0); b.setMinimumWidth(0); b.setMinHeight(0); b.setMinimumHeight(0);
        GradientDrawable shape=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{color,color});
        shape.setCornerRadius(dp(7));
        shape.setStroke(dp(1),0xff3c404b);
        b.setBackground(shape); b.setElevation(dp(1));
        return b;
    }
    private int lighten(int color){
        int r=Color.red(color),g=Color.green(color),b=Color.blue(color);
        return Color.rgb((r+255)/2,(g+255)/2,(b+255)/2);
    }
    private int blend(int a,int b,float ratio){
        return Color.rgb((int)(Color.red(a)*(1-ratio)+Color.red(b)*ratio),
            (int)(Color.green(a)*(1-ratio)+Color.green(b)*ratio),
            (int)(Color.blue(a)*(1-ratio)+Color.blue(b)*ratio));
    }
    private int dp(float value){return (int)(value*getResources().getDisplayMetrics().density+0.5f);}
    private void addTool(LinearLayout line,String label,Runnable action){Button b=key(label,specialBg,keyFg,16);line.addView(b,weight(1,40,2));b.setOnClickListener(v->action.run());}
    private void addSpecial(LinearLayout line,String label,int width,Runnable action){Button b=key(label,0xff3b3f49,keyFg,20);line.addView(b,lp(dp(width),dp(keyHeight+4)));b.setOnClickListener(v->action.run());}
    private void addWide(LinearLayout line,String label,int color,Runnable action,float weight){Button b=key(label,color,Color.WHITE,label.equals("INS LEADS")?14:13);line.addView(b,new LinearLayout.LayoutParams(0,-1,weight));b.setOnClickListener(v->action.run());LinearLayout.LayoutParams p=(LinearLayout.LayoutParams)b.getLayoutParams();p.setMargins(3,2,3,2);b.setLayoutParams(p);}
}
