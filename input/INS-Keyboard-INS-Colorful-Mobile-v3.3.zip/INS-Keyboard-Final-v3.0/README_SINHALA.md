# INS Colorful Mobile Keyboard v3.3.0

## මෙම සංස්කරණයේ වෙනස්කම්
- Mobile display එකේ ආසන්න වශයෙන් අඩක් පමණ keyboard එකට වෙන් කර ඇත.
- Screen height අනුව key sizes ස්වයංක්‍රීයව ගැළපේ.
- ?123, Shift, Backspace, Enter සහ punctuation buttons පෙරට වඩා විශාල කර ඇත.
- Space bar එකේ පළල අඩු කර අමතර control buttons සඳහා ඉඩ ලබා දී ඇත.
- Sinhala mode එකේ QWERTY English letters type කළ විට මූලික phonetic Sinhala conversion එක ලබා දෙයි.
- Clipboard view විවෘත කරන විට දැනට තිබෙන clipboard content එකත් history එකට ලබාගැනීමට උත්සාහ කරයි.
- INS LEADS website shortcut සහ settings flow තබා ඇත.

## Sinhala phonetic typing
Sinhala mode (toolbar හි EN/සිං button) තෝරාගෙන English letters වලින් type කරන්න. උදාහරණයක් ලෙස `amma`, `api`, `mage` වැනි අකුරු අනුපිළිවෙළක් Sinhala අකුරු බවට පරිවර්තනය වේ. මෙය මූලික transliteration එකක් වන අතර සියලුම Sinhala වචන සඳහා ශබ්දකෝෂ-මට්ටමේ නිවැරදි කිරීමක් නොවේ.

## Build
Android Studio හෝ ඔබේ GitHub Actions Android build workflow එකෙන් project එක build කරන්න.
