package com.ins.leadskeyboard;
import android.inputmethodservice.InputMethodService;
import android.view.*;
import android.view.inputmethod.*;
import android.content.*;
import android.content.ClipboardManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.widget.*;
import android.net.Uri;
public class InsInputMethodService extends InputMethodService {
 LinearLayout root; boolean caps=true; int red=0xffb4232f;
 @Override public View onCreateInputView(){
  root=new LinearLayout(this);root.setOrientation(1);root.setPadding(4,5,4,5);root.setBackgroundColor(0xffe9edf2);
  LinearLayout toolbar=row();Button ins=button("INS LEADS",red,Color.WHITE);ins.setTextSize(14);ins.setTypeface(null,Typeface.BOLD);ins.setOnClickListener(v->openLeads());toolbar.addView(ins,new LinearLayout.LayoutParams(0,48,1));
  Button hide=button("⌄",0xffd8dee8,0xff202938);hide.setOnClickListener(v->requestHideSelf(0));toolbar.addView(hide,new LinearLayout.LayoutParams(52,48));root.addView(toolbar);
  addKeys("qwertyuiop");addKeys("asdfghjkl");
  LinearLayout third=row();addKey(third,"⇧",52,0xffd5dce6);for(char c:"zxcvbnm".toCharArray())addKey(third,String.valueOf(c),0,Color.WHITE);addKey(third,"⌫",52,0xffd5dce6);root.addView(third);
  LinearLayout bottom=row();addKey(bottom,"?123",58,0xffd5dce6);addKey(bottom,",",38,Color.WHITE);addKey(bottom,"English",0,Color.WHITE);addKey(bottom,".",38,Color.WHITE);addKey(bottom,"↵",52,0xffd5dce6);root.addView(bottom);return root;
 }
 LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER);return l;}
 Button button(String s,int bg,int fg){Button b=new Button(this);b.setText(s);b.setTextColor(fg);b.setTextSize(18);b.setAllCaps(false);b.setPadding(0,0,0,0);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(bg));return b;}
 void addKeys(String line){LinearLayout r=row();for(char c:line.toCharArray())addKey(r,String.valueOf(c),0,Color.WHITE);root.addView(r);}
 void addKey(LinearLayout r,String label,int width,int bg){Button b=button(label,bg==0?Color.WHITE:bg,0xff202938);b.setTextSize(label.length()>1?13:19);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(width==0?0:width,47,width==0?1:0);p.setMargins(2,3,2,3);r.addView(b,p);
  b.setOnClickListener(v->{InputConnection ic=getCurrentInputConnection();if(ic==null)return;switch(label){case "⌫":ic.deleteSurroundingText(1,0);break;case "↵":ic.commitText("\n",1);break;case "⇧":caps=!caps;b.setText(caps?"⇧":"⇩");break;case "English":case "?123":break;default:ic.commitText(caps?label.toUpperCase():label,1);}});
 }
 void openLeads(){String site=getSharedPreferences("ins_keyboard",MODE_PRIVATE).getString("app_url","");if(site.isEmpty()){Toast.makeText(this,"පළමුව Keyboard App එකේ Website URL එක Save කරන්න",Toast.LENGTH_LONG).show();return;}
  String phone="";try{ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);if(cm!=null&&cm.hasPrimaryClip()&&cm.getPrimaryClip().getItemCount()>0){CharSequence c=cm.getPrimaryClip().getItemAt(0).coerceToText(this);if(c!=null)phone=c.toString().replaceAll("[^0-9+]","");}}catch(Exception ignored){}
  try{Uri.Builder u=Uri.parse(site).buildUpon().clearQuery();if(!phone.isEmpty())u.appendQueryParameter("phone",phone);u.appendQueryParameter("ins_keyboard","1");Intent i=new Intent(Intent.ACTION_VIEW,u.build());i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);}catch(Exception e){Toast.makeText(this,"INS site එක විවෘත කළ නොහැක",Toast.LENGTH_SHORT).show();}
 }
}
