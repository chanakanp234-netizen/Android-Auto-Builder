package com.firas.wamessagearchive.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "archived_messages", indices = [Index("timestamp"), Index("sender")])
data class ArchivedMessage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val notificationKey: String,
    val sender: String,
    val conversation: String?,
    val content: String,
    val mediaType: String,
    val isDeletedEvent: Boolean = false,
    val relatedMessageId: Long? = null,
    val timestamp: Long
)
