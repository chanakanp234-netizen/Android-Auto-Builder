package com.firas.wamessagearchive.ui

import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.firas.wamessagearchive.data.AppDatabase
import com.firas.wamessagearchive.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.DateFormat
import java.util.Date

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private var collectJob: Job? = null
    private val dao by lazy { AppDatabase.get(this).messages() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        val adapter = MessageAdapter()
        b.recycler.layoutManager = LinearLayoutManager(this)
        b.recycler.adapter = adapter
        b.btnPermission.setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        b.btnExport.setOnClickListener { exportArchive() }
        b.btnClear.setOnClickListener {
            androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Clear archive?")
                .setMessage("This permanently deletes all locally archived records.")
                .setNegativeButton("Cancel", null).setPositiveButton("Clear") { _, _ ->
                    lifecycleScope.launch(Dispatchers.IO) { dao.clear() }
                }.show()
        }
        b.search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { observe(s?.toString().orEmpty(), adapter) }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        observe("", adapter)
    }

    override fun onResume() { super.onResume(); updateStatus() }

    private fun updateStatus() {
        val cn = ComponentName(this, com.firas.wamessagearchive.service.WaNotificationListenerService::class.java)
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")?.contains(cn.flattenToString()) == true
        b.status.text = if (enabled) "ARCHIVING ACTIVE · LOCAL ONLY" else "SETUP REQUIRED · ENABLE NOTIFICATION ACCESS"
    }

    private fun observe(query: String, adapter: MessageAdapter) {
        collectJob?.cancel()
        collectJob = lifecycleScope.launch {
            (if (query.isBlank()) dao.observeAll() else dao.search(query)).collectLatest { adapter.submitList(it) }
        }
    }

    private fun exportArchive() {
        lifecycleScope.launch(Dispatchers.IO) {
            val rows = dao.snapshot()
            val array = JSONArray()
            rows.forEach { m -> array.put(JSONObject().apply {
                put("sender", m.sender); put("conversation", m.conversation ?: ""); put("content", m.content)
                put("mediaType", m.mediaType); put("deleted", m.isDeletedEvent)
                put("relatedMessageId", m.relatedMessageId ?: JSONObject.NULL)
                put("timestamp", DateFormat.getDateTimeInstance().format(Date(m.timestamp)))
            }) }
            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, "WA_Archive_${System.currentTimeMillis()}.json")
                put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/json")
                put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS + "/WA_Message_Archive")
            }
            val uri: Uri? = contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            if (uri != null) contentResolver.openOutputStream(uri)?.use { it.write(array.toString(2).toByteArray()) }
            withContext(Dispatchers.Main) { Toast.makeText(this@MainActivity, if (uri != null) "Export saved in Downloads/WA_Message_Archive" else "Export failed", Toast.LENGTH_LONG).show() }
        }
    }
}
