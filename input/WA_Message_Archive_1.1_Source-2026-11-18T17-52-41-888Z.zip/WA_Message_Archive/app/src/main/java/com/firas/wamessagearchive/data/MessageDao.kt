package com.firas.wamessagearchive.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MessageDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(message: ArchivedMessage): Long

    @Query("SELECT * FROM archived_messages ORDER BY timestamp DESC")
    fun observeAll(): Flow<List<ArchivedMessage>>

    @Query("SELECT * FROM archived_messages WHERE sender LIKE '%' || :q || '%' OR content LIKE '%' || :q || '%' OR conversation LIKE '%' || :q || '%' ORDER BY timestamp DESC")
    fun search(q: String): Flow<List<ArchivedMessage>>

    @Query("SELECT * FROM archived_messages WHERE id = :id LIMIT 1")
    suspend fun byId(id: Long): ArchivedMessage?

    @Query("SELECT * FROM archived_messages WHERE sender = :sender AND isDeletedEvent = 0 AND timestamp BETWEEN :from AND :to ORDER BY timestamp DESC LIMIT 1")
    suspend fun latestCandidate(sender: String, from: Long, to: Long): ArchivedMessage?

    @Query("UPDATE archived_messages SET isDeletedEvent = 1 WHERE id = :id")
    suspend fun markDeleted(id: Long)

    @Query("SELECT * FROM archived_messages ORDER BY timestamp DESC")
    suspend fun snapshot(): List<ArchivedMessage>

    @Query("DELETE FROM archived_messages WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM archived_messages")
    suspend fun clear()
}
