package com.firas.wamessagearchive.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.firas.wamessagearchive.R
import com.firas.wamessagearchive.data.ArchivedMessage
import java.text.DateFormat
import java.util.Date

class MessageAdapter : ListAdapter<ArchivedMessage, MessageAdapter.Holder>(Diff) {
    class Holder(v: View) : RecyclerView.ViewHolder(v) {
        val sender: TextView = v.findViewById(R.id.sender)
        val body: TextView = v.findViewById(R.id.body)
        val meta: TextView = v.findViewById(R.id.meta)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_message, parent, false))
    override fun onBindViewHolder(h: Holder, position: Int) {
        val m = getItem(position)
        h.sender.text = m.conversation?.let { "${m.sender} · $it" } ?: m.sender
        h.body.text = m.content
        val deleted = if (m.isDeletedEvent) " · DELETED" else ""
        h.meta.text = "${m.mediaType}$deleted · ${DateFormat.getDateTimeInstance().format(Date(m.timestamp))}"
    }
    companion object {
        val Diff = object : DiffUtil.ItemCallback<ArchivedMessage>() {
            override fun areItemsTheSame(a: ArchivedMessage, b: ArchivedMessage) = a.id == b.id
            override fun areContentsTheSame(a: ArchivedMessage, b: ArchivedMessage) = a == b
        }
    }
}
