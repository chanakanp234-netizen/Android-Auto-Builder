package com.firas.wamessagearchive.service

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.firas.wamessagearchive.data.AppDatabase
import com.firas.wamessagearchive.data.ArchivedMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class WaNotificationListenerService : NotificationListenerService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != "com.whatsapp") return
        val n = sbn.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString()?.trim().orEmpty()
        if (title.isBlank() || text.isBlank() || title.equals("WhatsApp", true)) return

        val conversation = extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString()
        val sender = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val deleted = isDeletedNotice(text)
        val type = classify(text)
        val dao = AppDatabase.get(applicationContext).messages()

        scope.launch {
            if (deleted) {
                // Best-effort correlation only: WhatsApp may omit the original sender or notification.
                val candidate = dao.latestCandidate(sender, sbn.postTime - 24 * 60 * 60 * 1000L, sbn.postTime)
                dao.insert(ArchivedMessage(
                    notificationKey = sbn.key + "_deleted_" + sbn.postTime,
                    sender = sender,
                    conversation = conversation,
                    content = text,
                    mediaType = "DELETED_NOTICE",
                    isDeletedEvent = true,
                    relatedMessageId = candidate?.id,
                    timestamp = sbn.postTime
                ))
                candidate?.let { dao.markDeleted(it.id) }
            } else {
                val msg = ArchivedMessage(
                    notificationKey = sbn.key + "_" + sbn.postTime,
                    sender = sender,
                    conversation = conversation,
                    content = text,
                    mediaType = type,
                    timestamp = sbn.postTime
                )
                dao.insert(msg)
            }
        }
    }

    private fun isDeletedNotice(value: String): Boolean {
        val s = value.lowercase()
        return s.contains("this message was deleted") || s.contains("تم حذف هذه الرسالة") || s.contains("supprimé ce message")
    }

    private fun classify(value: String): String {
        val s = value.lowercase()
        return when {
            s.contains("view once") || s.contains("عرض مرة واحدة") || s.contains("une seule fois") -> "VIEW_ONCE_NOTICE"
            s.contains("photo") || s == "📷" || s.contains("صورة") -> "PHOTO_NOTICE"
            s.contains("video") || s == "🎥" || s.contains("فيديو") -> "VIDEO_NOTICE"
            s.contains("voice message") || s.contains("رسالة صوتية") -> "AUDIO_NOTICE"
            else -> "TEXT"
        }
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
