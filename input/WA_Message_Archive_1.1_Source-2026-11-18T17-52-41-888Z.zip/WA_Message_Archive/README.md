# WA Message Archive 1.1

Android Studio project for Infinix Smart 8 (X6525), Android 13, no root.

## Features
- Locally archives WhatsApp notification text exposed by Android's NotificationListenerService.
- Keeps captured notification content after the notification is dismissed or the chat message is deleted.
- Records deletion notices and attempts a best-effort correlation with a recent message from the same displayed sender.
- Search, local Room database, JSON export, system DayNight theme (dark mode follows Android setting).
- No INTERNET permission and no cloud upload code.

## Important limitations
- This does not recover messages that never appeared in notifications (e.g. chat open, muted/hidden previews, offline delivery).
- WhatsApp notification formats vary by version, language, privacy setting, and group layout. Deletion correlation is best-effort, not guaranteed.
- View Once image/video bytes are not accessible through NotificationListenerService or ordinary shared storage. This project only archives a View Once notification notice if WhatsApp exposes one.
- Standard WhatsApp media folder is not copied in this build. Automatic media copying from SAF needs reliable per-item matching and should not be represented as guaranteed.

## Build
1. Open this folder in Android Studio (Giraffe or newer).
2. Use JDK 17 and allow Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install `app/build/outputs/apk/debug/app-debug.apk`.
5. Open Android Settings > Apps > WA Message Archive > three-dot menu > Allow restricted settings (if shown).
6. Open app > Enable Notification Access > enable WA Archive Notification Access.
7. On Infinix XOS, set battery use to Unrestricted / Don't optimize if the service is being stopped.

## Privacy
The manifest deliberately contains no INTERNET permission. Notification access is powerful: only enable it for this app if you trust the locally installed build. Archived content is sensitive; protect the phone and export files accordingly.
