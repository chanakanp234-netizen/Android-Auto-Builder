# INS Keyboard Professional 3.0 – Android source project

මෙය Android phone එකේ default keyboard ලෙස තෝරාගත හැකි INS Keyboard project එකයි.

## ඇතුළත් පහසුකම්
- Flashboard ආකාරයේ විශාල, වෙන්වූ box keys සහ වැඩි touch spacing
- English QWERTY සහ Sinhala Wijesekara-inspired layout
- වෙනම number row, Shift, Backspace, Symbols, Space සහ Enter
- INS LEADS shortcut: Settings තුළ දෙන Website URL එක විවෘත කර clipboard එකේ තිබෙන Sri Lankan mobile number එක `phone` query parameter එකක් ලෙස යවයි
- Clipboard history: items 30ක් දක්වා, tap කර paste කිරීම, තනි item delete කිරීම සහ Clear All
- Dark / Light theme සහ Compact / Standard / Tall keyboard height settings (default: Tall)
- Android navigation bar සඳහා bottom inset padding

## APK එක හදන පහසුම ක්‍රමය (GitHub Actions)
1. මෙම ZIP එක extract නොකරම භාවිත කරන්න.
2. GitHub හි `chanakanp234-netizen/Android-Auto-Builder` repository එකේ `input` folder එක open කරන්න.
3. Add file → Upload files තෝරා මෙම ZIP එක upload කර Commit changes කරන්න.
4. GitHub Actions → Build Android APK workflow එකේ අලුත් run එක open කරන්න.
4. සාර්ථක run එක open කර Artifacts යටතේ `android-debug-apk` download කරන්න.
5. ZIP එක extract කර `app-debug.apk` phone එකට යවා install කරන්න.

## Phone එකේ enable කිරීම
1. INS Keyboard Professional app එක open කරන්න.
2. `Enable INS Keyboard` තෝරා Settings තුළ INS Keyboard Professional enable කරන්න.
3. නැවත app එකට පැමිණ `Select INS Keyboard` තෝරා INS Keyboard Professional තෝරන්න.
4. Settings තුළ INS Leads Management Website URL එක save කරන්න.

## පැරණි APK එක සමඟ ගැටුම
මෙම version එකට අලුත් application ID එකක් (`com.ins.keyboard.professional`) භාවිත කර ඇත. ඒ නිසා කලින් test APK එකේ package/signature conflict එක මඟහැර වෙනම install කළ හැක.

## සීමා / පරීක්ෂා කළ යුතු දේ
- මෙය source ZIP එකකි; දැනට APK binary එකක් නොවේ. GitHub Actions build එක සාර්ථක වීමෙන් පසුව APK එක ලබාගත හැක.
- Sinhala layout එක Wijesekara-inspired initial mapping එකකි. සම්පූර්ණ SLS 1134 key mapping, සියලුම පිලි/සංයුක්ත අකුරු සහ predictive Sinhala typing තවම validate කර නැත.
- Android privacy සීමා නිසා clipboard history එක keyboard එක active/visible විට clipboard change event ලැබෙන අවස්ථාවල පමණක් update විය හැක.
- INS Leads website එකේ `phone` query parameter එක කියවා form එකට ඇතුළත් කිරීම website පැත්තෙන්ද සකස් කළ යුතුය.
- Typed text කිසිදු server එකකට යවන්නේ නැත. Clipboard history phone එකේ local preferences තුළ ගබඩා වේ.
