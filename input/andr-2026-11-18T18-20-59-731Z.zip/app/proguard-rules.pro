# ProGuard rules for WA Message Archive Pro
-keep class com.firas.waarchive.database.** { *; }
-keep class com.firas.waarchive.models.** { *; }
