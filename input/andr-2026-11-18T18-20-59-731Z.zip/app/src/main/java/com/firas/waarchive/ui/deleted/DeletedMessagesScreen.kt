package com.firas.waarchive.ui.deleted

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.firas.waarchive.models.DeletionEventUi
import com.firas.waarchive.models.DeletionMatchConfidence
import com.firas.waarchive.ui.components.EmptyArchiveState
import com.firas.waarchive.ui.components.LimitationInfoBanner
import com.firas.waarchive.ui.components.StatusTag
import com.firas.waarchive.ui.components.formatTimestamp
import com.firas.waarchive.ui.theme.AmberWarning
import com.firas.waarchive.ui.theme.CrimsonDeleted
import com.firas.waarchive.ui.theme.EmeraldPrimary

@Composable
fun DeletedMessagesScreen(
    deletionEvents: List<DeletionEventUi>,
    onDeleteEvent: (Long) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            LimitationInfoBanner(
                title = "Explicit Deletion Detection",
                body = "Deletion events are recorded only when WhatsApp exposes a deletion notice (e.g., \"This message was deleted\"). Dismissing a notification is never treated as deletion."
            )
        }

        if (deletionEvents.isEmpty()) {
            item {
                EmptyArchiveState(
                    icon = Icons.Rounded.DeleteSweep,
                    title = "No Deletion Events Recorded",
                    subtitle = "When WhatsApp replaces or posts a \"This message was deleted\" notification, it is logged here and paired with any previously archived original message."
                )
            }
        } else {
            items(deletionEvents, key = { it.id }) { event ->
                DeletionEventCard(
                    event = event,
                    onDelete = { onDeleteEvent(event.id) }
                )
            }
        }
    }
}

@Composable
private fun DeletionEventCard(
    event: DeletionEventUi,
    onDelete: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, CrimsonDeleted.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = event.senderName,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Chat: ${event.conversationName} · ${formatTimestamp(event.detectedAt)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Rounded.DeleteOutline,
                        contentDescription = "Delete record",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatusTag(label = "DELETED MESSAGE", color = CrimsonDeleted)
                val (confLabel, confColor) = when (event.matchConfidence) {
                    DeletionMatchConfidence.HIGH -> "MATCH: HIGH" to EmeraldPrimary
                    DeletionMatchConfidence.MEDIUM -> "MATCH: MEDIUM" to AmberWarning
                    DeletionMatchConfidence.UNMATCHED -> "NO PRIOR CAPTURE" to AmberWarning
                }
                StatusTag(label = confLabel, color = confColor)
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (!event.matchedOriginalText.isNullOrBlank()) {
                Text(
                    text = "Original Archived Message",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = EmeraldPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = event.matchedOriginalText,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
            } else {
                Text(
                    text = "No matching prior message notification was captured for this deletion notice (the chat may have been open or previews disabled when it arrived).",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Rounded.DeleteSweep,
                    contentDescription = null,
                    tint = CrimsonDeleted,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Notice: \"${event.noticeText}\"",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
