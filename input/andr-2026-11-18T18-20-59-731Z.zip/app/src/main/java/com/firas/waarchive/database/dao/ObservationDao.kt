package com.firas.waarchive.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.firas.waarchive.database.entity.NotificationObservationEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ObservationDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIgnore(observation: NotificationObservationEntity): Long

    @Query("SELECT COUNT(*) FROM notification_observations")
    fun observeCount(): Flow<Int>

    @Query("SELECT * FROM notification_observations ORDER BY observedAt DESC LIMIT 100")
    suspend fun getRecentObservations(): List<NotificationObservationEntity>

    @Query("DELETE FROM notification_observations")
    suspend fun clearAll()
}
