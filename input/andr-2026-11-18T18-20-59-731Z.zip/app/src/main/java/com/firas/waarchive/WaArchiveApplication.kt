package com.firas.waarchive

import android.app.Application
import com.firas.waarchive.archive.ArchiveProcessor
import com.firas.waarchive.database.WaArchiveDatabase
import com.firas.waarchive.notifications.ListenerStatusTracker
import com.firas.waarchive.repository.ArchiveRepository
import com.firas.waarchive.security.KeystoreCryptoManager
import com.firas.waarchive.storage.SafMediaArchiver

class WaArchiveApplication : Application() {

    lateinit var cryptoManager: KeystoreCryptoManager
        private set

    lateinit var database: WaArchiveDatabase
        private set

    lateinit var listenerStatusTracker: ListenerStatusTracker
        private set

    lateinit var archiveProcessor: ArchiveProcessor
        private set

    lateinit var repository: ArchiveRepository
        private set

    override fun onCreate() {
        super.onCreate()
        cryptoManager = KeystoreCryptoManager()
        database = WaArchiveDatabase.getInstance(this)
        listenerStatusTracker = ListenerStatusTracker(this)
        archiveProcessor = ArchiveProcessor(
            database = database,
            crypto = cryptoManager,
            statusTracker = listenerStatusTracker
        )
        val safMediaArchiver = SafMediaArchiver(
            context = this,
            database = database,
            crypto = cryptoManager
        )
        repository = ArchiveRepository(
            context = this,
            database = database,
            crypto = cryptoManager,
            statusTracker = listenerStatusTracker,
            safMediaArchiver = safMediaArchiver
        )
    }
}
