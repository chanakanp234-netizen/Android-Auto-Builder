package com.firas.waarchive.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.firas.waarchive.database.entity.DeletionEventEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface DeletionEventDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIgnore(event: DeletionEventEntity): Long

    @Query("SELECT * FROM deletion_events ORDER BY detectedAt DESC, id DESC")
    fun observeAll(): Flow<List<DeletionEventEntity>>

    @Query("SELECT * FROM deletion_events ORDER BY detectedAt DESC, id DESC")
    suspend fun getAllSnapshot(): List<DeletionEventEntity>

    @Query("SELECT COUNT(*) FROM deletion_events")
    fun observeCount(): Flow<Int>

    @Query("DELETE FROM deletion_events WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM deletion_events")
    suspend fun clearAll()
}
