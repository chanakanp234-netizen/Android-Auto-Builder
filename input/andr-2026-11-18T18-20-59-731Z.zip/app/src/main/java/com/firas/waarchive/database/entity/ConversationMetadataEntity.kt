package com.firas.waarchive.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "conversations",
    indices = [
        Index(value = ["lastMessageAt"])
    ]
)
data class ConversationMetadataEntity(
    @PrimaryKey
    val conversationKey: String,
    val encryptedDisplayName: String,
    val isGroup: Boolean,
    val messageCount: Int,
    val lastMessageAt: Long,
    val deletedCount: Int,
    val viewOnceCount: Int
)
