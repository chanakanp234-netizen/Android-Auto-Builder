package com.firas.waarchive.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "notification_observations",
    indices = [
        Index(value = ["observationHash"], unique = true),
        Index(value = ["notificationKey"]),
        Index(value = ["observedAt"])
    ]
)
data class NotificationObservationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val observationHash: String,
    val notificationKey: String,
    val notificationId: Int,
    val eventType: String,
    val postTime: Long,
    val observedAt: Long,
    val entryCount: Int,
    val isMessagingStyle: Boolean,
    val isSummaryNotification: Boolean,
    val encryptedExtrasSnapshot: String
)
