package com.firas.waarchive.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.firas.waarchive.models.MediaType

@Entity(
    tableName = "normal_media",
    indices = [
        Index(value = ["contentHash"], unique = true),
        Index(value = ["mediaType"]),
        Index(value = ["archivedAt"])
    ]
)
data class NormalMediaEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val contentHash: String,
    val originalFileName: String,
    val sourceDocumentUri: String,
    val privateFilePath: String,
    val mediaType: MediaType,
    val mimeType: String,
    val fileSizeBytes: Long,
    val encryptedSenderAssociation: String?,
    val fileLastModified: Long,
    val archivedAt: Long
)
