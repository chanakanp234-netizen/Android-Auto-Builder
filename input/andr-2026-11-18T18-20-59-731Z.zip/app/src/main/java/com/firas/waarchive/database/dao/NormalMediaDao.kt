package com.firas.waarchive.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.firas.waarchive.database.entity.NormalMediaEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface NormalMediaDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIgnore(media: NormalMediaEntity): Long

    @Query("SELECT EXISTS(SELECT 1 FROM normal_media WHERE contentHash = :hash)")
    suspend fun existsByHash(hash: String): Boolean

    @Query("SELECT * FROM normal_media ORDER BY fileLastModified DESC, id DESC")
    fun observeAll(): Flow<List<NormalMediaEntity>>

    @Query("SELECT * FROM normal_media ORDER BY fileLastModified DESC, id DESC")
    suspend fun getAllSnapshot(): List<NormalMediaEntity>

    @Query("SELECT * FROM normal_media WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): NormalMediaEntity?

    @Query("SELECT COUNT(*) FROM normal_media")
    fun observeCount(): Flow<Int>

    @Query("DELETE FROM normal_media WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM normal_media")
    suspend fun clearAll()
}
