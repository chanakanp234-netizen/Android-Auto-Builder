package com.firas.waarchive.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.firas.waarchive.models.MessageCategory

@Entity(
    tableName = "archived_messages",
    indices = [
        Index(value = ["dedupHash"], unique = true),
        Index(value = ["notificationKey"]),
        Index(value = ["conversationKey"]),
        Index(value = ["notificationTimestamp"]),
        Index(value = ["isDeleted"])
    ]
)
data class ArchivedMessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val dedupHash: String,
    val notificationKey: String,
    val notificationId: Int,
    val conversationKey: String,
    val encryptedNotificationTitle: String,
    val encryptedSenderName: String,
    val encryptedConversationName: String,
    val isGroupChat: Boolean,
    val encryptedMessageText: String,
    val encryptedBigText: String?,
    val category: MessageCategory,
    val notificationTimestamp: Long,
    val archivedAt: Long,
    val isDeleted: Boolean = false,
    val linkedDeletionEventId: Long? = null,
    val deletionDetectedAt: Long? = null,
    val sourcePackage: String = "com.whatsapp"
)
