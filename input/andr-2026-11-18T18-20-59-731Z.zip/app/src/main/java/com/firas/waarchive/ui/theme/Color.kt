package com.firas.waarchive.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Palette (Default)
val DarkBackground = Color(0xFF0B0F14)
val DarkSurface = Color(0xFF121820)
val DarkSurfaceVariant = Color(0xFF1B232E)
val DarkOutline = Color(0xFF2B3645)
val DarkOnSurface = Color(0xFFF1F5F9)
val DarkOnSurfaceMuted = Color(0xFF94A3B8)

// Light Palette (Optional)
val LightBackground = Color(0xFFF5F7FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE9EEF5)
val LightOutline = Color(0xFFD0D8E4)
val LightOnSurface = Color(0xFF0F172A)
val LightOnSurfaceMuted = Color(0xFF475569)

// Brand & Semantic Accents
val EmeraldPrimary = Color(0xFF10B981)
val EmeraldOnPrimary = Color(0xFF052E21)
val EmeraldContainerDark = Color(0xFF0F3A2E)
val EmeraldContainerLight = Color(0xFFD1FAE5)

val AmberWarning = Color(0xFFF59E0B)
val AmberContainerDark = Color(0xFF3A280A)
val AmberContainerLight = Color(0xFFFEF3C7)

val CrimsonDeleted = Color(0xFFEF4444)
val CrimsonContainerDark = Color(0xFF3B1518)
val CrimsonContainerLight = Color(0xFFFEE2E2)

val VioletViewOnce = Color(0xFF8B5CF6)
val VioletContainerDark = Color(0xFF2B1C4D)
val VioletContainerLight = Color(0xFFEDE9FE)

val SkyMedia = Color(0xFF0EA5E9)
val SkyContainerDark = Color(0xFF0E2F44)
val SkyContainerLight = Color(0xFFE0F2FE)
