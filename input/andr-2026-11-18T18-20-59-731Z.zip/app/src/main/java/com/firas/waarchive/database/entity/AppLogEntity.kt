package com.firas.waarchive.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "diagnostic_logs",
    indices = [
        Index(value = ["timestamp"])
    ]
)
data class AppLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val timestamp: Long,
    val level: String,
    val tag: String,
    val message: String
)
