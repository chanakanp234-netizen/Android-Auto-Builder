package com.firas.waarchive.storage

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.documentfile.provider.DocumentFile
import com.firas.waarchive.database.WaArchiveDatabase
import com.firas.waarchive.database.entity.NormalMediaEntity
import com.firas.waarchive.models.MediaType
import com.firas.waarchive.security.KeystoreCryptoManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest

data class MediaSyncResult(
    val scannedFiles: Int,
    val newlyArchivedPhotos: Int,
    val newlyArchivedVideos: Int,
    val skippedDuplicates: Int,
    val errorMessage: String? = null
)

class SafMediaArchiver(
    private val context: Context,
    private val database: WaArchiveDatabase,
    private val crypto: KeystoreCryptoManager
) {

    companion object {
        private const val PREFS_NAME = "wa_archive_saf_prefs"
        private const val KEY_TREE_URI = "saf_media_tree_uri"
        private const val KEY_LAST_SYNC_AT = "saf_last_sync_at"
        private const val MAX_SCAN_DEPTH = 3
        private const val ASSOCIATION_WINDOW_MS = 3L * 60L * 1000L
        private const val MAX_MEDIA_BYTES = 150L * 1024L * 1024L
    }

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun saveTreeUri(uri: Uri) {
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
        runCatching {
            context.contentResolver.takePersistableUriPermission(uri, flags)
        }
        prefs.edit().putString(KEY_TREE_URI, uri.toString()).apply()
    }

    fun getSavedTreeUri(): Uri? {
        val raw = prefs.getString(KEY_TREE_URI, null) ?: return null
        val uri = Uri.parse(raw)
        val hasPermission = context.contentResolver.persistedUriPermissions.any {
            it.uri == uri && it.isReadPermission
        }
        return if (hasPermission) uri else null
    }

    fun clearSavedTreeUri() {
        val existing = getSavedTreeUri()
        if (existing != null) {
            runCatching {
                context.contentResolver.releasePersistableUriPermission(
                    existing,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
        }
        prefs.edit().remove(KEY_TREE_URI).apply()
    }

    fun getLastSyncTime(): Long? =
        prefs.getLong(KEY_LAST_SYNC_AT, 0L).takeIf { it > 0L }

    suspend fun scanAndArchiveMedia(): MediaSyncResult = withContext(Dispatchers.IO) {
        val treeUri = getSavedTreeUri()
            ?: return@withContext MediaSyncResult(0, 0, 0, 0, "No WhatsApp media folder linked via Storage Access Framework.")

        val rootDir = DocumentFile.fromTreeUri(context, treeUri)
        if (rootDir == null || !rootDir.exists() || !rootDir.canRead()) {
            return@withContext MediaSyncResult(0, 0, 0, 0, "Selected folder is no longer readable.")
        }

        val candidates = mutableListOf<DocumentFile>()
        collectMediaFiles(rootDir, depth = 0, out = candidates)

        var newPhotos = 0
        var newVideos = 0
        var duplicates = 0

        val photosDir = File(context.filesDir, "archived_media/photos").apply { mkdirs() }
        val videosDir = File(context.filesDir, "archived_media/videos").apply { mkdirs() }

        for (doc in candidates) {
            val fileName = doc.name ?: continue
            if (fileName.startsWith(".")) continue
            val size = doc.length()
            if (size <= 0L || size > MAX_MEDIA_BYTES) continue

            val mime = resolveMimeType(doc, fileName) ?: continue
            val mediaType = when {
                mime.startsWith("image/") -> MediaType.PHOTO
                mime.startsWith("video/") -> MediaType.VIDEO
                else -> continue
            }

            val hash = computeSha256(doc.uri) ?: continue
            if (database.normalMediaDao().existsByHash(hash)) {
                duplicates++
                continue
            }

            val targetDir = if (mediaType == MediaType.PHOTO) photosDir else videosDir
            val safeExt = fileName.substringAfterLast('.', if (mediaType == MediaType.PHOTO) "jpg" else "mp4")
                .take(8)
                .replace(Regex("[^A-Za-z0-9]"), "")
                .ifBlank { if (mediaType == MediaType.PHOTO) "jpg" else "mp4" }
            val destFile = File(targetDir, "${hash.take(20)}_${System.currentTimeMillis()}.$safeExt")

            val copied = copyDocumentToFile(doc.uri, destFile)
            if (!copied) {
                destFile.delete()
                continue
            }

            val lastMod = doc.lastModified().takeIf { it > 0L } ?: System.currentTimeMillis()
            val reliableSender = findReliableSenderAssociation(lastMod)

            val inserted = database.normalMediaDao().insertIgnore(
                NormalMediaEntity(
                    contentHash = hash,
                    originalFileName = fileName,
                    sourceDocumentUri = doc.uri.toString(),
                    privateFilePath = destFile.absolutePath,
                    mediaType = mediaType,
                    mimeType = mime,
                    fileSizeBytes = destFile.length(),
                    encryptedSenderAssociation = crypto.encryptNullable(reliableSender),
                    fileLastModified = lastMod,
                    archivedAt = System.currentTimeMillis()
                )
            )

            if (inserted > 0L) {
                if (mediaType == MediaType.PHOTO) newPhotos++ else newVideos++
            } else {
                destFile.delete()
                duplicates++
            }
        }

        prefs.edit().putLong(KEY_LAST_SYNC_AT, System.currentTimeMillis()).apply()

        MediaSyncResult(
            scannedFiles = candidates.size,
            newlyArchivedPhotos = newPhotos,
            newlyArchivedVideos = newVideos,
            skippedDuplicates = duplicates
        )
    }

    private fun collectMediaFiles(dir: DocumentFile, depth: Int, out: MutableList<DocumentFile>) {
        if (depth > MAX_SCAN_DEPTH) return
        val children = runCatching { dir.listFiles() }.getOrNull() ?: return
        for (child in children) {
            val name = child.name.orEmpty()
            if (name.startsWith(".") || name.equals("Statuses", ignoreCase = true) || name.equals("Sent", ignoreCase = true)) {
                continue
            }
            if (child.isDirectory) {
                collectMediaFiles(child, depth + 1, out)
            } else if (child.isFile) {
                out.add(child)
            }
        }
    }

    private fun resolveMimeType(doc: DocumentFile, fileName: String): String? {
        doc.type?.takeIf { it.startsWith("image/") || it.startsWith("video/") }?.let { return it }
        val ext = fileName.substringAfterLast('.', "").lowercase()
        val guessed = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
        return guessed?.takeIf { it.startsWith("image/") || it.startsWith("video/") }
    }

    private fun computeSha256(uri: Uri): String? {
        return runCatching {
            val digest = MessageDigest.getInstance("SHA-256")
            context.contentResolver.openInputStream(uri)?.use { input ->
                val buffer = ByteArray(16 * 1024)
                var read = input.read(buffer)
                while (read != -1) {
                    digest.update(buffer, 0, read)
                    read = input.read(buffer)
                }
            } ?: return null
            digest.digest().joinToString("") { "%02x".format(it) }
        }.getOrNull()
    }

    private fun copyDocumentToFile(sourceUri: Uri, destFile: File): Boolean {
        return runCatching {
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output, bufferSize = 16 * 1024)
                }
            } ?: return false
            destFile.exists() && destFile.length() > 0L
        }.getOrDefault(false)
    }

    private suspend fun findReliableSenderAssociation(fileTimestamp: Long): String? {
        val candidates = database.messageDao().findMediaMessageCandidatesNear(
            startTime = fileTimestamp - ASSOCIATION_WINDOW_MS,
            endTime = fileTimestamp + ASSOCIATION_WINDOW_MS
        )
        if (candidates.isEmpty()) return null
        val distinctSenders = candidates.map { crypto.decrypt(it.encryptedSenderName) }.distinct()
        return if (distinctSenders.size == 1) distinctSenders.first() else null
    }

    fun deleteAllPrivateMediaFiles() {
        val root = File(context.filesDir, "archived_media")
        if (root.exists()) {
            root.deleteRecursively()
        }
    }
}
