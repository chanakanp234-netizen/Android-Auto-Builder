package com.firas.waarchive.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.firas.waarchive.database.entity.ConversationMetadataEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ConversationDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(conversation: ConversationMetadataEntity)

    @Query("SELECT * FROM conversations WHERE conversationKey = :key LIMIT 1")
    suspend fun getByKey(key: String): ConversationMetadataEntity?

    @Query("SELECT * FROM conversations ORDER BY lastMessageAt DESC")
    fun observeAll(): Flow<List<ConversationMetadataEntity>>

    @Query("SELECT COUNT(*) FROM conversations")
    fun observeCount(): Flow<Int>

    @Query("DELETE FROM conversations")
    suspend fun clearAll()
}
