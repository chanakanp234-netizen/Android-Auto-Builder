package com.firas.waarchive.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.firas.waarchive.WaArchiveApplication
import com.firas.waarchive.models.ArchiveFilterState
import com.firas.waarchive.models.ArchivedMessageUi
import com.firas.waarchive.models.DashboardStats
import com.firas.waarchive.models.DateRangeFilter
import com.firas.waarchive.models.DeletionEventUi
import com.firas.waarchive.models.DiagnosticLogUi
import com.firas.waarchive.models.ListenerStatus
import com.firas.waarchive.models.MessageCategory
import com.firas.waarchive.models.NormalMediaUi
import com.firas.waarchive.models.ViewOnceEventUi
import com.firas.waarchive.storage.MediaSyncResult
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as WaArchiveApplication
    private val repository = app.repository
    private val uiPrefs = application.getSharedPreferences("wa_archive_ui_prefs", Context.MODE_PRIVATE)

    private val _isDarkMode = MutableStateFlow(uiPrefs.getBoolean("dark_mode", true))
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    private val _filterState = MutableStateFlow(ArchiveFilterState())
    val filterState: StateFlow<ArchiveFilterState> = _filterState.asStateFlow()

    private val _safTreeUri = MutableStateFlow(repository.safMediaArchiver.getSavedTreeUri())
    val safTreeUri: StateFlow<Uri?> = _safTreeUri.asStateFlow()

    private val _lastMediaSyncAt = MutableStateFlow(repository.safMediaArchiver.getLastSyncTime())
    val lastMediaSyncAt: StateFlow<Long?> = _lastMediaSyncAt.asStateFlow()

    private val _isSyncingMedia = MutableStateFlow(false)
    val isSyncingMedia: StateFlow<Boolean> = _isSyncingMedia.asStateFlow()

    private val _snackbarMessage = MutableSharedFlow<String>()
    val snackbarMessage = _snackbarMessage.asSharedFlow()

    val listenerStatus: StateFlow<ListenerStatus> = repository.listenerStatus

    val dashboardStats: StateFlow<DashboardStats> = repository.dashboardStats
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DashboardStats())

    val allMessages: StateFlow<List<ArchivedMessageUi>> = repository.allMessages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val filteredMessages: StateFlow<List<ArchivedMessageUi>> = combine(
        repository.allMessages,
        _filterState
    ) { messages, filter ->
        repository.filterMessages(messages, filter)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val deletionEvents: StateFlow<List<DeletionEventUi>> = repository.deletionEvents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val viewOnceEvents: StateFlow<List<ViewOnceEventUi>> = repository.viewOnceEvents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val normalMedia: StateFlow<List<NormalMediaUi>> = repository.normalMedia
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val diagnosticLogs: StateFlow<List<DiagnosticLogUi>> = repository.diagnosticLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun refreshListenerPermission() {
        app.listenerStatusTracker.refreshPermissionState()
    }

    fun setDarkMode(enabled: Boolean) {
        uiPrefs.edit().putBoolean("dark_mode", enabled).apply()
        _isDarkMode.value = enabled
    }

    fun updateSearchQuery(query: String) {
        _filterState.update { it.copy(searchQuery = query) }
    }

    fun updateCategoryFilter(category: MessageCategory?) {
        _filterState.update { it.copy(selectedCategory = category) }
    }

    fun updateDeletedOnlyFilter(onlyDeleted: Boolean) {
        _filterState.update { it.copy(onlyDeleted = onlyDeleted) }
    }

    fun updateGroupFilter(onlyGroups: Boolean?) {
        _filterState.update { it.copy(onlyGroupChats = onlyGroups) }
    }

    fun updateDateRange(range: DateRangeFilter) {
        _filterState.update { it.copy(dateRange = range) }
    }

    fun updateConversationFilter(conversation: String?) {
        _filterState.update { it.copy(selectedConversation = conversation) }
    }

    fun updateSenderFilter(sender: String?) {
        _filterState.update { it.copy(selectedSender = sender) }
    }

    fun clearFilters() {
        _filterState.value = ArchiveFilterState()
    }

    fun deleteMessage(id: Long) {
        viewModelScope.launch {
            repository.deleteMessage(id)
            _snackbarMessage.emit("Archived message removed.")
        }
    }

    fun deleteDeletionEvent(id: Long) {
        viewModelScope.launch {
            repository.deleteDeletionEvent(id)
            _snackbarMessage.emit("Deletion record removed.")
        }
    }

    fun deleteViewOnceEvent(id: Long) {
        viewModelScope.launch {
            repository.deleteViewOnceEvent(id)
            _snackbarMessage.emit("View Once record removed.")
        }
    }

    fun deleteMediaRecord(id: Long) {
        viewModelScope.launch {
            repository.deleteMediaRecord(id)
            _snackbarMessage.emit("Archived media item removed.")
        }
    }

    fun clearCompleteArchive() {
        viewModelScope.launch {
            repository.clearCompleteArchive()
            _snackbarMessage.emit("Complete local archive cleared.")
        }
    }

    fun onSafFolderSelected(uri: Uri) {
        repository.safMediaArchiver.saveTreeUri(uri)
        _safTreeUri.value = repository.safMediaArchiver.getSavedTreeUri()
        syncSafMedia()
    }

    fun unlinkSafFolder() {
        repository.safMediaArchiver.clearSavedTreeUri()
        _safTreeUri.value = null
        viewModelScope.launch {
            _snackbarMessage.emit("WhatsApp media folder unlinked.")
        }
    }

    fun syncSafMedia() {
        if (_isSyncingMedia.value) return
        viewModelScope.launch {
            _isSyncingMedia.value = true
            val result: MediaSyncResult = repository.syncNormalMedia()
            _isSyncingMedia.value = false
            _lastMediaSyncAt.value = repository.safMediaArchiver.getLastSyncTime()
            val msg = result.errorMessage
                ?: "Media scan complete: ${result.newlyArchivedPhotos} photos, ${result.newlyArchivedVideos} videos added (${result.skippedDuplicates} duplicates skipped)."
            _snackbarMessage.emit(msg)
        }
    }

    fun exportToJson(destinationUri: Uri) {
        viewModelScope.launch {
            val result = repository.exportArchiveToJson(destinationUri)
            result.onSuccess { count ->
                _snackbarMessage.emit("Exported $count encrypted archive records to JSON.")
            }.onFailure { err ->
                _snackbarMessage.emit("Export failed: ${err.localizedMessage ?: "Unknown error"}")
            }
        }
    }
}
