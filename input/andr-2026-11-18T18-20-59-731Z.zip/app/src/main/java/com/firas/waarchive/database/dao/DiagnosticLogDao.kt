package com.firas.waarchive.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.firas.waarchive.database.entity.AppLogEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface DiagnosticLogDao {

    @Insert
    suspend fun insert(log: AppLogEntity)

    @Query("SELECT * FROM diagnostic_logs ORDER BY timestamp DESC, id DESC LIMIT 120")
    fun observeRecent(): Flow<List<AppLogEntity>>

    @Query("DELETE FROM diagnostic_logs WHERE id NOT IN (SELECT id FROM diagnostic_logs ORDER BY timestamp DESC, id DESC LIMIT 200)")
    suspend fun trimOldLogs()

    @Query("DELETE FROM diagnostic_logs")
    suspend fun clearAll()
}
