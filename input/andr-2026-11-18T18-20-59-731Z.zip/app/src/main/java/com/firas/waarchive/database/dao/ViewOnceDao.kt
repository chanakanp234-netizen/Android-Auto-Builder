package com.firas.waarchive.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.firas.waarchive.database.entity.ViewOnceEventEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ViewOnceDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIgnore(event: ViewOnceEventEntity): Long

    @Query("SELECT * FROM view_once_events ORDER BY notificationTimestamp DESC, id DESC")
    fun observeAll(): Flow<List<ViewOnceEventEntity>>

    @Query("SELECT * FROM view_once_events ORDER BY notificationTimestamp DESC, id DESC")
    suspend fun getAllSnapshot(): List<ViewOnceEventEntity>

    @Query("SELECT COUNT(*) FROM view_once_events")
    fun observeCount(): Flow<Int>

    @Query("DELETE FROM view_once_events WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM view_once_events")
    suspend fun clearAll()
}
