package com.firas.waarchive.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = EmeraldPrimary,
    onPrimary = EmeraldOnPrimary,
    primaryContainer = EmeraldContainerDark,
    onPrimaryContainer = ColorPaletteDefaults.DarkPrimaryContainerText,
    secondary = SkyMedia,
    secondaryContainer = SkyContainerDark,
    tertiary = VioletViewOnce,
    tertiaryContainer = VioletContainerDark,
    background = DarkBackground,
    onBackground = DarkOnSurface,
    surface = DarkSurface,
    onSurface = DarkOnSurface,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkOnSurfaceMuted,
    outline = DarkOutline,
    error = CrimsonDeleted,
    errorContainer = CrimsonContainerDark
)

private val LightColorScheme = lightColorScheme(
    primary = EmeraldPrimary,
    onPrimary = LightSurface,
    primaryContainer = EmeraldContainerLight,
    onPrimaryContainer = EmeraldOnPrimary,
    secondary = SkyMedia,
    secondaryContainer = SkyContainerLight,
    tertiary = VioletViewOnce,
    tertiaryContainer = VioletContainerLight,
    background = LightBackground,
    onBackground = LightOnSurface,
    surface = LightSurface,
    onSurface = LightOnSurface,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightOnSurfaceMuted,
    outline = LightOutline,
    error = CrimsonDeleted,
    errorContainer = CrimsonContainerLight
)

private object ColorPaletteDefaults {
    val DarkPrimaryContainerText = androidx.compose.ui.graphics.Color(0xFFA7F3D0)
}

@Composable
fun WaArchiveTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = colorScheme.background.toArgb()
                window.navigationBarColor = colorScheme.surface.toArgb()
                WindowCompat.getInsetsController(window, view).apply {
                    isAppearanceLightStatusBars = !darkTheme
                    isAppearanceLightNavigationBars = !darkTheme
                }
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = ArchiveTypography,
        content = content
    )
}
