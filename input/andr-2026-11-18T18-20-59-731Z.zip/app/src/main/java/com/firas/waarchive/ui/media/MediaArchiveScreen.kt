package com.firas.waarchive.ui.media

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Photo
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.firas.waarchive.models.MediaType
import com.firas.waarchive.models.NormalMediaUi
import com.firas.waarchive.ui.components.EmptyArchiveState
import com.firas.waarchive.ui.components.LimitationInfoBanner
import com.firas.waarchive.ui.components.StatusTag
import com.firas.waarchive.ui.components.formatFileSize
import com.firas.waarchive.ui.components.formatTimestamp
import com.firas.waarchive.ui.theme.EmeraldPrimary
import com.firas.waarchive.ui.theme.SkyMedia
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun MediaArchiveScreen(
    mediaItems: List<NormalMediaUi>,
    safTreeUri: Uri?,
    lastSyncAt: Long?,
    isSyncing: Boolean,
    onSelectMediaFolder: () -> Unit,
    onSyncNow: () -> Unit,
    onDeleteMedia: (Long) -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) }

    val photosCount = remember(mediaItems) { mediaItems.count { it.mediaType == MediaType.PHOTO } }
    val videosCount = remember(mediaItems) { mediaItems.count { it.mediaType == MediaType.VIDEO } }

    val displayedItems = remember(mediaItems, selectedTab) {
        when (selectedTab) {
            1 -> mediaItems.filter { it.mediaType == MediaType.PHOTO }
            2 -> mediaItems.filter { it.mediaType == MediaType.VIDEO }
            else -> mediaItems
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = selectedTab) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("All (${mediaItems.size})") }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Photos ($photosCount)") }
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text("Videos ($videosCount)") }
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SafFolderControlCard(
                    safTreeUri = safTreeUri,
                    lastSyncAt = lastSyncAt,
                    isSyncing = isSyncing,
                    onSelectFolder = onSelectMediaFolder,
                    onSyncNow = onSyncNow
                )
            }

            item {
                LimitationInfoBanner(
                    title = "Ordinary Downloaded Media Only",
                    body = "Files copied here come exclusively from the WhatsApp folder you explicitly select via Storage Access Framework (typically Android/media/com.whatsapp/WhatsApp/Media). View Once media is never mixed here."
                )
            }

            if (displayedItems.isEmpty()) {
                item {
                    EmptyArchiveState(
                        icon = Icons.Rounded.PhotoLibrary,
                        title = if (safTreeUri == null) "Select WhatsApp Media Folder" else "No Ordinary Media Archived",
                        subtitle = if (safTreeUri == null) {
                            "Choose your WhatsApp Images or WhatsApp Media folder using Storage Access Framework to archive downloaded photos and videos privately."
                        } else {
                            "Tap Scan & Archive Now to detect and copy new downloaded photos and videos without duplicates."
                        }
                    )
                }
            } else {
                items(displayedItems, key = { it.id }) { item ->
                    NormalMediaCard(
                        item = item,
                        onOpen = {
                            val file = File(item.privateFilePath)
                            if (file.exists()) {
                                runCatching {
                                    val contentUri = FileProvider.getUriForFile(
                                        context,
                                        "${context.packageName}.fileprovider",
                                        file
                                    )
                                    val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(contentUri, item.mimeType)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(viewIntent)
                                }
                            }
                        },
                        onDelete = { onDeleteMedia(item.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun SafFolderControlCard(
    safTreeUri: Uri?,
    lastSyncAt: Long?,
    isSyncing: Boolean,
    onSelectFolder: () -> Unit,
    onSyncNow: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Rounded.FolderOpen,
                    contentDescription = null,
                    tint = SkyMedia,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Storage Access Framework (SAF)",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = if (safTreeUri != null) {
                            "Linked: ${safTreeUri.lastPathSegment ?: safTreeUri.toString()}"
                        } else {
                            "No WhatsApp media folder selected"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            if (lastSyncAt != null) {
                Text(
                    text = "Last media scan: ${formatTimestamp(lastSyncAt)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onSelectFolder,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (safTreeUri == null) "Select Folder" else "Change Folder")
                }

                Button(
                    onClick = onSyncNow,
                    enabled = safTreeUri != null && !isSyncing,
                    modifier = Modifier.weight(1f)
                ) {
                    if (isSyncing) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    } else {
                        Icon(Icons.Rounded.Sync, contentDescription = null, modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (isSyncing) "Scanning..." else "Scan Now")
                }
            }
        }
    }
}

@Composable
private fun NormalMediaCard(
    item: NormalMediaUi,
    onOpen: () -> Unit,
    onDelete: () -> Unit
) {
    val thumbnail by produceState<Bitmap?>(initialValue = null, key1 = item.privateFilePath) {
        value = withContext(Dispatchers.IO) {
            loadLocalThumbnail(item.privateFilePath, item.mediaType)
        }
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen),
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                if (thumbnail != null) {
                    Image(
                        bitmap = thumbnail!!.asImageBitmap(),
                        contentDescription = item.originalFileName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = if (item.mediaType == MediaType.PHOTO) Icons.Rounded.Photo else Icons.Rounded.Videocam,
                        contentDescription = null,
                        tint = SkyMedia,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = item.originalFileName,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    StatusTag(
                        label = if (item.mediaType == MediaType.PHOTO) "PHOTO" else "VIDEO",
                        color = if (item.mediaType == MediaType.PHOTO) EmeraldPrimary else SkyMedia
                    )
                    StatusTag(
                        label = formatFileSize(item.fileSizeBytes),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (!item.senderAssociation.isNullOrBlank()) {
                    Text(
                        text = "Associated sender: ${item.senderAssociation}",
                        style = MaterialTheme.typography.labelMedium,
                        color = EmeraldPrimary
                    )
                }

                Text(
                    text = "Modified: ${formatTimestamp(item.fileLastModified)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                IconButton(onClick = onOpen) {
                    Icon(
                        imageVector = Icons.Rounded.OpenInNew,
                        contentDescription = "Open media",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Rounded.DeleteOutline,
                        contentDescription = "Delete archived media",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

private fun loadLocalThumbnail(path: String, mediaType: MediaType): Bitmap? {
    val file = File(path)
    if (!file.exists()) return null
    return runCatching {
        if (mediaType == MediaType.PHOTO) {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, bounds)
            val sample = maxOf(1, minOf(bounds.outWidth / 180, bounds.outHeight / 180))
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            BitmapFactory.decodeFile(path, opts)
        } else {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(path)
                retriever.getFrameAtTime(0L)
            } finally {
                retriever.release()
            }
        }
    }.getOrNull()
}
