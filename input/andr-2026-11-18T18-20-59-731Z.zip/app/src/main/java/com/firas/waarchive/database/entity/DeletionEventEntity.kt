package com.firas.waarchive.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.firas.waarchive.models.DeletionMatchConfidence

@Entity(
    tableName = "deletion_events",
    indices = [
        Index(value = ["dedupHash"], unique = true),
        Index(value = ["notificationKey"]),
        Index(value = ["conversationKey"]),
        Index(value = ["detectedAt"]),
        Index(value = ["matchedMessageId"])
    ]
)
data class DeletionEventEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val dedupHash: String,
    val notificationKey: String,
    val conversationKey: String,
    val encryptedSenderName: String,
    val encryptedConversationName: String,
    val encryptedNoticeText: String,
    val detectedAt: Long,
    val matchedMessageId: Long?,
    val matchConfidence: DeletionMatchConfidence,
    val encryptedMatchedOriginalText: String?
)
