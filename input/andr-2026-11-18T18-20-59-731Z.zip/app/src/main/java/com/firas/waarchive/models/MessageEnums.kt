package com.firas.waarchive.models

enum class MessageCategory {
    TEXT,
    IMAGE,
    VIDEO,
    AUDIO,
    VOICE_NOTE,
    DOCUMENT,
    STICKER,
    VIEW_ONCE_PHOTO,
    VIEW_ONCE_VIDEO,
    VIEW_ONCE_UNKNOWN,
    DELETED_NOTICE,
    SYSTEM
}

enum class MediaType {
    PHOTO,
    VIDEO
}

enum class ViewOnceMediaKind {
    PHOTO,
    VIDEO,
    UNKNOWN
}

enum class DeletionMatchConfidence {
    HIGH,
    MEDIUM,
    UNMATCHED
}

enum class DateRangeFilter {
    ALL_TIME,
    TODAY,
    LAST_7_DAYS,
    LAST_30_DAYS
}
