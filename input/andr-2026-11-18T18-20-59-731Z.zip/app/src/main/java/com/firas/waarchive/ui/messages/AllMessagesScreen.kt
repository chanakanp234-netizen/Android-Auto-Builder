package com.firas.waarchive.ui.messages

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FilterList
import androidx.compose.material.icons.rounded.Forum
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.firas.waarchive.models.ArchiveFilterState
import com.firas.waarchive.models.ArchivedMessageUi
import com.firas.waarchive.models.DateRangeFilter
import com.firas.waarchive.models.MessageCategory
import com.firas.waarchive.ui.components.ArchivedMessageCard
import com.firas.waarchive.ui.components.EmptyArchiveState
import com.firas.waarchive.ui.components.MessageDetailDialog

@Composable
fun AllMessagesScreen(
    messages: List<ArchivedMessageUi>,
    allUnfilteredMessages: List<ArchivedMessageUi>,
    filterState: ArchiveFilterState,
    onSearchQueryChange: (String) -> Unit,
    onCategoryFilterChange: (MessageCategory?) -> Unit,
    onDeletedOnlyChange: (Boolean) -> Unit,
    onGroupFilterChange: (Boolean?) -> Unit,
    onDateRangeChange: (DateRangeFilter) -> Unit,
    onConversationFilterChange: (String?) -> Unit,
    onSenderFilterChange: (String?) -> Unit,
    onClearFilters: () -> Unit,
    onDeleteMessage: (Long) -> Unit
) {
    var selectedMessage by remember { mutableStateOf<ArchivedMessageUi?>(null) }
    var showConversationMenu by remember { mutableStateOf(false) }
    var showSenderMenu by remember { mutableStateOf(false) }
    var showDateMenu by remember { mutableStateOf(false) }
    var showCategoryMenu by remember { mutableStateOf(false) }

    val availableConversations = remember(allUnfilteredMessages) {
        allUnfilteredMessages.map { it.conversationName }.distinct().sorted()
    }
    val availableSenders = remember(allUnfilteredMessages) {
        allUnfilteredMessages.map { it.senderName }.distinct().sorted()
    }

    val hasActiveFilters = filterState != ArchiveFilterState()

    Column(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
            OutlinedTextField(
                value = filterState.searchQuery,
                onValueChange = onSearchQueryChange,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search messages, contacts, or groups...") },
                leadingIcon = {
                    Icon(Icons.Rounded.Search, contentDescription = null)
                },
                trailingIcon = {
                    if (filterState.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Clear search")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilterChip(
                    selected = filterState.onlyDeleted,
                    onClick = { onDeletedOnlyChange(!filterState.onlyDeleted) },
                    label = { Text("Deleted Only") }
                )

                FilterChip(
                    selected = filterState.onlyGroupChats == true,
                    onClick = {
                        onGroupFilterChange(if (filterState.onlyGroupChats == true) null else true)
                    },
                    label = { Text("Groups") }
                )

                // Contact / Sender Filter Menu
                Column {
                    FilterChip(
                        selected = filterState.selectedSender != null,
                        onClick = { showSenderMenu = true },
                        label = {
                            Text(filterState.selectedSender ?: "Contact")
                        },
                        leadingIcon = {
                            Icon(
                                Icons.Rounded.FilterList,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    )
                    DropdownMenu(
                        expanded = showSenderMenu,
                        onDismissRequest = { showSenderMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("All Contacts") },
                            onClick = {
                                onSenderFilterChange(null)
                                showSenderMenu = false
                            }
                        )
                        availableSenders.forEach { sender ->
                            DropdownMenuItem(
                                text = { Text(sender) },
                                onClick = {
                                    onSenderFilterChange(sender)
                                    showSenderMenu = false
                                }
                            )
                        }
                    }
                }

                // Conversation / Group Filter Menu
                Column {
                    FilterChip(
                        selected = filterState.selectedConversation != null,
                        onClick = { showConversationMenu = true },
                        label = {
                            Text(filterState.selectedConversation ?: "Chat / Group")
                        }
                    )
                    DropdownMenu(
                        expanded = showConversationMenu,
                        onDismissRequest = { showConversationMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("All Conversations") },
                            onClick = {
                                onConversationFilterChange(null)
                                showConversationMenu = false
                            }
                        )
                        availableConversations.forEach { conv ->
                            DropdownMenuItem(
                                text = { Text(conv) },
                                onClick = {
                                    onConversationFilterChange(conv)
                                    showConversationMenu = false
                                }
                            )
                        }
                    }
                }

                // Media Type / Category Filter Menu
                Column {
                    FilterChip(
                        selected = filterState.selectedCategory != null,
                        onClick = { showCategoryMenu = true },
                        label = {
                            Text(filterState.selectedCategory?.name ?: "Type")
                        }
                    )
                    DropdownMenu(
                        expanded = showCategoryMenu,
                        onDismissRequest = { showCategoryMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("All Types") },
                            onClick = {
                                onCategoryFilterChange(null)
                                showCategoryMenu = false
                            }
                        )
                        listOf(
                            MessageCategory.TEXT,
                            MessageCategory.IMAGE,
                            MessageCategory.VIDEO,
                            MessageCategory.VOICE_NOTE,
                            MessageCategory.AUDIO,
                            MessageCategory.DOCUMENT,
                            MessageCategory.STICKER
                        ).forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat.name) },
                                onClick = {
                                    onCategoryFilterChange(cat)
                                    showCategoryMenu = false
                                }
                            )
                        }
                    }
                }

                // Date Range Filter Menu
                Column {
                    FilterChip(
                        selected = filterState.dateRange != DateRangeFilter.ALL_TIME,
                        onClick = { showDateMenu = true },
                        label = {
                            Text(
                                when (filterState.dateRange) {
                                    DateRangeFilter.ALL_TIME -> "Any Date"
                                    DateRangeFilter.TODAY -> "Today"
                                    DateRangeFilter.LAST_7_DAYS -> "Last 7d"
                                    DateRangeFilter.LAST_30_DAYS -> "Last 30d"
                                }
                            )
                        }
                    )
                    DropdownMenu(
                        expanded = showDateMenu,
                        onDismissRequest = { showDateMenu = false }
                    ) {
                        DateRangeFilter.entries.forEach { range ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        when (range) {
                                            DateRangeFilter.ALL_TIME -> "All Time"
                                            DateRangeFilter.TODAY -> "Today"
                                            DateRangeFilter.LAST_7_DAYS -> "Last 7 Days"
                                            DateRangeFilter.LAST_30_DAYS -> "Last 30 Days"
                                        }
                                    )
                                },
                                onClick = {
                                    onDateRangeChange(range)
                                    showDateMenu = false
                                }
                            )
                        }
                    }
                }

                if (hasActiveFilters) {
                    TextButton(onClick = onClearFilters) {
                        Text("Reset")
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "${messages.size} archived message(s)",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        if (messages.isEmpty()) {
            EmptyArchiveState(
                icon = Icons.Rounded.Forum,
                title = if (hasActiveFilters) "No Matching Messages" else "No Archived Messages Yet",
                subtitle = if (hasActiveFilters) {
                    "Try adjusting your search keywords or active filters."
                } else {
                    "Once Notification Access is granted, incoming WhatsApp notifications will be archived here automatically."
                }
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    ArchivedMessageCard(
                        message = msg,
                        onClick = { selectedMessage = msg }
                    )
                }
            }
        }
    }

    selectedMessage?.let { msg ->
        MessageDetailDialog(
            message = msg,
            onDismiss = { selectedMessage = null },
            onDelete = {
                onDeleteMessage(msg.id)
                selectedMessage = null
            }
        )
    }
}
