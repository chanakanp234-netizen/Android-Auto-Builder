package com.firas.waarchive.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.firas.waarchive.database.entity.ArchivedMessageEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MessageDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIgnore(message: ArchivedMessageEntity): Long

    @Query("SELECT * FROM archived_messages ORDER BY notificationTimestamp DESC, id DESC")
    fun observeAllMessages(): Flow<List<ArchivedMessageEntity>>

    @Query("SELECT * FROM archived_messages WHERE isDeleted = 1 ORDER BY notificationTimestamp DESC, id DESC")
    fun observeDeletedMessages(): Flow<List<ArchivedMessageEntity>>

    @Query("SELECT * FROM archived_messages ORDER BY notificationTimestamp DESC, id DESC")
    suspend fun getAllMessagesSnapshot(): List<ArchivedMessageEntity>

    @Query(
        """
        SELECT * FROM archived_messages
        WHERE conversationKey = :conversationKey
          AND notificationTimestamp <= :beforeTimestamp
          AND notificationTimestamp >= :afterTimestamp
          AND isDeleted = 0
        ORDER BY notificationTimestamp DESC
        LIMIT 25
        """
    )
    suspend fun findCandidateMatchesForDeletion(
        conversationKey: String,
        beforeTimestamp: Long,
        afterTimestamp: Long
    ): List<ArchivedMessageEntity>

    @Query(
        """
        SELECT * FROM archived_messages
        WHERE notificationTimestamp BETWEEN :startTime AND :endTime
          AND category IN ('IMAGE', 'VIDEO')
        ORDER BY notificationTimestamp DESC
        LIMIT 10
        """
    )
    suspend fun findMediaMessageCandidatesNear(
        startTime: Long,
        endTime: Long
    ): List<ArchivedMessageEntity>

    @Query(
        """
        UPDATE archived_messages
        SET isDeleted = 1,
            linkedDeletionEventId = :deletionEventId,
            deletionDetectedAt = :detectedAt
        WHERE id = :messageId
        """
    )
    suspend fun markAsDeletedPreservingText(
        messageId: Long,
        deletionEventId: Long,
        detectedAt: Long
    )

    @Query("SELECT COUNT(*) FROM archived_messages")
    fun observeTotalCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM archived_messages WHERE isDeleted = 1")
    fun observeDeletedMessageCount(): Flow<Int>

    @Query("DELETE FROM archived_messages WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM archived_messages")
    suspend fun clearAll()
}
