package com.firas.waarchive.notifications

import android.app.Notification
import android.os.Build
import android.os.Bundle
import android.os.Parcelable
import android.service.notification.StatusBarNotification
import com.firas.waarchive.models.MessageCategory
import com.firas.waarchive.models.ViewOnceMediaKind

data class ParsedMessageEntry(
    val senderName: String,
    val conversationName: String,
    val isGroupChat: Boolean,
    val messageText: String,
    val bigText: String?,
    val timestamp: Long,
    val category: MessageCategory,
    val isDeletionNotice: Boolean,
    val isViewOnceEvent: Boolean,
    val viewOnceMediaKind: ViewOnceMediaKind?
)

data class ParsedNotificationPayload(
    val notificationKey: String,
    val notificationId: Int,
    val postTime: Long,
    val notificationTitle: String,
    val isMessagingStyle: Boolean,
    val isSummaryNotification: Boolean,
    val extrasSnapshot: String,
    val entries: List<ParsedMessageEntry>
)

object WhatsAppNotificationParser {

    const val WHATSAPP_PACKAGE = "com.whatsapp"

    private val deletionPatterns = listOf(
        "this message was deleted",
        "you deleted this message",
        "message deleted",
        "ce message a été supprimé",
        "vous avez supprimé ce message",
        "تم حذف هذه الرسالة",
        "حذفت هذه الرسالة",
        "esta mensagem foi apagada",
        "este mensaje fue eliminado",
        "diese nachricht wurde gelöscht"
    )

    private val summaryBoilerplateRegex = Regex(
        """^\d+\s+new\s+messages?(\s+from\s+\d+\s+chats?)?$""",
        RegexOption.IGNORE_CASE
    )

    private val checkingMessagesRegex = Regex(
        """^(checking for new messages|whatsapp web is currently active|backing up messages|restoring media).*$""",
        RegexOption.IGNORE_CASE
    )

    private val groupTitleCountRegex = Regex("""^(.+?)\s*\(\d+\s+messages?\)\s*$""", RegexOption.IGNORE_CASE)

    fun parse(sbn: StatusBarNotification): ParsedNotificationPayload? {
        if (sbn.packageName != WHATSAPP_PACKAGE) return null

        val notification = sbn.notification ?: return null
        val extras = notification.extras ?: Bundle.EMPTY
        val isSummary = (notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0

        val rawTitle = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val rawText = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        val rawBigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim()
            ?.takeIf { it.isNotEmpty() }
        val conversationTitle = extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)
            ?.toString()?.trim()?.takeIf { it.isNotEmpty() }
        val subText = extras.getCharSequence(Notification.EXTRA_SUB_TEXT)
            ?.toString()?.trim()?.takeIf { it.isNotEmpty() }
        val isGroupExtra = extras.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false)

        val currentMessages = extractMessagingStyleMessages(extras, Notification.EXTRA_MESSAGES)
        val historicMessages = extractMessagingStyleMessages(extras, Notification.EXTRA_HISTORIC_MESSAGES)
        val allStyleMessages = (historicMessages + currentMessages)
            .distinctBy { "${it.sender}|${it.text}|${it.timestamp}|${it.mimeType}" }

        val textLines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
            ?.mapNotNull { it?.toString()?.trim()?.takeIf { line -> line.isNotEmpty() } }
            .orEmpty()

        val entries = mutableListOf<ParsedMessageEntry>()

        // 1. Prefer structured MessagingStyle messages (current + historic) when exposed
        if (allStyleMessages.isNotEmpty()) {
            val cleanConv = cleanConversationName(conversationTitle ?: rawTitle)
            val isGroup = isGroupExtra || !conversationTitle.isNullOrEmpty() || cleanConv != rawTitle
            for (msg in allStyleMessages) {
                val msgText = msg.text.ifBlank {
                    describeMimeFallback(msg.mimeType)
                }
                if (msgText.isBlank() || isBoilerplateSystemText(msgText)) continue

                val resolvedSender = msg.sender?.takeIf { it.isNotBlank() }
                    ?: extractSenderFromColonPrefix(msgText, cleanConv)
                    ?: cleanConv.ifBlank { "WhatsApp Contact" }

                val cleanedText = stripLeadingSenderIfRedundant(msgText, resolvedSender, isGroup)
                entries += buildEntry(
                    senderName = resolvedSender,
                    conversationName = cleanConv.ifBlank { resolvedSender },
                    isGroupChat = isGroup || (resolvedSender != cleanConv && cleanConv.isNotBlank()),
                    messageText = cleanedText,
                    bigText = rawBigText?.takeIf { it != cleanedText && allStyleMessages.size == 1 },
                    timestamp = msg.timestamp.takeIf { it > 0L } ?: sbn.postTime,
                    mimeType = msg.mimeType
                )
            }
        }

        // 2. Fallback / supplement for InboxStyle EXTRA_TEXT_LINES (often populated in bundled WhatsApp summaries)
        if (entries.isEmpty() && textLines.isNotEmpty()) {
            val defaultConv = cleanConversationName(conversationTitle ?: rawTitle)
            for ((idx, line) in textLines.withIndex()) {
                if (isBoilerplateSystemText(line)) continue
                val parsedLine = parseColonLine(line, defaultConv)
                entries += buildEntry(
                    senderName = parsedLine.first,
                    conversationName = parsedLine.second,
                    isGroupChat = parsedLine.third || isGroupExtra,
                    messageText = parsedLine.fourth,
                    bigText = null,
                    timestamp = sbn.postTime + idx,
                    mimeType = null
                )
            }
        }

        // 3. Direct single notification title + text / bigText fallback
        if (entries.isEmpty()) {
            val primaryBody = rawBigText ?: rawText
            if (primaryBody.isNotBlank() && !isBoilerplateSystemText(primaryBody) && !isSummary) {
                val (resolvedSender, resolvedConv, inferredGroup) = resolveTitleAndSender(
                    rawTitle = rawTitle,
                    conversationTitle = conversationTitle,
                    subText = subText,
                    isGroupExtra = isGroupExtra
                )
                entries += buildEntry(
                    senderName = resolvedSender,
                    conversationName = resolvedConv,
                    isGroupChat = inferredGroup,
                    messageText = rawText.ifBlank { primaryBody },
                    bigText = rawBigText?.takeIf { it != rawText },
                    timestamp = sbn.postTime,
                    mimeType = null
                )
            }
        }

        val extrasSummary = buildString {
            append("title=").append(rawTitle)
            append(" | conv=").append(conversationTitle.orEmpty())
            append(" | text=").append(rawText)
            if (!rawBigText.isNullOrBlank()) append(" | bigText=").append(rawBigText)
            if (allStyleMessages.isNotEmpty()) append(" | styleCount=").append(allStyleMessages.size)
            if (textLines.isNotEmpty()) append(" | lines=").append(textLines.size)
            if (isSummary) append(" | summary=true")
        }

        return ParsedNotificationPayload(
            notificationKey = sbn.key,
            notificationId = sbn.id,
            postTime = sbn.postTime,
            notificationTitle = rawTitle.ifBlank { conversationTitle ?: "WhatsApp" },
            isMessagingStyle = allStyleMessages.isNotEmpty(),
            isSummaryNotification = isSummary,
            extrasSnapshot = extrasSummary,
            entries = entries
        )
    }

    private data class StyleMsg(
        val text: String,
        val timestamp: Long,
        val sender: String?,
        val mimeType: String?
    )

    private fun extractMessagingStyleMessages(extras: Bundle, key: String): List<StyleMsg> {
        val parcelables: Array<Parcelable>? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            extras.getParcelableArray(key, Parcelable::class.java)
        } else {
            @Suppress("DEPRECATION")
            extras.getParcelableArray(key)
        }
        if (parcelables.isNullOrEmpty()) return emptyList()

        val parsed = Notification.MessagingStyle.Message.getMessagesFromBundleArray(parcelables)
        return parsed.map { msg ->
            val senderName = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                msg.senderPerson?.name?.toString()?.trim()
            } else {
                @Suppress("DEPRECATION")
                msg.sender?.toString()?.trim()
            }
            StyleMsg(
                text = msg.text?.toString()?.trim().orEmpty(),
                timestamp = msg.timestamp,
                sender = senderName,
                mimeType = msg.dataMimeType
            )
        }
    }

    private fun buildEntry(
        senderName: String,
        conversationName: String,
        isGroupChat: Boolean,
        messageText: String,
        bigText: String?,
        timestamp: Long,
        mimeType: String?
    ): ParsedMessageEntry {
        val combined = listOfNotNull(messageText, bigText).joinToString(" ").trim()
        val isDeletion = isExplicitDeletionNotice(combined)
        val viewOnceKind = detectViewOnceKind(combined, mimeType)
        val isViewOnce = viewOnceKind != null && !isDeletion

        val category = when {
            isDeletion -> MessageCategory.DELETED_NOTICE
            viewOnceKind == ViewOnceMediaKind.PHOTO -> MessageCategory.VIEW_ONCE_PHOTO
            viewOnceKind == ViewOnceMediaKind.VIDEO -> MessageCategory.VIEW_ONCE_VIDEO
            viewOnceKind == ViewOnceMediaKind.UNKNOWN -> MessageCategory.VIEW_ONCE_UNKNOWN
            else -> classifyNormalCategory(combined, mimeType)
        }

        return ParsedMessageEntry(
            senderName = senderName.ifBlank { "Unknown Sender" },
            conversationName = conversationName.ifBlank { senderName.ifBlank { "WhatsApp Chat" } },
            isGroupChat = isGroupChat,
            messageText = messageText,
            bigText = bigText,
            timestamp = timestamp,
            category = category,
            isDeletionNotice = isDeletion,
            isViewOnceEvent = isViewOnce,
            viewOnceMediaKind = viewOnceKind
        )
    }

    internal fun isExplicitDeletionNotice(text: String): Boolean {
        val normalized = text.lowercase().trim()
        if (normalized.isEmpty()) return false
        return deletionPatterns.any { normalized.contains(it) }
    }

    internal fun detectViewOnceKind(text: String, mimeType: String?): ViewOnceMediaKind? {
        val lower = text.lowercase()
        val hasExplicitViewOnceMarker =
            lower.contains("view once") ||
                lower.contains("view-once") ||
                lower.contains("1-time") ||
                lower.contains("one-time photo") ||
                lower.contains("one-time video") ||
                lower.contains("photo • once") ||
                lower.contains("video • once") ||
                lower.contains("vue unique") ||
                lower.contains("عرض لمرة واحدة") ||
                lower.contains("visualização única") ||
                lower.contains("ver una vez")

        if (!hasExplicitViewOnceMarker) return null

        return when {
            lower.contains("photo") || lower.contains("image") || lower.contains("📷") ||
                mimeType?.startsWith("image/") == true -> ViewOnceMediaKind.PHOTO
            lower.contains("video") || lower.contains("🎥") || lower.contains("📹") ||
                mimeType?.startsWith("video/") == true -> ViewOnceMediaKind.VIDEO
            else -> ViewOnceMediaKind.UNKNOWN
        }
    }

    private fun classifyNormalCategory(text: String, mimeType: String?): MessageCategory {
        val lower = text.lowercase()
        return when {
            mimeType?.startsWith("image/") == true || lower.startsWith("📷") || lower == "photo" -> MessageCategory.IMAGE
            mimeType?.startsWith("video/") == true || lower.startsWith("🎥") || lower.startsWith("📹") || lower == "video" -> MessageCategory.VIDEO
            lower.contains("voice message") || lower.startsWith("🎤") -> MessageCategory.VOICE_NOTE
            mimeType?.startsWith("audio/") == true || lower.startsWith("🎵") || lower == "audio" -> MessageCategory.AUDIO
            lower.startsWith("📄") || lower.contains("document") -> MessageCategory.DOCUMENT
            lower.contains("sticker") || lower.startsWith("💟") -> MessageCategory.STICKER
            else -> MessageCategory.TEXT
        }
    }

    private fun describeMimeFallback(mimeType: String?): String {
        return when {
            mimeType == null -> ""
            mimeType.startsWith("image/") -> "📷 Photo"
            mimeType.startsWith("video/") -> "🎥 Video"
            mimeType.startsWith("audio/") -> "🎵 Audio"
            else -> "Attachment ($mimeType)"
        }
    }

    private fun isBoilerplateSystemText(text: String): Boolean {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return true
        if (summaryBoilerplateRegex.matches(trimmed)) return true
        if (checkingMessagesRegex.matches(trimmed)) return true
        return false
    }

    private fun cleanConversationName(raw: String): String {
        val match = groupTitleCountRegex.matchEntire(raw.trim())
        return (match?.groupValues?.getOrNull(1) ?: raw).trim()
    }

    private fun resolveTitleAndSender(
        rawTitle: String,
        conversationTitle: String?,
        subText: String?,
        isGroupExtra: Boolean
    ): Triple<String, String, Boolean> {
        val cleanedTitle = cleanConversationName(rawTitle)
        if (!conversationTitle.isNullOrBlank()) {
            val cleanConv = cleanConversationName(conversationTitle)
            return Triple(
                cleanedTitle.ifBlank { cleanConv },
                cleanConv,
                true
            )
        }
        // Check WhatsApp pattern "Group Name: Sender" or "Sender @ Group Name"
        if (cleanedTitle.contains(" @ ")) {
            val parts = cleanedTitle.split(" @ ", limit = 2)
            return Triple(parts[0].trim(), parts[1].trim(), true)
        }
        if (cleanedTitle.contains(": ") && !cleanedTitle.startsWith("+")) {
            val parts = cleanedTitle.split(": ", limit = 2)
            return Triple(parts[1].trim(), parts[0].trim(), true)
        }
        val convName = subText?.let { cleanConversationName(it) } ?: cleanedTitle
        val isGroup = isGroupExtra || (convName != cleanedTitle && convName.isNotBlank())
        return Triple(cleanedTitle.ifBlank { "WhatsApp Contact" }, convName.ifBlank { "WhatsApp Chat" }, isGroup)
    }

    private data class Quad(val first: String, val second: String, val third: Boolean, val fourth: String)

    private fun parseColonLine(line: String, defaultConversation: String): Quad {
        val colonIdx = line.indexOf(": ")
        if (colonIdx in 1..48) {
            val left = line.substring(0, colonIdx).trim()
            val right = line.substring(colonIdx + 2).trim()
            if (left.contains(" @ ")) {
                val parts = left.split(" @ ", limit = 2)
                return Quad(parts[0].trim(), parts[1].trim(), true, right)
            }
            val conv = defaultConversation.takeIf {
                it.isNotBlank() && !it.equals("WhatsApp", ignoreCase = true) && !summaryBoilerplateRegex.matches(it)
            } ?: left
            val isGroup = conv != left
            return Quad(left, conv, isGroup, right)
        }
        return Quad(defaultConversation.ifBlank { "WhatsApp Contact" }, defaultConversation.ifBlank { "WhatsApp Chat" }, false, line)
    }

    private fun extractSenderFromColonPrefix(text: String, conversationName: String): String? {
        val colonIdx = text.indexOf(": ")
        if (colonIdx in 1..40) {
            val candidate = text.substring(0, colonIdx).trim()
            if (!candidate.equals(conversationName, ignoreCase = true)) {
                return candidate
            }
        }
        return null
    }

    private fun stripLeadingSenderIfRedundant(text: String, sender: String, isGroup: Boolean): String {
        if (!isGroup) return text
        val prefix = "$sender: "
        return if (text.startsWith(prefix) && text.length > prefix.length) {
            text.removePrefix(prefix).trim()
        } else {
            text
        }
    }
}
