package com.firas.waarchive.repository

import android.content.Context
import android.net.Uri
import com.firas.waarchive.database.WaArchiveDatabase
import com.firas.waarchive.models.ArchiveFilterState
import com.firas.waarchive.models.ArchivedMessageUi
import com.firas.waarchive.models.ConversationSummaryUi
import com.firas.waarchive.models.DashboardStats
import com.firas.waarchive.models.DateRangeFilter
import com.firas.waarchive.models.DeletionEventUi
import com.firas.waarchive.models.DiagnosticLogUi
import com.firas.waarchive.models.ListenerStatus
import com.firas.waarchive.models.NormalMediaUi
import com.firas.waarchive.models.ViewOnceEventUi
import com.firas.waarchive.notifications.ListenerStatusTracker
import com.firas.waarchive.security.KeystoreCryptoManager
import com.firas.waarchive.storage.MediaSyncResult
import com.firas.waarchive.storage.SafMediaArchiver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Calendar

class ArchiveRepository(
    private val context: Context,
    private val database: WaArchiveDatabase,
    private val crypto: KeystoreCryptoManager,
    private val statusTracker: ListenerStatusTracker,
    val safMediaArchiver: SafMediaArchiver
) {

    val listenerStatus: StateFlow<ListenerStatus> = statusTracker.status

    val allMessages: Flow<List<ArchivedMessageUi>> = database.messageDao().observeAllMessages()
        .map { list ->
            list.map { entity ->
                ArchivedMessageUi(
                    id = entity.id,
                    notificationKey = entity.notificationKey,
                    notificationId = entity.notificationId,
                    conversationKey = entity.conversationKey,
                    notificationTitle = crypto.decrypt(entity.encryptedNotificationTitle),
                    senderName = crypto.decrypt(entity.encryptedSenderName),
                    conversationName = crypto.decrypt(entity.encryptedConversationName),
                    isGroupChat = entity.isGroupChat,
                    messageText = crypto.decrypt(entity.encryptedMessageText),
                    bigText = crypto.decryptNullable(entity.encryptedBigText),
                    category = entity.category,
                    notificationTimestamp = entity.notificationTimestamp,
                    archivedAt = entity.archivedAt,
                    isDeleted = entity.isDeleted,
                    linkedDeletionEventId = entity.linkedDeletionEventId,
                    deletionDetectedAt = entity.deletionDetectedAt,
                    sourcePackage = entity.sourcePackage
                )
            }
        }

    val deletionEvents: Flow<List<DeletionEventUi>> = database.deletionEventDao().observeAll()
        .map { list ->
            list.map { entity ->
                DeletionEventUi(
                    id = entity.id,
                    notificationKey = entity.notificationKey,
                    conversationKey = entity.conversationKey,
                    senderName = crypto.decrypt(entity.encryptedSenderName),
                    conversationName = crypto.decrypt(entity.encryptedConversationName),
                    noticeText = crypto.decrypt(entity.encryptedNoticeText),
                    detectedAt = entity.detectedAt,
                    matchedMessageId = entity.matchedMessageId,
                    matchConfidence = entity.matchConfidence,
                    matchedOriginalText = crypto.decryptNullable(entity.encryptedMatchedOriginalText)
                )
            }
        }

    val viewOnceEvents: Flow<List<ViewOnceEventUi>> = database.viewOnceDao().observeAll()
        .map { list ->
            list.map { entity ->
                ViewOnceEventUi(
                    id = entity.id,
                    notificationKey = entity.notificationKey,
                    senderName = crypto.decrypt(entity.encryptedSenderName),
                    conversationName = crypto.decrypt(entity.encryptedConversationName),
                    isGroupChat = entity.isGroupChat,
                    mediaKind = entity.mediaKind,
                    rawNotice = crypto.decrypt(entity.encryptedRawNotice),
                    notificationTimestamp = entity.notificationTimestamp,
                    archivedAt = entity.archivedAt,
                    limitationNote = entity.limitationNote
                )
            }
        }

    val normalMedia: Flow<List<NormalMediaUi>> = database.normalMediaDao().observeAll()
        .map { list ->
            list.map { entity ->
                NormalMediaUi(
                    id = entity.id,
                    contentHash = entity.contentHash,
                    originalFileName = entity.originalFileName,
                    sourceDocumentUri = entity.sourceDocumentUri,
                    privateFilePath = entity.privateFilePath,
                    mediaType = entity.mediaType,
                    mimeType = entity.mimeType,
                    fileSizeBytes = entity.fileSizeBytes,
                    senderAssociation = crypto.decryptNullable(entity.encryptedSenderAssociation),
                    fileLastModified = entity.fileLastModified,
                    archivedAt = entity.archivedAt
                )
            }
        }

    val conversations: Flow<List<ConversationSummaryUi>> = database.conversationDao().observeAll()
        .map { list ->
            list.map { entity ->
                ConversationSummaryUi(
                    conversationKey = entity.conversationKey,
                    displayName = crypto.decrypt(entity.encryptedDisplayName),
                    isGroup = entity.isGroup,
                    messageCount = entity.messageCount,
                    lastMessageAt = entity.lastMessageAt,
                    deletedCount = entity.deletedCount,
                    viewOnceCount = entity.viewOnceCount
                )
            }
        }

    val diagnosticLogs: Flow<List<DiagnosticLogUi>> = database.diagnosticLogDao().observeRecent()
        .map { list ->
            list.map {
                DiagnosticLogUi(
                    id = it.id,
                    timestamp = it.timestamp,
                    level = it.level,
                    tag = it.tag,
                    message = it.message
                )
            }
        }

    val dashboardStats: Flow<DashboardStats> = combine(
        database.messageDao().observeTotalCount(),
        database.deletionEventDao().observeCount(),
        database.viewOnceDao().observeCount(),
        database.normalMediaDao().observeCount(),
        database.observationDao().observeCount()
    ) { msgCount, delCount, voCount, mediaCount, obsCount ->
        DashboardStats(
            totalMessages = msgCount,
            deletedRecords = delCount,
            viewOnceEvents = voCount,
            archivedMediaCount = mediaCount,
            totalObservations = obsCount,
            conversationsCount = 0
        )
    }.combine(database.conversationDao().observeCount()) { stats, convCount ->
        stats.copy(conversationsCount = convCount)
    }

    fun filterMessages(
        messages: List<ArchivedMessageUi>,
        filter: ArchiveFilterState
    ): List<ArchivedMessageUi> {
        val query = filter.searchQuery.trim().lowercase()
        val now = System.currentTimeMillis()
        val cutoffTime = when (filter.dateRange) {
            DateRangeFilter.ALL_TIME -> 0L
            DateRangeFilter.TODAY -> {
                Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }.timeInMillis
            }
            DateRangeFilter.LAST_7_DAYS -> now - 7L * 24L * 60L * 60L * 1000L
            DateRangeFilter.LAST_30_DAYS -> now - 30L * 24L * 60L * 60L * 1000L
        }

        return messages.filter { msg ->
            if (filter.onlyDeleted && !msg.isDeleted) return@filter false
            if (filter.onlyGroupChats == true && !msg.isGroupChat) return@filter false
            if (filter.onlyGroupChats == false && msg.isGroupChat) return@filter false
            if (filter.selectedCategory != null && msg.category != filter.selectedCategory) return@filter false
            if (filter.selectedConversation != null && msg.conversationName != filter.selectedConversation) return@filter false
            if (filter.selectedSender != null && msg.senderName != filter.selectedSender) return@filter false
            if (cutoffTime > 0L && msg.notificationTimestamp < cutoffTime) return@filter false

            if (query.isNotEmpty()) {
                val matchesText = msg.messageText.lowercase().contains(query) ||
                    (msg.bigText?.lowercase()?.contains(query) == true) ||
                    msg.senderName.lowercase().contains(query) ||
                    msg.conversationName.lowercase().contains(query) ||
                    msg.notificationTitle.lowercase().contains(query)
                if (!matchesText) return@filter false
            }
            true
        }
    }

    suspend fun deleteMessage(id: Long) = withContext(Dispatchers.IO) {
        database.messageDao().deleteById(id)
    }

    suspend fun deleteDeletionEvent(id: Long) = withContext(Dispatchers.IO) {
        database.deletionEventDao().deleteById(id)
    }

    suspend fun deleteViewOnceEvent(id: Long) = withContext(Dispatchers.IO) {
        database.viewOnceDao().deleteById(id)
    }

    suspend fun deleteMediaRecord(id: Long) = withContext(Dispatchers.IO) {
        val record = database.normalMediaDao().getById(id)
        if (record != null) {
            runCatching { File(record.privateFilePath).delete() }
            database.normalMediaDao().deleteById(id)
        }
    }

    suspend fun clearCompleteArchive() = withContext(Dispatchers.IO) {
        database.messageDao().clearAll()
        database.deletionEventDao().clearAll()
        database.viewOnceDao().clearAll()
        database.normalMediaDao().clearAll()
        database.observationDao().clearAll()
        database.conversationDao().clearAll()
        database.diagnosticLogDao().clearAll()
        safMediaArchiver.deleteAllPrivateMediaFiles()
        statusTracker.resetMetrics()
    }

    suspend fun syncNormalMedia(): MediaSyncResult = safMediaArchiver.scanAndArchiveMedia()

    suspend fun exportArchiveToJson(destinationUri: Uri): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            val messages = database.messageDao().getAllMessagesSnapshot()
            val deletions = database.deletionEventDao().getAllSnapshot()
            val viewOnces = database.viewOnceDao().getAllSnapshot()
            val media = database.normalMediaDao().getAllSnapshot()

            val root = JSONObject().apply {
                put("app", "WA Message Archive Pro")
                put("exportedAtEpochMs", System.currentTimeMillis())
                put("packageScope", "com.whatsapp")

                put("messages", JSONArray().apply {
                    messages.forEach { m ->
                        put(JSONObject().apply {
                            put("id", m.id)
                            put("notificationKey", m.notificationKey)
                            put("notificationTitle", crypto.decrypt(m.encryptedNotificationTitle))
                            put("senderName", crypto.decrypt(m.encryptedSenderName))
                            put("conversationName", crypto.decrypt(m.encryptedConversationName))
                            put("isGroupChat", m.isGroupChat)
                            put("messageText", crypto.decrypt(m.encryptedMessageText))
                            put("bigText", crypto.decryptNullable(m.encryptedBigText) ?: JSONObject.NULL)
                            put("category", m.category.name)
                            put("notificationTimestamp", m.notificationTimestamp)
                            put("archivedAt", m.archivedAt)
                            put("isDeleted", m.isDeleted)
                            put("deletionDetectedAt", m.deletionDetectedAt ?: JSONObject.NULL)
                        })
                    }
                })

                put("deletionEvents", JSONArray().apply {
                    deletions.forEach { d ->
                        put(JSONObject().apply {
                            put("id", d.id)
                            put("senderName", crypto.decrypt(d.encryptedSenderName))
                            put("conversationName", crypto.decrypt(d.encryptedConversationName))
                            put("noticeText", crypto.decrypt(d.encryptedNoticeText))
                            put("detectedAt", d.detectedAt)
                            put("matchedMessageId", d.matchedMessageId ?: JSONObject.NULL)
                            put("matchConfidence", d.matchConfidence.name)
                            put("matchedOriginalText", crypto.decryptNullable(d.encryptedMatchedOriginalText) ?: JSONObject.NULL)
                        })
                    }
                })

                put("viewOnceEvents", JSONArray().apply {
                    viewOnces.forEach { v ->
                        put(JSONObject().apply {
                            put("id", v.id)
                            put("senderName", crypto.decrypt(v.encryptedSenderName))
                            put("conversationName", crypto.decrypt(v.encryptedConversationName))
                            put("isGroupChat", v.isGroupChat)
                            put("mediaKind", v.mediaKind.name)
                            put("rawNotice", crypto.decrypt(v.encryptedRawNotice))
                            put("notificationTimestamp", v.notificationTimestamp)
                            put("limitationNote", v.limitationNote)
                        })
                    }
                })

                put("archivedMedia", JSONArray().apply {
                    media.forEach { item ->
                        put(JSONObject().apply {
                            put("id", item.id)
                            put("originalFileName", item.originalFileName)
                            put("mediaType", item.mediaType.name)
                            put("mimeType", item.mimeType)
                            put("fileSizeBytes", item.fileSizeBytes)
                            put("senderAssociation", crypto.decryptNullable(item.encryptedSenderAssociation) ?: JSONObject.NULL)
                            put("fileLastModified", item.fileLastModified)
                            put("archivedAt", item.archivedAt)
                        })
                    }
                })
            }

            context.contentResolver.openOutputStream(destinationUri)?.use { out ->
                out.write(root.toString(2).toByteArray(Charsets.UTF_8))
            } ?: error("Unable to open output stream for JSON export.")

            messages.size + deletions.size + viewOnces.size + media.size
        }
    }
}
