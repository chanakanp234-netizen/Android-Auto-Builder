package com.firas.waarchive

import com.firas.waarchive.models.ViewOnceMediaKind
import com.firas.waarchive.notifications.WhatsAppNotificationParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WhatsAppNotificationParserTest {

    @Test
    fun detectsExplicitDeletionNotices() {
        assertTrue(WhatsAppNotificationParser.isExplicitDeletionNotice("This message was deleted"))
        assertTrue(WhatsAppNotificationParser.isExplicitDeletionNotice("You deleted this message"))
        assertFalse(WhatsAppNotificationParser.isExplicitDeletionNotice("Let's meet at 5pm"))
    }

    @Test
    fun detectsViewOnceMediaKindWhenExplicitlyExposed() {
        assertEquals(
            ViewOnceMediaKind.PHOTO,
            WhatsAppNotificationParser.detectViewOnceKind("📷 Photo (View once)", null)
        )
        assertEquals(
            ViewOnceMediaKind.VIDEO,
            WhatsAppNotificationParser.detectViewOnceKind("🎥 View once video", null)
        )
        assertNull(
            WhatsAppNotificationParser.detectViewOnceKind("📷 Photo", "image/jpeg")
        )
    }
}
