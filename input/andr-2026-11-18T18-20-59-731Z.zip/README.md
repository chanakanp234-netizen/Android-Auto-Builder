# WA Message Archive Pro

**Private, local, no-root WhatsApp notification and ordinary media archive for Android 13 (tested target: Infinix Smart 8 X6525 / XOS 13).**

## Core Capabilities

- **Automatic Notification Archiving (`NotificationListenerService`)**: Monitors `com.whatsapp` exclusively using Android's official `NotificationListenerService`. Captures `MessagingStyle` entries, `EXTRA_HISTORIC_MESSAGES`, `EXTRA_TEXT_LINES`, `EXTRA_BIG_TEXT`, sender/group metadata, notification keys, and timestamps immediately without overwriting earlier captured records.
- **Deleted Message Tracking**: Records explicit WhatsApp deletion notices (such as `"This message was deleted"`) separately from original messages and correlates them with previously archived messages by conversation, sender, and timestamp window. Dismissing a notification is never mistaken for message deletion.
- **View Once Event Metadata Archive**: Permanently logs View Once notifications when Android exposes View Once indicators (including photo vs video distinction when disclosed) alongside a clear explanation that official Android APIs cannot extract protected View Once media content.
- **Ordinary Media Archiving (Storage Access Framework)**: Optionally links a user-selected WhatsApp media directory via `ACTION_OPEN_DOCUMENT_TREE`, deduplicates files by SHA-256 hash, copies photos and videos losslessly into app-private storage, and associates senders only when a reliable match exists.
- **At-Rest Security**: Encrypts sensitive message text, sender names, conversation names, and notification previews with Android Keystore AES-256-GCM before storing in Room SQLite. Declares **no `INTERNET` permission**.
- **Export & Controls**: Dark Mode by default with Light Mode toggle, live search and multi-dimensional filtering, individual record deletion, full archive wipe, and offline JSON export via SAF.

## Honest Android Platform Limitations

- Messages received while a WhatsApp conversation is open on screen, muted, or with notification previews disabled do not emit readable notification payloads to `NotificationListenerService`.
- Protected View Once media cannot be retrieved without bypassing WhatsApp security; this app strictly avoids root, hooking, or sandbox circumvention.

## Build Instructions (`./gradlew assembleDebug`)

Designed for JDK 17 and compatible with [xtobi/Android-Auto-Builder](https://github.com/xtobi/Android-Auto-Builder):

```bash
chmod +x gradlew
./gradlew assembleDebug
```

Output debug APK path:
`app/build/outputs/apk/debug/app-debug.apk`

## Infinix Smart 8 (X6525) / XOS 13 Setup

1. Install the built APK on your Infinix Smart 8.
2. Open **WA Message Archive Pro** and tap **Enable Notification Access** -> toggle on **WA Message Archive Pro Listener**.
3. Open **App Info -> Battery** -> select **Unrestricted**.
4. In **Phone Master -> Auto-start management**, allow **WA Message Archive Pro**, and lock the app in the Recent Apps switcher.
5. Keep WhatsApp message previews enabled in **WhatsApp -> Settings -> Notifications**.
