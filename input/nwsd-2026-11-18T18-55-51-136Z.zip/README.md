# WA Message Archive Pro

**Private, local, no-root WhatsApp notification and ordinary media archive for Android 13 (target device: Infinix Smart 8 X6525 / XOS 13).**

## Core Capabilities

- **WhatsApp Notification Archiving (`NotificationListenerService`)**: Monitors `com.whatsapp` exclusively using Android's official `NotificationListenerService`. Extracts `NotificationCompat.MessagingStyle` entries, `EXTRA_HISTORIC_MESSAGES`, direct `Bundle` fallback arrays (safe on Android 13 API 33), `EXTRA_TEXT_LINES`, `EXTRA_BIG_TEXT`, `EXTRA_TEXT`, `CarExtender` fallback, sender/group metadata, and timestamps.
- **Anti-Delete Preservation**: Saves original message text immediately using `Mutex`-serialized Room writes and `OnConflictStrategy.IGNORE`. Explicit deletion notices (`"This message was deleted"`) are stored separately in `deletion_events` and matched to previously archived messages without ever overwriting the original message text. Dismissing a notification (`onNotificationRemoved`) is never treated as deletion.
- **Live Notification Diagnostics Screen**: Built-in per-notification audit log showing listener connection state, `com.whatsapp` identification, title, `EXTRA_TEXT` / `EXTRA_BIG_TEXT` / `MessagingStyle` extraction flags, database save outcome, and exact reasons when no message text was exposed. Stored locally; never logged to production Logcat.
- **View Once Honesty & Event Metadata**: Logs View Once events only when WhatsApp explicitly exposes a View Once marker, and clearly reports that original View Once photos/videos cannot be extracted via official Android APIs.
- **Ordinary Media Archiving (Storage Access Framework)**: Optionally links a user-selected WhatsApp media folder via `ACTION_OPEN_DOCUMENT_TREE`, deduplicates files by SHA-256 byte hash, and copies photos and videos losslessly into app-private storage.
- **At-Rest Security**: Encrypts archived text, sender names, conversation names, and titles via Android Keystore **AES-256-GCM**. Declares **no `INTERNET` permission**.

## Honest Platform Limitations

- Messages received while a WhatsApp chat is open on screen, muted, or with notification previews disabled do not emit message text to `NotificationListenerService`.
- Protected View Once media cannot be recovered without bypassing WhatsApp security; this application strictly uses official Android APIs without root, Xposed, or modified APKs.

## Build Instructions (`./gradlew assembleDebug`)

Designed for JDK 17 and compatible with [xtobi/Android-Auto-Builder](https://github.com/xtobi/Android-Auto-Builder):

```bash
chmod +x gradlew
./gradlew assembleDebug
```

Output debug APK path:
`app/build/outputs/apk/debug/app-debug.apk`

See `TEST_PLAN.md` for Tests A–E verification steps on Infinix Smart 8 (X6525 / XOS 13).
