package com.firas.waarchive.notifications

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.service.notification.NotificationListenerService
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.firas.waarchive.models.ListenerStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class ListenerStatusTracker(private val context: Context) {

    companion object {
        private const val PREFS_NAME = "wa_archive_listener_prefs"
        private const val KEY_LAST_CONNECTED_AT = "last_connected_at"
        private const val KEY_LAST_EVENT_AT = "last_event_at"
        private const val KEY_LAST_SUCCESS_AT = "last_success_at"
        private const val KEY_OBSERVED_COUNT = "observed_count"
    }

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _status = MutableStateFlow(loadInitialStatus())
    val status: StateFlow<ListenerStatus> = _status.asStateFlow()

    private fun loadInitialStatus(): ListenerStatus {
        val lastConn = prefs.getLong(KEY_LAST_CONNECTED_AT, 0L).takeIf { it > 0L }
        val lastEvt = prefs.getLong(KEY_LAST_EVENT_AT, 0L).takeIf { it > 0L }
        val lastSuccess = prefs.getLong(KEY_LAST_SUCCESS_AT, 0L).takeIf { it > 0L }
        val count = prefs.getInt(KEY_OBSERVED_COUNT, 0)
        return ListenerStatus(
            isPermissionGranted = isNotificationAccessEnabled(),
            isServiceConnected = false,
            isPostNotificationsGranted = isPostNotificationsEnabled(),
            lastConnectedAt = lastConn,
            lastEventAt = lastEvt,
            lastSuccessfulArchiveAt = lastSuccess,
            observedNotificationCount = count
        )
    }

    fun isNotificationAccessEnabled(): Boolean {
        val enabledPackages = NotificationManagerCompat.getEnabledListenerPackages(context)
        return enabledPackages.contains(context.packageName)
    }

    fun isPostNotificationsEnabled(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun refreshPermissionState() {
        val granted = isNotificationAccessEnabled()
        val postGranted = isPostNotificationsEnabled()
        _status.update { current ->
            current.copy(
                isPermissionGranted = granted,
                isPostNotificationsGranted = postGranted,
                isServiceConnected = if (!granted) false else current.isServiceConnected
            )
        }
    }

    fun requestServiceRebindIfPermitted() {
        if (!isNotificationAccessEnabled()) return
        runCatching {
            NotificationListenerService.requestRebind(
                ComponentName(context, WaNotificationListenerService::class.java)
            )
        }
    }

    fun onServiceConnected() {
        val now = System.currentTimeMillis()
        prefs.edit().putLong(KEY_LAST_CONNECTED_AT, now).apply()
        _status.update {
            it.copy(
                isPermissionGranted = isNotificationAccessEnabled(),
                isPostNotificationsGranted = isPostNotificationsEnabled(),
                isServiceConnected = true,
                lastConnectedAt = now
            )
        }
    }

    fun onServiceDisconnected() {
        _status.update {
            it.copy(
                isPermissionGranted = isNotificationAccessEnabled(),
                isPostNotificationsGranted = isPostNotificationsEnabled(),
                isServiceConnected = false
            )
        }
    }

    fun recordObservedEvent(archivedNewRecord: Boolean) {
        val now = System.currentTimeMillis()
        val nextCount = (_status.value.observedNotificationCount) + 1
        prefs.edit().apply {
            putLong(KEY_LAST_EVENT_AT, now)
            putInt(KEY_OBSERVED_COUNT, nextCount)
            if (archivedNewRecord) {
                putLong(KEY_LAST_SUCCESS_AT, now)
            }
            apply()
        }
        _status.update {
            it.copy(
                isPermissionGranted = isNotificationAccessEnabled(),
                isPostNotificationsGranted = isPostNotificationsEnabled(),
                isServiceConnected = true,
                lastEventAt = now,
                lastSuccessfulArchiveAt = if (archivedNewRecord) now else it.lastSuccessfulArchiveAt,
                observedNotificationCount = nextCount
            )
        }
    }

    fun resetMetrics() {
        prefs.edit()
            .remove(KEY_LAST_EVENT_AT)
            .remove(KEY_LAST_SUCCESS_AT)
            .putInt(KEY_OBSERVED_COUNT, 0)
            .apply()
        _status.update {
            it.copy(
                lastEventAt = null,
                lastSuccessfulArchiveAt = null,
                observedNotificationCount = 0
            )
        }
    }
}
