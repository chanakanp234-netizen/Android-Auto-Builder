package com.firas.waarchive.database

import androidx.room.TypeConverter
import com.firas.waarchive.models.DeletionMatchConfidence
import com.firas.waarchive.models.MediaType
import com.firas.waarchive.models.MessageCategory
import com.firas.waarchive.models.NotificationDiagnosticStatus
import com.firas.waarchive.models.ViewOnceMediaKind

class Converters {

    @TypeConverter
    fun fromMessageCategory(value: MessageCategory): String = value.name

    @TypeConverter
    fun toMessageCategory(value: String): MessageCategory =
        runCatching { MessageCategory.valueOf(value) }.getOrDefault(MessageCategory.TEXT)

    @TypeConverter
    fun fromMediaType(value: MediaType): String = value.name

    @TypeConverter
    fun toMediaType(value: String): MediaType =
        runCatching { MediaType.valueOf(value) }.getOrDefault(MediaType.PHOTO)

    @TypeConverter
    fun fromViewOnceMediaKind(value: ViewOnceMediaKind): String = value.name

    @TypeConverter
    fun toViewOnceMediaKind(value: String): ViewOnceMediaKind =
        runCatching { ViewOnceMediaKind.valueOf(value) }.getOrDefault(ViewOnceMediaKind.UNKNOWN)

    @TypeConverter
    fun fromDeletionMatchConfidence(value: DeletionMatchConfidence): String = value.name

    @TypeConverter
    fun toDeletionMatchConfidence(value: String): DeletionMatchConfidence =
        runCatching { DeletionMatchConfidence.valueOf(value) }.getOrDefault(DeletionMatchConfidence.UNMATCHED)

    @TypeConverter
    fun fromDiagnosticStatus(value: NotificationDiagnosticStatus): String = value.name

    @TypeConverter
    fun toDiagnosticStatus(value: String): NotificationDiagnosticStatus =
        runCatching { NotificationDiagnosticStatus.valueOf(value) }
            .getOrDefault(NotificationDiagnosticStatus.NOTIFICATION_RECEIVED)
}
