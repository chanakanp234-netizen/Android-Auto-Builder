package com.firas.waarchive.archive

import com.firas.waarchive.database.WaArchiveDatabase
import com.firas.waarchive.database.entity.AppLogEntity
import com.firas.waarchive.database.entity.ArchivedMessageEntity
import com.firas.waarchive.database.entity.ConversationMetadataEntity
import com.firas.waarchive.database.entity.DeletionEventEntity
import com.firas.waarchive.database.entity.NotificationDiagnosticEntity
import com.firas.waarchive.database.entity.NotificationObservationEntity
import com.firas.waarchive.database.entity.ViewOnceEventEntity
import com.firas.waarchive.models.DeletionMatchConfidence
import com.firas.waarchive.models.NotificationDiagnosticStatus
import com.firas.waarchive.models.ViewOnceMediaKind
import com.firas.waarchive.notifications.ListenerStatusTracker
import com.firas.waarchive.notifications.ParsedMessageEntry
import com.firas.waarchive.notifications.ParsedNotificationPayload
import com.firas.waarchive.notifications.WhatsAppNotificationParser
import com.firas.waarchive.security.KeystoreCryptoManager
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.Locale
import kotlin.math.abs

class ArchiveProcessor(
    private val database: WaArchiveDatabase,
    private val crypto: KeystoreCryptoManager,
    private val statusTracker: ListenerStatusTracker
) {

    companion object {
        private const val DELETION_CORRELATION_WINDOW_MS = 48L * 60L * 60L * 1000L
        private const val EXACT_TIMESTAMP_MATCH_WINDOW_MS = 3_000L
        private const val VIEW_ONCE_LIMITATION_NOTE =
            "Metadata captured from notification. Original View Once photo/video is protected by WhatsApp and cannot be extracted via official Android NotificationListenerService APIs."
    }

    private val processingMutex = Mutex()

    suspend fun processPostedNotification(payload: ParsedNotificationPayload) = processingMutex.withLock {
        val now = System.currentTimeMillis()
        var savedRecordsCount = 0
        var hasDeletionEvent = false
        var hasViewOnceEvent = false

        try {
            val obsHash = crypto.sha256(
                "POSTED|${payload.notificationKey}|${payload.postTime}|${payload.extrasSnapshot}"
            )
            database.observationDao().insertIgnore(
                NotificationObservationEntity(
                    observationHash = obsHash,
                    notificationKey = payload.notificationKey,
                    notificationId = payload.notificationId,
                    eventType = "POSTED",
                    postTime = payload.postTime,
                    observedAt = now,
                    entryCount = payload.entries.size,
                    isMessagingStyle = payload.isMessagingStyle,
                    isSummaryNotification = payload.isSummaryNotification,
                    encryptedExtrasSnapshot = crypto.encrypt(payload.extrasSnapshot)
                )
            )

            for (entry in payload.entries) {
                val convKey = buildConversationKey(entry.conversationName)
                when {
                    entry.isDeletionNotice -> {
                        val inserted = handleDeletionEntry(payload, entry, convKey)
                        if (inserted) {
                            savedRecordsCount++
                            hasDeletionEvent = true
                        }
                    }
                    entry.isViewOnceEvent -> {
                        val inserted = handleViewOnceEntry(payload, entry, convKey, now)
                        if (inserted) {
                            savedRecordsCount++
                            hasViewOnceEvent = true
                        }
                    }
                    else -> {
                        val inserted = handleNormalMessageEntry(payload, entry, convKey, now)
                        if (inserted) savedRecordsCount++
                    }
                }
            }

            val diagStatus = when {
                payload.entries.isEmpty() -> NotificationDiagnosticStatus.NO_MESSAGE_TEXT_EXPOSED
                hasViewOnceEvent -> NotificationDiagnosticStatus.VIEW_ONCE_IDENTIFIED
                hasDeletionEvent && savedRecordsCount > 0 -> NotificationDiagnosticStatus.DELETION_NOTICE_RECORDED
                payload.possibleMediaWithoutViewOnceFlag && savedRecordsCount > 0 -> NotificationDiagnosticStatus.POSSIBLE_MEDIA_NOTIFICATION
                savedRecordsCount > 0 -> NotificationDiagnosticStatus.MESSAGE_SAVED_SUCCESSFULLY
                else -> NotificationDiagnosticStatus.MESSAGE_TEXT_EXTRACTED
            }

            val reason = when {
                payload.entries.isEmpty() ->
                    payload.noTextReason ?: "No extractable message text was exposed in this notification."
                hasViewOnceEvent ->
                    "Explicit View Once metadata recorded ($savedRecordsCount new). Original media bytes are unavailable via Android APIs."
                hasDeletionEvent && savedRecordsCount > 0 ->
                    "WhatsApp deletion notice recorded and correlated against previously archived messages."
                payload.possibleMediaWithoutViewOnceFlag && savedRecordsCount > 0 ->
                    "Media notification placeholder saved ($savedRecordsCount new). WhatsApp did not explicitly expose whether it was ordinary or View Once."
                savedRecordsCount > 0 ->
                    "Extracted ${payload.entries.size} message(s) and saved $savedRecordsCount new record(s) to encrypted Room DB."
                else ->
                    "Extracted ${payload.entries.size} message(s); all were already archived (deduplicated safely)."
            }

            insertDiagnosticRecord(
                payload = payload,
                now = now,
                dbSuccess = true,
                savedCount = savedRecordsCount,
                status = diagStatus,
                reason = reason
            )

            statusTracker.recordObservedEvent(savedRecordsCount > 0)
        } catch (err: Exception) {
            runCatching {
                insertDiagnosticRecord(
                    payload = payload,
                    now = now,
                    dbSuccess = false,
                    savedCount = savedRecordsCount,
                    status = NotificationDiagnosticStatus.DATABASE_SAVE_FAILED,
                    reason = "Database/Crypto write error: ${err.javaClass.simpleName}"
                )
            }
            throw err
        }
    }

    suspend fun recordNotificationRemoved(notificationKey: String, notificationId: Int, postTime: Long, reason: Int) =
        processingMutex.withLock {
            val now = System.currentTimeMillis()
            val obsHash = crypto.sha256("REMOVED|$notificationKey|$postTime|$reason|$now")
            database.observationDao().insertIgnore(
                NotificationObservationEntity(
                    observationHash = obsHash,
                    notificationKey = notificationKey,
                    notificationId = notificationId,
                    eventType = "REMOVED_REASON_$reason",
                    postTime = postTime,
                    observedAt = now,
                    entryCount = 0,
                    isMessagingStyle = false,
                    isSummaryNotification = false,
                    encryptedExtrasSnapshot = crypto.encrypt("Notification dismissed/removed (reason=$reason); archived messages preserved.")
                )
            )
        }

    suspend fun logSafeDiagnostic(level: String, tag: String, messageWithoutPii: String) {
        database.diagnosticLogDao().insert(
            AppLogEntity(
                timestamp = System.currentTimeMillis(),
                level = level,
                tag = tag,
                message = messageWithoutPii
            )
        )
        database.diagnosticLogDao().trimOldLogs()
    }

    private suspend fun insertDiagnosticRecord(
        payload: ParsedNotificationPayload,
        now: Long,
        dbSuccess: Boolean,
        savedCount: Int,
        status: NotificationDiagnosticStatus,
        reason: String
    ) {
        database.notificationDiagnosticDao().insert(
            NotificationDiagnosticEntity(
                timestamp = now,
                sourcePackage = payload.sourcePackage,
                isWhatsAppPackage = payload.sourcePackage == WhatsAppNotificationParser.WHATSAPP_PACKAGE,
                notificationKey = payload.notificationKey,
                notificationId = payload.notificationId,
                isGroupSummary = payload.isSummaryNotification,
                encryptedNotificationTitle = crypto.encrypt(payload.notificationTitle),
                hasExtraText = payload.hasExtraText,
                hasExtraBigText = payload.hasExtraBigText,
                hasExtraTextLines = payload.hasExtraTextLines,
                messagingStyleCount = payload.messagingStyleCount,
                extractedTextCount = payload.entries.size,
                databaseSaveSucceeded = dbSuccess,
                savedRecordCount = savedCount,
                status = status,
                reasonDetail = reason
            )
        )
        database.notificationDiagnosticDao().trimOldEntries()
    }

    private suspend fun handleNormalMessageEntry(
        payload: ParsedNotificationPayload,
        entry: ParsedMessageEntry,
        convKey: String,
        now: Long
    ): Boolean {
        val normalizedBody = entry.messageText.trim().lowercase(Locale.ROOT)
        val dedupHash = crypto.sha256(
            "MSG|$convKey|${entry.senderName.trim().lowercase(Locale.ROOT)}|${entry.timestamp}|${entry.occurrenceIndex}|$normalizedBody"
        )

        val entity = ArchivedMessageEntity(
            dedupHash = dedupHash,
            notificationKey = payload.notificationKey,
            notificationId = payload.notificationId,
            conversationKey = convKey,
            encryptedNotificationTitle = crypto.encrypt(payload.notificationTitle),
            encryptedSenderName = crypto.encrypt(entry.senderName),
            encryptedConversationName = crypto.encrypt(entry.conversationName),
            isGroupChat = entry.isGroupChat,
            encryptedMessageText = crypto.encrypt(entry.messageText),
            encryptedBigText = crypto.encryptNullable(entry.bigText),
            category = entry.category,
            notificationTimestamp = entry.timestamp,
            archivedAt = now,
            isDeleted = false,
            linkedDeletionEventId = null,
            deletionDetectedAt = null,
            sourcePackage = WhatsAppNotificationParser.WHATSAPP_PACKAGE
        )

        val insertedId = database.messageDao().insertIgnore(entity)
        if (insertedId > 0L) {
            updateConversationMetadata(
                convKey = convKey,
                displayName = entry.conversationName,
                isGroup = entry.isGroupChat,
                timestamp = entry.timestamp,
                deltaMessages = 1
            )
            return true
        }
        return false
    }

    private suspend fun handleDeletionEntry(
        payload: ParsedNotificationPayload,
        entry: ParsedMessageEntry,
        convKey: String
    ): Boolean {
        val dedupHash = crypto.sha256(
            "DEL|$convKey|${entry.senderName.trim().lowercase(Locale.ROOT)}|${entry.timestamp}|${entry.occurrenceIndex}|${entry.messageText.trim().lowercase(Locale.ROOT)}"
        )

        val candidates = database.messageDao().findCandidateMatchesForDeletion(
            conversationKey = convKey,
            beforeTimestamp = entry.timestamp + EXACT_TIMESTAMP_MATCH_WINDOW_MS,
            afterTimestamp = entry.timestamp - DELETION_CORRELATION_WINDOW_MS
        )

        var matchedEntity: ArchivedMessageEntity? = null
        var confidence = DeletionMatchConfidence.UNMATCHED

        if (candidates.isNotEmpty()) {
            val senderNormalized = entry.senderName.trim().lowercase(Locale.ROOT)

            // 1. Exact/near timestamp match with same sender (best for MessagingStyle multi-message stacks)
            val exactTimeSameSender = candidates.firstOrNull { candidate ->
                abs(candidate.notificationTimestamp - entry.timestamp) <= EXACT_TIMESTAMP_MATCH_WINDOW_MS &&
                    crypto.decrypt(candidate.encryptedSenderName).trim().lowercase(Locale.ROOT) == senderNormalized
            }
            // 2. Exact/near timestamp match in same conversation
            val exactTimeConv = candidates.firstOrNull { candidate ->
                abs(candidate.notificationTimestamp - entry.timestamp) <= EXACT_TIMESTAMP_MATCH_WINDOW_MS
            }
            // 3. Same notificationKey + same sender
            val sameKeySameSender = candidates.firstOrNull { candidate ->
                candidate.notificationKey == payload.notificationKey &&
                    crypto.decrypt(candidate.encryptedSenderName).trim().lowercase(Locale.ROOT) == senderNormalized
            }
            // 4. Same sender in same conversation within 48h
            val sameSenderMatch = candidates.firstOrNull { candidate ->
                crypto.decrypt(candidate.encryptedSenderName).trim().lowercase(Locale.ROOT) == senderNormalized
            }

            when {
                exactTimeSameSender != null -> {
                    matchedEntity = exactTimeSameSender
                    confidence = DeletionMatchConfidence.HIGH
                }
                sameKeySameSender != null -> {
                    matchedEntity = sameKeySameSender
                    confidence = DeletionMatchConfidence.HIGH
                }
                sameSenderMatch != null -> {
                    matchedEntity = sameSenderMatch
                    confidence = DeletionMatchConfidence.HIGH
                }
                exactTimeConv != null -> {
                    matchedEntity = exactTimeConv
                    confidence = DeletionMatchConfidence.MEDIUM
                }
                else -> {
                    // Fallback when WhatsApp replaces group sender with group title on deletion notice
                    matchedEntity = candidates.first()
                    confidence = DeletionMatchConfidence.MEDIUM
                }
            }
        }

        val matchedOriginalPlain = matchedEntity?.let { crypto.decrypt(it.encryptedMessageText) }

        val deletionEntity = DeletionEventEntity(
            dedupHash = dedupHash,
            notificationKey = payload.notificationKey,
            conversationKey = convKey,
            encryptedSenderName = crypto.encrypt(entry.senderName),
            encryptedConversationName = crypto.encrypt(entry.conversationName),
            encryptedNoticeText = crypto.encrypt(entry.messageText),
            detectedAt = entry.timestamp,
            matchedMessageId = matchedEntity?.id,
            matchConfidence = confidence,
            encryptedMatchedOriginalText = crypto.encryptNullable(matchedOriginalPlain)
        )

        val deletionId = database.deletionEventDao().insertIgnore(deletionEntity)
        if (deletionId > 0L) {
            if (matchedEntity != null) {
                database.messageDao().markAsDeletedPreservingText(
                    messageId = matchedEntity.id,
                    deletionEventId = deletionId,
                    detectedAt = entry.timestamp
                )
            }
            updateConversationMetadata(
                convKey = convKey,
                displayName = entry.conversationName,
                isGroup = entry.isGroupChat,
                timestamp = entry.timestamp,
                deltaDeleted = 1
            )
            return true
        }
        return false
    }

    private suspend fun handleViewOnceEntry(
        payload: ParsedNotificationPayload,
        entry: ParsedMessageEntry,
        convKey: String,
        now: Long
    ): Boolean {
        val mediaKind = entry.viewOnceMediaKind ?: ViewOnceMediaKind.UNKNOWN
        val dedupHash = crypto.sha256(
            "VO|$convKey|${entry.senderName.trim().lowercase(Locale.ROOT)}|${entry.timestamp}|${entry.occurrenceIndex}|${mediaKind.name}|${entry.messageText.trim().lowercase(Locale.ROOT)}"
        )

        val viewOnceEntity = ViewOnceEventEntity(
            dedupHash = dedupHash,
            notificationKey = payload.notificationKey,
            encryptedSenderName = crypto.encrypt(entry.senderName),
            encryptedConversationName = crypto.encrypt(entry.conversationName),
            isGroupChat = entry.isGroupChat,
            mediaKind = mediaKind,
            encryptedRawNotice = crypto.encrypt(entry.messageText),
            notificationTimestamp = entry.timestamp,
            archivedAt = now,
            isMediaContentAvailable = false,
            limitationNote = VIEW_ONCE_LIMITATION_NOTE
        )

        val insertedId = database.viewOnceDao().insertIgnore(viewOnceEntity)
        if (insertedId > 0L) {
            updateConversationMetadata(
                convKey = convKey,
                displayName = entry.conversationName,
                isGroup = entry.isGroupChat,
                timestamp = entry.timestamp,
                deltaViewOnce = 1
            )
            return true
        }
        return false
    }

    private suspend fun updateConversationMetadata(
        convKey: String,
        displayName: String,
        isGroup: Boolean,
        timestamp: Long,
        deltaMessages: Int = 0,
        deltaDeleted: Int = 0,
        deltaViewOnce: Int = 0
    ) {
        val existing = database.conversationDao().getByKey(convKey)
        val updated = if (existing == null) {
            ConversationMetadataEntity(
                conversationKey = convKey,
                encryptedDisplayName = crypto.encrypt(displayName),
                isGroup = isGroup,
                messageCount = deltaMessages,
                lastMessageAt = timestamp,
                deletedCount = deltaDeleted,
                viewOnceCount = deltaViewOnce
            )
        } else {
            existing.copy(
                isGroup = existing.isGroup || isGroup,
                messageCount = existing.messageCount + deltaMessages,
                lastMessageAt = maxOf(existing.lastMessageAt, timestamp),
                deletedCount = existing.deletedCount + deltaDeleted,
                viewOnceCount = existing.viewOnceCount + deltaViewOnce
            )
        }
        database.conversationDao().upsert(updated)
    }

    private fun buildConversationKey(conversationName: String): String {
        val normalized = conversationName.trim().lowercase(Locale.ROOT).ifBlank { "whatsapp_chat" }
        return crypto.sha256("CONV|$normalized")
    }
}
