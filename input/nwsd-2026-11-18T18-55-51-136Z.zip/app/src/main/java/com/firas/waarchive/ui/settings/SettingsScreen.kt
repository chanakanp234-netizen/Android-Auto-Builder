package com.firas.waarchive.ui.settings

import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.FactCheck
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.firas.waarchive.models.DiagnosticLogUi
import com.firas.waarchive.models.ListenerStatus
import com.firas.waarchive.ui.components.formatShortTime
import com.firas.waarchive.ui.theme.AmberWarning
import com.firas.waarchive.ui.theme.CrimsonDeleted
import com.firas.waarchive.ui.theme.EmeraldPrimary
import com.firas.waarchive.ui.theme.SkyMedia

@Composable
fun SettingsScreen(
    isDarkMode: Boolean,
    listenerStatus: ListenerStatus,
    safTreeUri: Uri?,
    diagnosticLogs: List<DiagnosticLogUi>,
    onToggleDarkMode: (Boolean) -> Unit,
    onOpenNotificationAccessSettings: () -> Unit,
    onOpenAppBatterySettings: () -> Unit,
    onRequestPostNotifications: () -> Unit,
    onOpenDiagnostics: () -> Unit,
    onSelectSafFolder: () -> Unit,
    onUnlinkSafFolder: () -> Unit,
    onExportJson: () -> Unit,
    onClearCompleteArchive: () -> Unit
) {
    var showClearConfirmDialog by remember { mutableStateOf(false) }
    var showLogsExpanded by remember { mutableStateOf(false) }
    var showXosGuideExpanded by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Appearance
        item {
            SettingsSectionCard(title = "Appearance") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isDarkMode) Icons.Rounded.DarkMode else Icons.Rounded.LightMode,
                            contentDescription = null,
                            tint = EmeraldPrimary
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Dark Mode", style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = if (isDarkMode) "Dark theme active (Default)" else "Light theme active",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Switch(
                        checked = isDarkMode,
                        onCheckedChange = onToggleDarkMode
                    )
                }
            }
        }

        // 2. Permissions & Access
        item {
            SettingsSectionCard(title = "Permissions & Background Access") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Special Notification Access (Required)", style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = if (listenerStatus.isPermissionGranted) {
                                    if (listenerStatus.isServiceConnected) "Granted · Service Connected"
                                    else "Granted · Waiting for OS bind"
                                } else {
                                    "Disabled · Required to read com.whatsapp notifications"
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (listenerStatus.isPermissionGranted) EmeraldPrimary else CrimsonDeleted
                            )
                        }
                        OutlinedButton(onClick = onOpenNotificationAccessSettings) {
                            Icon(Icons.Rounded.NotificationsActive, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Open")
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("POST_NOTIFICATIONS (Optional App Alerts)", style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = if (listenerStatus.isPostNotificationsGranted) {
                                    "Granted (Separate from Notification Access)"
                                } else {
                                    "Not granted · Only affects this app's own alerts"
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        OutlinedButton(onClick = onRequestPostNotifications) {
                            Text(if (listenerStatus.isPostNotificationsGranted) "Granted" else "Grant")
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Ordinary Media Folder (SAF)", style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = safTreeUri?.lastPathSegment ?: "Not configured",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            if (safTreeUri != null) {
                                TextButton(onClick = onUnlinkSafFolder) {
                                    Text("Unlink")
                                }
                            }
                            OutlinedButton(onClick = onSelectSafFolder) {
                                Icon(Icons.Rounded.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (safTreeUri == null) "Pick" else "Change")
                            }
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))

                    Button(
                        onClick = onOpenDiagnostics,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.FactCheck, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Open Live Notification Diagnostics")
                    }
                }
            }
        }

        // 3. Infinix Smart 8 (X6525) / XOS 13 Guide
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, AmberWarning.copy(alpha = 0.45f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showXosGuideExpanded = !showXosGuideExpanded },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(
                                imageVector = Icons.Rounded.BatteryChargingFull,
                                contentDescription = null,
                                tint = AmberWarning
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Infinix Smart 8 (X6525) Setup Guide",
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                        Icon(
                            imageVector = if (showXosGuideExpanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                            contentDescription = null
                        )
                    }

                    if (showXosGuideExpanded) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "XOS 13 aggressively freezes background apps. Complete these steps on your Infinix X6525 to keep NotificationListenerService active:",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        GuideStep("1. Special Notification Access", "Settings > Apps > Special app access > Notification access > Enable WA Message Archive Pro Listener. (This is separate from standard Notification permissions.)")
                        GuideStep("2. Unrestricted Battery Usage", "Open App Info > Battery > select Unrestricted (never Optimized or Restricted).")
                        GuideStep("3. Disable XOS App Freeze & Allow Auto-Start", "Open Phone Master > App Management > Auto-start management > Allow WA Message Archive Pro, and exclude it from Power Boost / Battery Lab cleanup.")
                        GuideStep("4. Lock in Recent Apps", "Open Recent Apps switcher, tap the menu on WA Message Archive Pro, and tap Lock.")
                        GuideStep("5. Enable WhatsApp Previews", "In WhatsApp > Settings > Notifications, keep notifications enabled and ensure message preview text is visible (not hidden by app lock).")
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = onOpenAppBatterySettings,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Open App Info & Battery Settings")
                        }
                    }
                }
            }
        }

        // 4. Data Export & Archive Management
        item {
            SettingsSectionCard(title = "Archive Data & Export") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = onExportJson,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.FileDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Export Complete Archive to JSON")
                    }

                    OutlinedButton(
                        onClick = { showClearConfirmDialog = true },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CrimsonDeleted),
                        border = BorderStroke(1.dp, CrimsonDeleted.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.DeleteSweep, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Clear Complete Archive")
                    }
                }
            }
        }

        // 5. Security & Privacy Architecture
        item {
            SettingsSectionCard(title = "Security & Privacy Architecture") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Lock, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("AES-256-GCM Hardware-Backed Encryption", style = MaterialTheme.typography.titleMedium)
                    }
                    Text(
                        text = "Archived message text, sender names, conversation names, and notification titles are encrypted at rest using Android Keystore before insertion into Room SQLite.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Shield, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Zero Network Access (No INTERNET Permission)", style = MaterialTheme.typography.titleMedium)
                    }
                    Text(
                        text = "This application declares no INTERNET permission in AndroidManifest.xml and never logs message content to Logcat.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // 6. Service Lifecycle Logs
        item {
            SettingsSectionCard(title = "Service Lifecycle Logs") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showLogsExpanded = !showLogsExpanded },
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${diagnosticLogs.size} non-sensitive lifecycle entries",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Icon(
                        imageVector = if (showLogsExpanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                        contentDescription = null
                    )
                }
                if (showLogsExpanded) {
                    Spacer(modifier = Modifier.height(8.dp))
                    if (diagnosticLogs.isEmpty()) {
                        Text(
                            text = "No service lifecycle logs recorded yet.",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            diagnosticLogs.take(25).forEach { log ->
                                Text(
                                    text = "[${formatShortTime(log.timestamp)}] ${log.level}/${log.tag}: ${log.message}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showClearConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showClearConfirmDialog = false },
            title = { Text("Clear Complete Local Archive?") },
            text = {
                Text(
                    "This permanently deletes all archived messages, deletion records, View Once events, copied ordinary media files, and diagnostic logs from this device. This action cannot be undone."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showClearConfirmDialog = false
                        onClearCompleteArchive()
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = CrimsonDeleted)
                ) {
                    Text("Delete Everything")
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirmDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun SettingsSectionCard(
    title: String,
    content: @Composable () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun GuideStep(title: String, detail: String) {
    Column(modifier = Modifier.padding(bottom = 8.dp)) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = detail,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
