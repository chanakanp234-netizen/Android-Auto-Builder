package com.firas.waarchive.notifications

import android.content.ComponentName
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.firas.waarchive.WaArchiveApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class WaNotificationListenerService : NotificationListenerService() {

    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(serviceJob + Dispatchers.IO)

    private val app: WaArchiveApplication
        get() = application as WaArchiveApplication

    override fun onCreate() {
        super.onCreate()
        if (app.listenerStatusTracker.isNotificationAccessEnabled()) {
            app.listenerStatusTracker.refreshPermissionState()
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        app.listenerStatusTracker.onServiceConnected()
        serviceScope.launch {
            app.archiveProcessor.logSafeDiagnostic(
                level = "INFO",
                tag = "ListenerService",
                messageWithoutPii = "NotificationListenerService connected and monitoring com.whatsapp"
            )
        }
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        app.listenerStatusTracker.onServiceDisconnected()
        serviceScope.launch {
            app.archiveProcessor.logSafeDiagnostic(
                level = "WARN",
                tag = "ListenerService",
                messageWithoutPii = "NotificationListenerService disconnected; requesting rebind"
            )
        }
        runCatching {
            requestRebind(ComponentName(this, WaNotificationListenerService::class.java))
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null || sbn.packageName != WhatsAppNotificationParser.WHATSAPP_PACKAGE) {
            return
        }

        // Connected callback may be missed if service stayed bound across UI restart
        if (!app.listenerStatusTracker.status.value.isServiceConnected) {
            app.listenerStatusTracker.onServiceConnected()
        }

        val parsed = runCatching { WhatsAppNotificationParser.parse(sbn) }
            .onFailure { err ->
                serviceScope.launch {
                    app.archiveProcessor.logSafeDiagnostic(
                        level = "ERROR",
                        tag = "Parser",
                        messageWithoutPii = "Notification parse failure: ${err.javaClass.simpleName}"
                    )
                }
            }
            .getOrNull() ?: return

        serviceScope.launch {
            runCatching {
                app.archiveProcessor.processPostedNotification(parsed)
            }.onFailure { err ->
                app.archiveProcessor.logSafeDiagnostic(
                    level = "ERROR",
                    tag = "ArchiveProcessor",
                    messageWithoutPii = "Archive write error: ${err.javaClass.simpleName}"
                )
            }
        }
    }

    override fun onNotificationRemoved(
        sbn: StatusBarNotification?,
        rankingMap: RankingMap?,
        reason: Int
    ) {
        if (sbn == null || sbn.packageName != WhatsAppNotificationParser.WHATSAPP_PACKAGE) {
            return
        }
        val key = sbn.key
        val id = sbn.id
        val postTime = sbn.postTime
        serviceScope.launch {
            runCatching {
                app.archiveProcessor.recordNotificationRemoved(key, id, postTime, reason)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }
}
