package com.firas.waarchive.ui.navigation

import android.net.Uri
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.FactCheck
import androidx.compose.material.icons.rounded.Forum
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.firas.waarchive.ui.MainViewModel
import com.firas.waarchive.ui.dashboard.DashboardScreen
import com.firas.waarchive.ui.deleted.DeletedMessagesScreen
import com.firas.waarchive.ui.diagnostics.DiagnosticsScreen
import com.firas.waarchive.ui.media.MediaArchiveScreen
import com.firas.waarchive.ui.messages.AllMessagesScreen
import com.firas.waarchive.ui.settings.SettingsScreen
import com.firas.waarchive.ui.viewonce.ViewOnceScreen

sealed class ArchiveDestination(
    val route: String,
    val title: String,
    val shortLabel: String,
    val icon: ImageVector
) {
    data object Dashboard : ArchiveDestination("dashboard", "WA Message Archive Pro", "Home", Icons.Rounded.Dashboard)
    data object Messages : ArchiveDestination("messages", "All Messages", "Messages", Icons.Rounded.Forum)
    data object Deleted : ArchiveDestination("deleted", "Deleted Messages", "Deleted", Icons.Rounded.DeleteSweep)
    data object ViewOnce : ArchiveDestination("viewonce", "View Once Events", "Once", Icons.Rounded.VisibilityOff)
    data object Media : ArchiveDestination("media", "Photos & Videos", "Media", Icons.Rounded.PhotoLibrary)
    data object Settings : ArchiveDestination("settings", "Settings & Device Guide", "Settings", Icons.Rounded.Settings)
    data object Diagnostics : ArchiveDestination("diagnostics", "Notification Diagnostics", "Diag", Icons.Rounded.FactCheck)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArchiveAppShell(
    viewModel: MainViewModel,
    onOpenNotificationAccessSettings: () -> Unit,
    onOpenAppBatterySettings: () -> Unit,
    onRequestPostNotifications: () -> Unit,
    onLaunchSafFolderPicker: () -> Unit,
    onLaunchJsonExportPicker: () -> Unit
) {
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }

    val listenerStatus by viewModel.listenerStatus.collectAsStateWithLifecycle()
    val stats by viewModel.dashboardStats.collectAsStateWithLifecycle()
    val allMessages by viewModel.allMessages.collectAsStateWithLifecycle()
    val filteredMessages by viewModel.filteredMessages.collectAsStateWithLifecycle()
    val filterState by viewModel.filterState.collectAsStateWithLifecycle()
    val deletionEvents by viewModel.deletionEvents.collectAsStateWithLifecycle()
    val viewOnceEvents by viewModel.viewOnceEvents.collectAsStateWithLifecycle()
    val normalMedia by viewModel.normalMedia.collectAsStateWithLifecycle()
    val safTreeUri: Uri? by viewModel.safTreeUri.collectAsStateWithLifecycle()
    val lastMediaSyncAt by viewModel.lastMediaSyncAt.collectAsStateWithLifecycle()
    val isSyncingMedia by viewModel.isSyncingMedia.collectAsStateWithLifecycle()
    val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
    val diagnosticLogs by viewModel.diagnosticLogs.collectAsStateWithLifecycle()
    val notificationDiagnostics by viewModel.notificationDiagnostics.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        viewModel.snackbarMessage.collect { message ->
            snackbarHostState.showSnackbar(message)
        }
    }

    val bottomDestinations = remember {
        listOf(
            ArchiveDestination.Dashboard,
            ArchiveDestination.Messages,
            ArchiveDestination.Deleted,
            ArchiveDestination.ViewOnce,
            ArchiveDestination.Media,
            ArchiveDestination.Settings
        )
    }

    val allDestinations = remember {
        bottomDestinations + ArchiveDestination.Diagnostics
    }

    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination
    val currentScreen = allDestinations.firstOrNull { dest ->
        currentDestination?.hierarchy?.any { it.route == dest.route } == true
    } ?: ArchiveDestination.Dashboard

    fun navigateTo(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = currentScreen.title,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                actions = {
                    IconButton(onClick = { navigateTo(ArchiveDestination.Diagnostics.route) }) {
                        Icon(
                            imageVector = Icons.Rounded.FactCheck,
                            contentDescription = "Notification Diagnostics",
                            tint = if (currentScreen == ArchiveDestination.Diagnostics) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            }
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                bottomDestinations.forEach { dest ->
                    val selected = currentDestination?.hierarchy?.any { it.route == dest.route } == true
                    NavigationBarItem(
                        selected = selected,
                        onClick = { navigateTo(dest.route) },
                        icon = {
                            Icon(
                                imageVector = dest.icon,
                                contentDescription = dest.title
                            )
                        },
                        label = {
                            Text(
                                text = dest.shortLabel,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = ArchiveDestination.Dashboard.route,
            modifier = Modifier.padding(innerPadding),
            enterTransition = { fadeIn(animationSpec = tween(180)) },
            exitTransition = { fadeOut(animationSpec = tween(140)) },
            popEnterTransition = { EnterTransition.None },
            popExitTransition = { ExitTransition.None }
        ) {
            composable(ArchiveDestination.Dashboard.route) {
                DashboardScreen(
                    stats = stats,
                    listenerStatus = listenerStatus,
                    recentMessages = allMessages,
                    onOpenNotificationSettings = onOpenNotificationAccessSettings,
                    onNavigateToMessages = { navigateTo(ArchiveDestination.Messages.route) },
                    onNavigateToDeleted = { navigateTo(ArchiveDestination.Deleted.route) },
                    onNavigateToViewOnce = { navigateTo(ArchiveDestination.ViewOnce.route) },
                    onNavigateToMedia = { navigateTo(ArchiveDestination.Media.route) },
                    onNavigateToDiagnostics = { navigateTo(ArchiveDestination.Diagnostics.route) },
                    onNavigateToSettings = { navigateTo(ArchiveDestination.Settings.route) },
                    onDeleteMessage = viewModel::deleteMessage
                )
            }

            composable(ArchiveDestination.Messages.route) {
                AllMessagesScreen(
                    messages = filteredMessages,
                    allUnfilteredMessages = allMessages,
                    filterState = filterState,
                    onSearchQueryChange = viewModel::updateSearchQuery,
                    onCategoryFilterChange = viewModel::updateCategoryFilter,
                    onDeletedOnlyChange = viewModel::updateDeletedOnlyFilter,
                    onGroupFilterChange = viewModel::updateGroupFilter,
                    onDateRangeChange = viewModel::updateDateRange,
                    onConversationFilterChange = viewModel::updateConversationFilter,
                    onSenderFilterChange = viewModel::updateSenderFilter,
                    onClearFilters = viewModel::clearFilters,
                    onDeleteMessage = viewModel::deleteMessage
                )
            }

            composable(ArchiveDestination.Deleted.route) {
                DeletedMessagesScreen(
                    deletionEvents = deletionEvents,
                    onDeleteEvent = viewModel::deleteDeletionEvent
                )
            }

            composable(ArchiveDestination.ViewOnce.route) {
                ViewOnceScreen(
                    events = viewOnceEvents,
                    onDeleteEvent = viewModel::deleteViewOnceEvent
                )
            }

            composable(ArchiveDestination.Media.route) {
                MediaArchiveScreen(
                    mediaItems = normalMedia,
                    safTreeUri = safTreeUri,
                    lastSyncAt = lastMediaSyncAt,
                    isSyncing = isSyncingMedia,
                    onSelectMediaFolder = onLaunchSafFolderPicker,
                    onSyncNow = viewModel::syncSafMedia,
                    onDeleteMedia = viewModel::deleteMediaRecord
                )
            }

            composable(ArchiveDestination.Diagnostics.route) {
                DiagnosticsScreen(
                    listenerStatus = listenerStatus,
                    diagnostics = notificationDiagnostics,
                    serviceLogs = diagnosticLogs,
                    onOpenNotificationAccess = onOpenNotificationAccessSettings,
                    onRequestRebind = { viewModel.requestServiceRebindIfNeeded(showFeedback = true) },
                    onClearDiagnostics = viewModel::clearDiagnostics
                )
            }

            composable(ArchiveDestination.Settings.route) {
                SettingsScreen(
                    isDarkMode = isDarkMode,
                    listenerStatus = listenerStatus,
                    safTreeUri = safTreeUri,
                    diagnosticLogs = diagnosticLogs,
                    onToggleDarkMode = viewModel::setDarkMode,
                    onOpenNotificationAccessSettings = onOpenNotificationAccessSettings,
                    onOpenAppBatterySettings = onOpenAppBatterySettings,
                    onRequestPostNotifications = onRequestPostNotifications,
                    onOpenDiagnostics = { navigateTo(ArchiveDestination.Diagnostics.route) },
                    onSelectSafFolder = onLaunchSafFolderPicker,
                    onUnlinkSafFolder = viewModel::unlinkSafFolder,
                    onExportJson = onLaunchJsonExportPicker,
                    onClearCompleteArchive = viewModel::clearCompleteArchive
                )
            }
        }
    }
}
