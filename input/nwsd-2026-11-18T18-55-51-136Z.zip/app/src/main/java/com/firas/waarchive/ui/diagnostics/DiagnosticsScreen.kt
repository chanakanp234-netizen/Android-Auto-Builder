package com.firas.waarchive.ui.diagnostics

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.FactCheck
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.firas.waarchive.models.DiagnosticLogUi
import com.firas.waarchive.models.ListenerStatus
import com.firas.waarchive.models.NotificationDiagnosticStatus
import com.firas.waarchive.models.NotificationDiagnosticUi
import com.firas.waarchive.ui.components.EmptyArchiveState
import com.firas.waarchive.ui.components.LimitationInfoBanner
import com.firas.waarchive.ui.components.StatusTag
import com.firas.waarchive.ui.components.formatTimestamp
import com.firas.waarchive.ui.theme.AmberWarning
import com.firas.waarchive.ui.theme.CrimsonDeleted
import com.firas.waarchive.ui.theme.EmeraldPrimary
import com.firas.waarchive.ui.theme.SkyMedia
import com.firas.waarchive.ui.theme.VioletViewOnce

@Composable
fun DiagnosticsScreen(
    listenerStatus: ListenerStatus,
    diagnostics: List<NotificationDiagnosticUi>,
    serviceLogs: List<DiagnosticLogUi>,
    onOpenNotificationAccess: () -> Unit,
    onRequestRebind: () -> Unit,
    onClearDiagnostics: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            ListenerHealthCard(
                status = listenerStatus,
                onOpenNotificationAccess = onOpenNotificationAccess,
                onRequestRebind = onRequestRebind
            )
        }

        item {
            LimitationInfoBanner(
                title = "Local-Only Extraction Audit",
                body = "Diagnostics are stored locally in Room on your device and never uploaded or logged to production Logcat. Send a test WhatsApp message to verify EXTRA_TEXT, MessagingStyle, extraction, and DB persistence."
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Notification Pipeline Log (${diagnostics.size})",
                    style = MaterialTheme.typography.titleLarge
                )
                if (diagnostics.isNotEmpty() || serviceLogs.isNotEmpty()) {
                    TextButton(onClick = onClearDiagnostics) {
                        Icon(
                            Icons.Rounded.DeleteOutline,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Clear")
                    }
                }
            }
        }

        if (diagnostics.isEmpty()) {
            item {
                EmptyArchiveState(
                    icon = Icons.Rounded.FactCheck,
                    title = "No WhatsApp Notifications Diagnosed Yet",
                    subtitle = "Send a WhatsApp message to this phone while Notification Access is enabled. Every received notification's extras, MessagingStyle count, extraction status, and DB write outcome will appear here."
                )
            }
        } else {
            items(diagnostics, key = { it.id }) { item ->
                DiagnosticEntryCard(item = item)
            }
        }

        if (serviceLogs.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Service Lifecycle Events (${serviceLogs.size})",
                    style = MaterialTheme.typography.titleMedium
                )
            }
            items(serviceLogs.take(20), key = { "svc_${it.id}" }) { log ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "${log.level} · ${log.tag} · ${formatTimestamp(log.timestamp)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = log.message,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ListenerHealthCard(
    status: ListenerStatus,
    onOpenNotificationAccess: () -> Unit,
    onRequestRebind: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Rounded.NotificationsActive,
                    contentDescription = null,
                    tint = if (status.isServiceConnected) EmeraldPrimary else AmberWarning
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Notification Listener Diagnostics",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            DiagBoolRow("Special Notification Access (Required)", status.isPermissionGranted, "Enabled", "Disabled")
            DiagBoolRow("Listener Service Connected", status.isServiceConnected, "Bound & Active", "Disconnected")
            DiagBoolRow("Android 13 App Alert Permission (Optional)", status.isPostNotificationsGranted, "Granted", "Not Granted")

            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))

            DiagTextRow("Last Connected", formatTimestamp(status.lastConnectedAt))
            DiagTextRow("Last Notification Observed", formatTimestamp(status.lastEventAt))
            DiagTextRow("Last Message Saved", formatTimestamp(status.lastSuccessfulArchiveAt))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onOpenNotificationAccess,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Access Settings")
                }
                Button(
                    onClick = onRequestRebind,
                    enabled = status.isPermissionGranted,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Request Rebind")
                }
            }
        }
    }
}

@Composable
private fun DiagnosticEntryCard(item: NotificationDiagnosticUi) {
    val (badgeLabel, badgeColor) = when (item.status) {
        NotificationDiagnosticStatus.NOTIFICATION_RECEIVED -> "NOTIFICATION RECEIVED" to SkyMedia
        NotificationDiagnosticStatus.WHATSAPP_IDENTIFIED -> "WHATSAPP IDENTIFIED" to SkyMedia
        NotificationDiagnosticStatus.MESSAGE_TEXT_EXTRACTED -> "TEXT EXTRACTED (DEDUPED)" to EmeraldPrimary
        NotificationDiagnosticStatus.MESSAGE_SAVED_SUCCESSFULLY -> "MESSAGE SAVED" to EmeraldPrimary
        NotificationDiagnosticStatus.NO_MESSAGE_TEXT_EXPOSED -> "NO TEXT EXPOSED" to AmberWarning
        NotificationDiagnosticStatus.POSSIBLE_MEDIA_NOTIFICATION -> "POSSIBLE MEDIA" to SkyMedia
        NotificationDiagnosticStatus.VIEW_ONCE_IDENTIFIED -> "VIEW ONCE IDENTIFIED" to VioletViewOnce
        NotificationDiagnosticStatus.DELETION_NOTICE_RECORDED -> "DELETION RECORDED" to CrimsonDeleted
        NotificationDiagnosticStatus.DATABASE_SAVE_FAILED -> "DB SAVE FAILED" to CrimsonDeleted
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, badgeColor.copy(alpha = 0.45f))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatusTag(label = badgeLabel, color = badgeColor)
                Text(
                    text = formatTimestamp(item.timestamp),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Text(
                text = "Title: ${item.notificationTitle}",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )

            Text(
                text = "Package: ${item.sourcePackage} (${if (item.isWhatsAppPackage) "Official WhatsApp" else "Other"}) · Summary Flag: ${item.isGroupSummary}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                StatusTag(
                    label = "EXTRA_TEXT: ${if (item.hasExtraText) "YES" else "NO"}",
                    color = if (item.hasExtraText) EmeraldPrimary else AmberWarning
                )
                StatusTag(
                    label = "BIG_TEXT: ${if (item.hasExtraBigText) "YES" else "NO"}",
                    color = if (item.hasExtraBigText) EmeraldPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                StatusTag(
                    label = "MessagingStyle: ${item.messagingStyleCount}",
                    color = if (item.messagingStyleCount > 0) EmeraldPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                )
                StatusTag(
                    label = "Extracted: ${item.extractedTextCount} · Saved: ${item.savedRecordCount}",
                    color = if (item.databaseSaveSucceeded && item.savedRecordCount > 0) EmeraldPrimary else AmberWarning
                )
            }

            DiagBoolRow("Database Save Succeeded", item.databaseSaveSucceeded, "Yes", "Failed")

            Text(
                text = item.reasonDetail,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun DiagBoolRow(
    label: String,
    value: Boolean,
    trueLabel: String,
    falseLabel: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = if (value) trueLabel else falseLabel,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = if (value) EmeraldPrimary else CrimsonDeleted
        )
    }
}

@Composable
private fun DiagTextRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
