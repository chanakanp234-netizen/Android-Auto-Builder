package com.firas.waarchive.ui.dashboard

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.FactCheck
import androidx.compose.material.icons.rounded.Forum
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.firas.waarchive.models.ArchivedMessageUi
import com.firas.waarchive.models.DashboardStats
import com.firas.waarchive.models.ListenerStatus
import com.firas.waarchive.ui.components.ArchivedMessageCard
import com.firas.waarchive.ui.components.LimitationInfoBanner
import com.firas.waarchive.ui.components.MessageDetailDialog
import com.firas.waarchive.ui.components.formatTimestamp
import com.firas.waarchive.ui.theme.AmberWarning
import com.firas.waarchive.ui.theme.CrimsonDeleted
import com.firas.waarchive.ui.theme.EmeraldPrimary
import com.firas.waarchive.ui.theme.SkyMedia
import com.firas.waarchive.ui.theme.VioletViewOnce

@Composable
fun DashboardScreen(
    stats: DashboardStats,
    listenerStatus: ListenerStatus,
    recentMessages: List<ArchivedMessageUi>,
    onOpenNotificationSettings: () -> Unit,
    onNavigateToMessages: () -> Unit,
    onNavigateToDeleted: () -> Unit,
    onNavigateToViewOnce: () -> Unit,
    onNavigateToMedia: () -> Unit,
    onNavigateToDiagnostics: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onDeleteMessage: (Long) -> Unit
) {
    var selectedMessage by remember { mutableStateOf<ArchivedMessageUi?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            ListenerStatusHeroCard(
                status = listenerStatus,
                onOpenSettings = onOpenNotificationSettings,
                onOpenDiagnostics = onNavigateToDiagnostics
            )
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatTile(
                        title = "Archived Messages",
                        count = stats.totalMessages,
                        icon = Icons.Rounded.Forum,
                        accent = EmeraldPrimary,
                        onClick = onNavigateToMessages,
                        modifier = Modifier.weight(1f)
                    )
                    StatTile(
                        title = "Deleted Records",
                        count = stats.deletedRecords,
                        icon = Icons.Rounded.DeleteSweep,
                        accent = CrimsonDeleted,
                        onClick = onNavigateToDeleted,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatTile(
                        title = "View Once Events",
                        count = stats.viewOnceEvents,
                        icon = Icons.Rounded.VisibilityOff,
                        accent = VioletViewOnce,
                        onClick = onNavigateToViewOnce,
                        modifier = Modifier.weight(1f)
                    )
                    StatTile(
                        title = "Normal Media",
                        count = stats.archivedMediaCount,
                        icon = Icons.Rounded.PhotoLibrary,
                        accent = SkyMedia,
                        onClick = onNavigateToMedia,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onNavigateToDiagnostics),
                color = SkyMedia.copy(alpha = 0.1f),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, SkyMedia.copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.FactCheck,
                        contentDescription = null,
                        tint = SkyMedia,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Notification Pipeline Diagnostics",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Inspect real-time EXTRA_TEXT, MessagingStyle extraction, DB write status, and empty-preview reasons.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.Schedule,
                            contentDescription = null,
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Archive Telemetry",
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                    InfoKeyValueRow(
                        label = "Last Successful Archive",
                        value = formatTimestamp(listenerStatus.lastSuccessfulArchiveAt)
                    )
                    InfoKeyValueRow(
                        label = "Monitored Package",
                        value = "com.whatsapp (Official)"
                    )
                    InfoKeyValueRow(
                        label = "Notification Observations",
                        value = "${stats.totalObservations} logged · ${stats.conversationsCount} chats"
                    )
                    InfoKeyValueRow(
                        label = "Storage Security",
                        value = "Android Keystore AES-256-GCM · Offline Only"
                    )
                }
            }
        }

        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onNavigateToSettings),
                color = AmberWarning.copy(alpha = 0.1f),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, AmberWarning.copy(alpha = 0.35f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.BatteryChargingFull,
                        contentDescription = null,
                        tint = AmberWarning,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Infinix Smart 8 (XOS 13) Reliability Guide",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Disable XOS Battery Freeze & allow unrestricted background execution in Settings.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        item {
            LimitationInfoBanner(
                title = "Official Android API Scope",
                body = "Only messages exposed via Android notifications can be captured. Messages received while a chat is open, muted, or with previews disabled are not sent to NotificationListenerService."
            )
        }

        if (recentMessages.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Recent Captures",
                        style = MaterialTheme.typography.titleLarge
                    )
                    OutlinedButton(onClick = onNavigateToMessages) {
                        Text("View All")
                    }
                }
            }

            items(recentMessages.take(5), key = { it.id }) { message ->
                ArchivedMessageCard(
                    message = message,
                    onClick = { selectedMessage = message }
                )
            }
        }
    }

    selectedMessage?.let { msg ->
        MessageDetailDialog(
            message = msg,
            onDismiss = { selectedMessage = null },
            onDelete = {
                onDeleteMessage(msg.id)
                selectedMessage = null
            }
        )
    }
}

@Composable
private fun ListenerStatusHeroCard(
    status: ListenerStatus,
    onOpenSettings: () -> Unit,
    onOpenDiagnostics: () -> Unit
) {
    val (bgColor, borderColor, icon, title, desc) = when {
        !status.isPermissionGranted -> Tuple5(
            CrimsonDeleted.copy(alpha = 0.12f),
            CrimsonDeleted.copy(alpha = 0.45f),
            Icons.Rounded.NotificationsOff,
            "Notification Access Required",
            "Grant special Notification Access so WA Message Archive Pro can capture com.whatsapp notifications locally."
        )
        status.isServiceConnected -> Tuple5(
            EmeraldPrimary.copy(alpha = 0.12f),
            EmeraldPrimary.copy(alpha = 0.45f),
            Icons.Rounded.NotificationsActive,
            "Listener Active · Monitoring WhatsApp",
            "Connected to Android NotificationManager. Incoming WhatsApp messages are extracted and saved immediately."
        )
        else -> Tuple5(
            AmberWarning.copy(alpha = 0.12f),
            AmberWarning.copy(alpha = 0.45f),
            Icons.Rounded.Warning,
            "Access Granted · Service Rebinding",
            "Special Notification Access is enabled. Tap Diagnostics to request a rebind or check XOS 13 battery settings if disconnected."
        )
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = bgColor,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (!status.isPermissionGranted) CrimsonDeleted else if (status.isServiceConnected) EmeraldPrimary else AmberWarning,
                    modifier = Modifier.size(26.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (status.isPermissionGranted) Icons.Rounded.CheckCircle else Icons.Rounded.Lock,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (status.isPermissionGranted) "Special Notification Access On" else "No Root · Official API",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = desc,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onOpenSettings,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (!status.isPermissionGranted) CrimsonDeleted else EmeraldPrimary
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = if (!status.isPermissionGranted) "Enable Access" else "Access Settings"
                    )
                }
                OutlinedButton(
                    onClick = onOpenDiagnostics,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Diagnostics")
                }
            }
        }
    }
}

@Composable
private fun StatTile(
    title: String,
    count: Int,
    icon: ImageVector,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.clickable(onClick = onClick),
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accent,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = count.toString(),
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun InfoKeyValueRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

private data class Tuple5<A, B, C, D, E>(
    val a: A,
    val b: B,
    val c: C,
    val d: D,
    val e: E
)
