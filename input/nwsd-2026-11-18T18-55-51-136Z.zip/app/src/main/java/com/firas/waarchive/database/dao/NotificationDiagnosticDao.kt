package com.firas.waarchive.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.firas.waarchive.database.entity.NotificationDiagnosticEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface NotificationDiagnosticDao {

    @Insert
    suspend fun insert(entry: NotificationDiagnosticEntity): Long

    @Query("SELECT * FROM notification_diagnostics ORDER BY timestamp DESC, id DESC LIMIT 150")
    fun observeRecent(): Flow<List<NotificationDiagnosticEntity>>

    @Query("DELETE FROM notification_diagnostics WHERE id NOT IN (SELECT id FROM notification_diagnostics ORDER BY timestamp DESC, id DESC LIMIT 250)")
    suspend fun trimOldEntries()

    @Query("DELETE FROM notification_diagnostics")
    suspend fun clearAll()
}
