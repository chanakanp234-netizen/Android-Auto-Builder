package com.firas.waarchive.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.firas.waarchive.models.NotificationDiagnosticStatus

@Entity(
    tableName = "notification_diagnostics",
    indices = [
        Index(value = ["timestamp"]),
        Index(value = ["status"])
    ]
)
data class NotificationDiagnosticEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val timestamp: Long,
    val sourcePackage: String,
    val isWhatsAppPackage: Boolean,
    val notificationKey: String,
    val notificationId: Int,
    val isGroupSummary: Boolean,
    val encryptedNotificationTitle: String,
    val hasExtraText: Boolean,
    val hasExtraBigText: Boolean,
    val hasExtraTextLines: Boolean,
    val messagingStyleCount: Int,
    val extractedTextCount: Int,
    val databaseSaveSucceeded: Boolean,
    val savedRecordCount: Int,
    val status: NotificationDiagnosticStatus,
    val reasonDetail: String
)
