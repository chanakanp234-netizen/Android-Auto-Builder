package com.firas.waarchive.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.firas.waarchive.database.dao.ConversationDao
import com.firas.waarchive.database.dao.DeletionEventDao
import com.firas.waarchive.database.dao.DiagnosticLogDao
import com.firas.waarchive.database.dao.MessageDao
import com.firas.waarchive.database.dao.NormalMediaDao
import com.firas.waarchive.database.dao.NotificationDiagnosticDao
import com.firas.waarchive.database.dao.ObservationDao
import com.firas.waarchive.database.dao.ViewOnceDao
import com.firas.waarchive.database.entity.AppLogEntity
import com.firas.waarchive.database.entity.ArchivedMessageEntity
import com.firas.waarchive.database.entity.ConversationMetadataEntity
import com.firas.waarchive.database.entity.DeletionEventEntity
import com.firas.waarchive.database.entity.NormalMediaEntity
import com.firas.waarchive.database.entity.NotificationDiagnosticEntity
import com.firas.waarchive.database.entity.NotificationObservationEntity
import com.firas.waarchive.database.entity.ViewOnceEventEntity

@Database(
    entities = [
        ArchivedMessageEntity::class,
        NotificationObservationEntity::class,
        DeletionEventEntity::class,
        ViewOnceEventEntity::class,
        NormalMediaEntity::class,
        ConversationMetadataEntity::class,
        AppLogEntity::class,
        NotificationDiagnosticEntity::class
    ],
    version = 2,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class WaArchiveDatabase : RoomDatabase() {

    abstract fun messageDao(): MessageDao
    abstract fun observationDao(): ObservationDao
    abstract fun deletionEventDao(): DeletionEventDao
    abstract fun viewOnceDao(): ViewOnceDao
    abstract fun normalMediaDao(): NormalMediaDao
    abstract fun conversationDao(): ConversationDao
    abstract fun diagnosticLogDao(): DiagnosticLogDao
    abstract fun notificationDiagnosticDao(): NotificationDiagnosticDao

    companion object {
        private const val DB_NAME = "wa_message_archive_pro.db"

        @Volatile
        private var INSTANCE: WaArchiveDatabase? = null

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE view_once_events ADD COLUMN isMediaContentAvailable INTEGER NOT NULL DEFAULT 0"
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS notification_diagnostics (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        timestamp INTEGER NOT NULL,
                        sourcePackage TEXT NOT NULL,
                        isWhatsAppPackage INTEGER NOT NULL,
                        notificationKey TEXT NOT NULL,
                        notificationId INTEGER NOT NULL,
                        isGroupSummary INTEGER NOT NULL,
                        encryptedNotificationTitle TEXT NOT NULL,
                        hasExtraText INTEGER NOT NULL,
                        hasExtraBigText INTEGER NOT NULL,
                        hasExtraTextLines INTEGER NOT NULL,
                        messagingStyleCount INTEGER NOT NULL,
                        extractedTextCount INTEGER NOT NULL,
                        databaseSaveSucceeded INTEGER NOT NULL,
                        savedRecordCount INTEGER NOT NULL,
                        status TEXT NOT NULL,
                        reasonDetail TEXT NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS index_notification_diagnostics_timestamp ON notification_diagnostics(timestamp)"
                )
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS index_notification_diagnostics_status ON notification_diagnostics(status)"
                )
            }
        }

        fun getInstance(context: Context): WaArchiveDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    WaArchiveDatabase::class.java,
                    DB_NAME
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
