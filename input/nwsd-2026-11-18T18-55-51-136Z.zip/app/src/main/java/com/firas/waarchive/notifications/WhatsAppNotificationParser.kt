package com.firas.waarchive.notifications

import android.app.Notification
import android.app.Person
import android.os.Build
import android.os.Bundle
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat
import com.firas.waarchive.models.MessageCategory
import com.firas.waarchive.models.ViewOnceMediaKind

data class ParsedMessageEntry(
    val senderName: String,
    val conversationName: String,
    val isGroupChat: Boolean,
    val messageText: String,
    val bigText: String?,
    val timestamp: Long,
    val occurrenceIndex: Int,
    val category: MessageCategory,
    val isDeletionNotice: Boolean,
    val isViewOnceEvent: Boolean,
    val viewOnceMediaKind: ViewOnceMediaKind?
)

data class ParsedNotificationPayload(
    val sourcePackage: String,
    val notificationKey: String,
    val notificationId: Int,
    val postTime: Long,
    val notificationTitle: String,
    val isMessagingStyle: Boolean,
    val isSummaryNotification: Boolean,
    val hasExtraText: Boolean,
    val hasExtraBigText: Boolean,
    val hasExtraTextLines: Boolean,
    val messagingStyleCount: Int,
    val possibleMediaWithoutViewOnceFlag: Boolean,
    val noTextReason: String?,
    val extrasSnapshot: String,
    val entries: List<ParsedMessageEntry>
)

object WhatsAppNotificationParser {

    const val WHATSAPP_PACKAGE = "com.whatsapp"

    private val deletionPatterns = listOf(
        "this message was deleted",
        "you deleted this message",
        "message deleted",
        "ce message a été supprimé",
        "vous avez supprimé ce message",
        "تم حذف هذه الرسالة",
        "حذفت هذه الرسالة",
        "esta mensagem foi apagada",
        "este mensaje fue eliminado",
        "diese nachricht wurde gelöscht"
    )

    private val summaryBoilerplateRegex = Regex(
        """^(\d+\s+(new\s+)?messages?(\s+from\s+\d+\s+chats?)?|\d+\s+messages?)$""",
        RegexOption.IGNORE_CASE
    )

    private val checkingMessagesRegex = Regex(
        """^(checking for new messages|whatsapp web is currently active|backing up messages|restoring media|finished backup|searching\.\.\.).*$""",
        RegexOption.IGNORE_CASE
    )

    // Matches "Family Group (3 messages)" OR "Family Group (3 messages): Alice"
    private val groupTitleCountSuffixRegex = Regex(
        """^(.+?)\s*\(\d+\s+messages?\)(?::\s*(.+))?$""",
        RegexOption.IGNORE_CASE
    )

    fun parse(sbn: StatusBarNotification): ParsedNotificationPayload? {
        if (sbn.packageName != WHATSAPP_PACKAGE) return null

        val notification = sbn.notification ?: return null
        val extras = notification.extras ?: Bundle.EMPTY
        val isSummary = (notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0

        val rawTitle = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val rawText = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        val rawBigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim()
            ?.takeIf { it.isNotEmpty() }
        val conversationTitle = extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)
            ?.toString()?.trim()?.takeIf { it.isNotEmpty() }
        val subText = extras.getCharSequence(Notification.EXTRA_SUB_TEXT)
            ?.toString()?.trim()?.takeIf { it.isNotEmpty() }
        val isGroupExtra = extras.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false)

        val styleResult = extractAllMessagingStyleMessages(notification, extras)
        val allStyleMessages = styleResult.messages

        val textLines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
            ?.mapNotNull { it?.toString()?.trim()?.takeIf { line -> line.isNotEmpty() } }
            .orEmpty()

        val rawEntries = mutableListOf<ParsedMessageEntry>()
        var noTextReason: String? = null

        val effectiveConvTitle = styleResult.conversationTitle ?: conversationTitle
        val effectiveIsGroup = styleResult.isGroupConversation || isGroupExtra

        // 1. Primary: MessagingStyle (NotificationCompat + raw bundle fallback + CarExtender fallback)
        if (allStyleMessages.isNotEmpty()) {
            val (baseTitleConv, baseTitleSender, titleHadGroupCount) = splitGroupCountTitle(rawTitle)
            val resolvedConv = cleanConversationName(effectiveConvTitle ?: baseTitleConv)
            val isGroup = effectiveIsGroup || titleHadGroupCount ||
                (!effectiveConvTitle.isNullOrBlank() && !resolvedConv.equals(baseTitleSender, ignoreCase = true))

            for (msg in allStyleMessages) {
                val msgText = msg.text.ifBlank { describeMimeFallback(msg.mimeType) }
                if (msgText.isBlank()) continue
                if (isBoilerplateSystemText(msgText)) {
                    noTextReason = "Skipped WhatsApp system/summary text: \"$msgText\""
                    continue
                }

                val resolvedSender = msg.sender?.takeIf { it.isNotBlank() }
                    ?: baseTitleSender?.takeIf { it.isNotBlank() }
                    ?: extractSenderFromColonPrefix(msgText, resolvedConv)
                    ?: resolvedConv.ifBlank { "WhatsApp Contact" }

                val cleanedText = stripLeadingSenderIfRedundant(msgText, resolvedSender, isGroup)
                rawEntries += buildEntry(
                    senderName = resolvedSender,
                    conversationName = resolvedConv.ifBlank { resolvedSender },
                    isGroupChat = isGroup || !resolvedSender.equals(resolvedConv, ignoreCase = true),
                    messageText = cleanedText,
                    bigText = rawBigText?.takeIf { it != cleanedText && allStyleMessages.size == 1 },
                    timestamp = msg.timestamp.takeIf { it > 0L } ?: sbn.postTime,
                    occurrenceIndex = 0,
                    mimeType = msg.mimeType
                )
            }
        }

        // 2. Fallback: InboxStyle EXTRA_TEXT_LINES (often populated in bundled WhatsApp notifications)
        if (rawEntries.isEmpty() && textLines.isNotEmpty()) {
            val (baseTitleConv, _, _) = splitGroupCountTitle(rawTitle)
            val defaultConv = cleanConversationName(effectiveConvTitle ?: baseTitleConv)
            for ((idx, line) in textLines.withIndex()) {
                if (isBoilerplateSystemText(line)) {
                    noTextReason = "Skipped WhatsApp summary line: \"$line\""
                    continue
                }
                val parsedLine = parseColonLine(line, defaultConv)
                rawEntries += buildEntry(
                    senderName = parsedLine.first,
                    conversationName = parsedLine.second,
                    isGroupChat = parsedLine.third || effectiveIsGroup,
                    messageText = parsedLine.fourth,
                    bigText = null,
                    timestamp = sbn.postTime,
                    occurrenceIndex = idx,
                    mimeType = null
                )
            }
        }

        // 3. Fallback: EXTRA_BIG_TEXT or EXTRA_TEXT (do NOT discard merely because FLAG_GROUP_SUMMARY is set!)
        if (rawEntries.isEmpty()) {
            val primaryBody = rawBigText ?: rawText
            if (primaryBody.isNotBlank()) {
                if (isBoilerplateSystemText(primaryBody)) {
                    noTextReason = if (isSummary) {
                        "Summary notification boilerplate only (\"$primaryBody\"); individual chat notifications carry actual text or previews are hidden."
                    } else {
                        "WhatsApp status/boilerplate notification (\"$primaryBody\"); no user message text exposed."
                    }
                } else {
                    val (resolvedSender, resolvedConv, inferredGroup) = resolveTitleAndSender(
                        rawTitle = rawTitle,
                        conversationTitle = effectiveConvTitle,
                        subText = subText,
                        isGroupExtra = effectiveIsGroup
                    )
                    val cleanedBody = stripLeadingSenderIfRedundant(
                        rawText.ifBlank { primaryBody },
                        resolvedSender,
                        inferredGroup
                    )
                    rawEntries += buildEntry(
                        senderName = resolvedSender,
                        conversationName = resolvedConv,
                        isGroupChat = inferredGroup,
                        messageText = cleanedBody,
                        bigText = rawBigText?.takeIf { it != cleanedBody && it != rawText },
                        timestamp = sbn.postTime,
                        occurrenceIndex = 0,
                        mimeType = null
                    )
                }
            } else {
                noTextReason = if (isSummary) {
                    "Empty group summary notification (EXTRA_TEXT and MessagingStyle are empty)."
                } else {
                    "Notification had no readable text in EXTRA_TEXT, EXTRA_BIG_TEXT, EXTRA_TEXT_LINES, or MessagingStyle (previews may be disabled)."
                }
            }
        }

        // Assign per-key occurrenceIndex so identical messages in the same timestamp/bundle aren't dropped
        val seenOccurrences = mutableMapOf<String, Int>()
        val entries = rawEntries.map { entry ->
            val key = "${entry.senderName}|${entry.timestamp}|${entry.messageText}"
            val idx = seenOccurrences.getOrDefault(key, 0)
            seenOccurrences[key] = idx + 1
            entry.copy(occurrenceIndex = idx)
        }

        val possibleMediaWithoutViewOnce = entries.any {
            !it.isViewOnceEvent && (it.category == MessageCategory.IMAGE || it.category == MessageCategory.VIDEO)
        }

        val extrasSummary = buildString {
            append("title=").append(rawTitle)
            append(" | conv=").append(effectiveConvTitle.orEmpty())
            append(" | text=").append(rawText)
            if (!rawBigText.isNullOrBlank()) append(" | bigText=").append(rawBigText)
            if (allStyleMessages.isNotEmpty()) append(" | styleCount=").append(allStyleMessages.size)
            if (textLines.isNotEmpty()) append(" | lines=").append(textLines.size)
            if (isSummary) append(" | summary=true")
        }

        return ParsedNotificationPayload(
            sourcePackage = sbn.packageName,
            notificationKey = sbn.key,
            notificationId = sbn.id,
            postTime = sbn.postTime,
            notificationTitle = rawTitle.ifBlank { effectiveConvTitle ?: "WhatsApp" },
            isMessagingStyle = allStyleMessages.isNotEmpty(),
            isSummaryNotification = isSummary,
            hasExtraText = rawText.isNotEmpty(),
            hasExtraBigText = !rawBigText.isNullOrEmpty(),
            hasExtraTextLines = textLines.isNotEmpty(),
            messagingStyleCount = allStyleMessages.size,
            possibleMediaWithoutViewOnceFlag = possibleMediaWithoutViewOnce,
            noTextReason = if (entries.isEmpty()) noTextReason else null,
            extrasSnapshot = extrasSummary,
            entries = entries
        )
    }

    private data class StyleMsg(
        val text: String,
        val timestamp: Long,
        val sender: String?,
        val mimeType: String?
    )

    private data class StyleExtractionResult(
        val messages: List<StyleMsg>,
        val conversationTitle: String?,
        val isGroupConversation: Boolean
    )

    private fun extractAllMessagingStyleMessages(
        notification: Notification,
        extras: Bundle
    ): StyleExtractionResult {
        val collected = mutableListOf<StyleMsg>()
        var extractedConvTitle: String? = null
        var extractedIsGroup = false

        // Path A: AndroidX NotificationCompat.MessagingStyle extractor (safest across Android 13 ROMs)
        runCatching {
            val compatStyle = NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(notification)
            if (compatStyle != null) {
                extractedConvTitle = compatStyle.conversationTitle?.toString()?.trim()?.takeIf { it.isNotEmpty() }
                extractedIsGroup = compatStyle.isGroupConversation
                compatStyle.historicMessages.forEach { m ->
                    collected += StyleMsg(
                        text = m.text?.toString()?.trim().orEmpty(),
                        timestamp = m.timestamp,
                        sender = m.person?.name?.toString()?.trim(),
                        mimeType = m.dataMimeType
                    )
                }
                compatStyle.messages.forEach { m ->
                    collected += StyleMsg(
                        text = m.text?.toString()?.trim().orEmpty(),
                        timestamp = m.timestamp,
                        sender = m.person?.name?.toString()?.trim(),
                        mimeType = m.dataMimeType
                    )
                }
            }
        }

        // Path B: Direct raw Bundle array inspection (avoids Android 13 typed getParcelableArray bug)
        if (collected.isEmpty()) {
            collected += extractFromBundleArrayKey(extras, Notification.EXTRA_HISTORIC_MESSAGES)
            collected += extractFromBundleArrayKey(extras, Notification.EXTRA_MESSAGES)
        }

        // Path C: CarExtender fallback if present and MessagingStyle was empty
        if (collected.isEmpty()) {
            runCatching {
                val carExt = extras.getBundle("android.car.EXTENSIONS")
                val carConv = carExt?.getBundle("car_conversation")
                val carMsgs = carConv?.getStringArray("messages")
                val carTime = carConv?.getLong("timestamp", 0L) ?: 0L
                val participants = carConv?.getStringArray("participants")
                val participant = participants?.firstOrNull()?.trim()
                if (!carMsgs.isNullOrEmpty()) {
                    carMsgs.forEach { msg ->
                        val text = msg?.trim().orEmpty()
                        if (text.isNotEmpty()) {
                            collected += StyleMsg(
                                text = text,
                                timestamp = carTime,
                                sender = participant,
                                mimeType = null
                            )
                        }
                    }
                }
            }
        }

        val deduped = collected.distinctBy { "${it.sender}|${it.text}|${it.timestamp}|${it.mimeType}" }
        return StyleExtractionResult(
            messages = deduped,
            conversationTitle = extractedConvTitle,
            isGroupConversation = extractedIsGroup
        )
    }

    private fun extractFromBundleArrayKey(extras: Bundle, key: String): List<StyleMsg> {
        @Suppress("DEPRECATION")
        val rawArray = runCatching { extras.getParcelableArray(key) }.getOrNull() ?: return emptyList()
        if (rawArray.isEmpty()) return emptyList()

        // First try platform parser safely
        val platformParsed = runCatching {
            Notification.MessagingStyle.Message.getMessagesFromBundleArray(rawArray)
        }.getOrNull()

        if (!platformParsed.isNullOrEmpty()) {
            return platformParsed.map { msg ->
                val senderName = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    msg.senderPerson?.name?.toString()?.trim()
                } else {
                    @Suppress("DEPRECATION")
                    msg.sender?.toString()?.trim()
                }
                StyleMsg(
                    text = msg.text?.toString()?.trim().orEmpty(),
                    timestamp = msg.timestamp,
                    sender = senderName,
                    mimeType = msg.dataMimeType
                )
            }
        }

        // Fallback: manual Bundle key extraction
        return rawArray.mapNotNull { item ->
            val bundle = item as? Bundle ?: return@mapNotNull null
            val text = bundle.getCharSequence("text")?.toString()?.trim().orEmpty()
            val time = bundle.getLong("time", 0L)
            val mimeType = bundle.getString("type")
            val senderName = extractSenderFromMessageBundle(bundle)
            StyleMsg(text = text, timestamp = time, sender = senderName, mimeType = mimeType)
        }
    }

    private fun extractSenderFromMessageBundle(bundle: Bundle): String? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            @Suppress("DEPRECATION")
            val person = runCatching { bundle.getParcelable<Person>("sender_person") }.getOrNull()
            person?.name?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { return it }
        }
        val compatPersonBundle = bundle.getBundle("person")
        compatPersonBundle?.getCharSequence("name")?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { return it }
        return bundle.getCharSequence("sender")?.toString()?.trim()?.takeIf { it.isNotEmpty() }
    }

    private fun buildEntry(
        senderName: String,
        conversationName: String,
        isGroupChat: Boolean,
        messageText: String,
        bigText: String?,
        timestamp: Long,
        occurrenceIndex: Int,
        mimeType: String?
    ): ParsedMessageEntry {
        val combined = listOfNotNull(messageText, bigText).joinToString(" ").trim()
        val isDeletion = isExplicitDeletionNotice(combined)
        val viewOnceKind = detectViewOnceKind(combined, mimeType)
        val isViewOnce = viewOnceKind != null && !isDeletion

        val category = when {
            isDeletion -> MessageCategory.DELETED_NOTICE
            viewOnceKind == ViewOnceMediaKind.PHOTO -> MessageCategory.VIEW_ONCE_PHOTO
            viewOnceKind == ViewOnceMediaKind.VIDEO -> MessageCategory.VIEW_ONCE_VIDEO
            viewOnceKind == ViewOnceMediaKind.UNKNOWN -> MessageCategory.VIEW_ONCE_UNKNOWN
            else -> classifyNormalCategory(combined, mimeType)
        }

        return ParsedMessageEntry(
            senderName = senderName.ifBlank { "Unknown Sender" },
            conversationName = conversationName.ifBlank { senderName.ifBlank { "WhatsApp Chat" } },
            isGroupChat = isGroupChat,
            messageText = messageText,
            bigText = bigText,
            timestamp = timestamp,
            occurrenceIndex = occurrenceIndex,
            category = category,
            isDeletionNotice = isDeletion,
            isViewOnceEvent = isViewOnce,
            viewOnceMediaKind = viewOnceKind
        )
    }

    internal fun isExplicitDeletionNotice(text: String): Boolean {
        val normalized = text.lowercase().trim()
        if (normalized.isEmpty()) return false
        return deletionPatterns.any { normalized.contains(it) }
    }

    internal fun detectViewOnceKind(text: String, mimeType: String?): ViewOnceMediaKind? {
        val lower = text.lowercase()
        val hasExplicitViewOnceMarker =
            lower.contains("view once") ||
                lower.contains("view-once") ||
                lower.contains("1-time") ||
                lower.contains("one-time photo") ||
                lower.contains("one-time video") ||
                lower.contains("photo • once") ||
                lower.contains("video • once") ||
                lower.contains("vue unique") ||
                lower.contains("عرض لمرة واحدة") ||
                lower.contains("visualização única") ||
                lower.contains("ver una vez")

        if (!hasExplicitViewOnceMarker) return null

        return when {
            lower.contains("photo") || lower.contains("image") || lower.contains("📷") ||
                mimeType?.startsWith("image/") == true -> ViewOnceMediaKind.PHOTO
            lower.contains("video") || lower.contains("🎥") || lower.contains("📹") ||
                mimeType?.startsWith("video/") == true -> ViewOnceMediaKind.VIDEO
            else -> ViewOnceMediaKind.UNKNOWN
        }
    }

    private fun classifyNormalCategory(text: String, mimeType: String?): MessageCategory {
        val lower = text.lowercase()
        return when {
            mimeType?.startsWith("image/") == true || lower.contains("📷") || lower == "photo" -> MessageCategory.IMAGE
            mimeType?.startsWith("video/") == true || lower.contains("🎥") || lower.contains("📹") || lower == "video" -> MessageCategory.VIDEO
            lower.contains("voice message") || lower.contains("🎤") -> MessageCategory.VOICE_NOTE
            mimeType?.startsWith("audio/") == true || lower.contains("🎵") || lower == "audio" -> MessageCategory.AUDIO
            lower.contains("📄") || lower.contains("document") -> MessageCategory.DOCUMENT
            lower.contains("sticker") || lower.contains("💟") -> MessageCategory.STICKER
            else -> MessageCategory.TEXT
        }
    }

    private fun describeMimeFallback(mimeType: String?): String {
        return when {
            mimeType == null -> ""
            mimeType.startsWith("image/") -> "📷 Photo"
            mimeType.startsWith("video/") -> "🎥 Video"
            mimeType.startsWith("audio/") -> "🎵 Audio"
            else -> "Attachment ($mimeType)"
        }
    }

    internal fun isBoilerplateSystemText(text: String): Boolean {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return true
        if (summaryBoilerplateRegex.matches(trimmed)) return true
        if (checkingMessagesRegex.matches(trimmed)) return true
        return false
    }

    private fun splitGroupCountTitle(raw: String): Triple<String, String?, Boolean> {
        val trimmed = raw.trim()
        val match = groupTitleCountSuffixRegex.matchEntire(trimmed)
        return if (match != null) {
            val conv = match.groupValues[1].trim()
            val sender = match.groupValues.getOrNull(2)?.trim()?.takeIf { it.isNotEmpty() }
            Triple(conv, sender, true)
        } else {
            Triple(trimmed, null, false)
        }
    }

    internal fun cleanConversationName(raw: String): String {
        return splitGroupCountTitle(raw).first
    }

    private fun resolveTitleAndSender(
        rawTitle: String,
        conversationTitle: String?,
        subText: String?,
        isGroupExtra: Boolean
    ): Triple<String, String, Boolean> {
        val (titleBase, titleSender, hadCount) = splitGroupCountTitle(rawTitle)

        if (!conversationTitle.isNullOrBlank()) {
            val cleanConv = cleanConversationName(conversationTitle)
            val resolvedSender = titleSender ?: titleBase.ifBlank { cleanConv }
            return Triple(resolvedSender, cleanConv, true)
        }

        if (hadCount && titleSender != null) {
            return Triple(titleSender, titleBase, true)
        }

        // Check WhatsApp pattern "Sender @ Group Name" or "Group Name: Sender"
        if (titleBase.contains(" @ ")) {
            val parts = titleBase.split(" @ ", limit = 2)
            return Triple(parts[0].trim(), parts[1].trim(), true)
        }
        if (titleBase.contains(": ") && !titleBase.startsWith("+")) {
            val parts = titleBase.split(": ", limit = 2)
            return Triple(parts[1].trim(), parts[0].trim(), true)
        }
        val convName = subText?.let { cleanConversationName(it) } ?: titleBase
        val isGroup = isGroupExtra || hadCount || (convName != titleBase && convName.isNotBlank())
        return Triple(titleBase.ifBlank { "WhatsApp Contact" }, convName.ifBlank { "WhatsApp Chat" }, isGroup)
    }

    private data class Quad(val first: String, val second: String, val third: Boolean, val fourth: String)

    private fun parseColonLine(line: String, defaultConversation: String): Quad {
        val colonIdx = line.indexOf(": ")
        if (colonIdx in 1..48) {
            val left = line.substring(0, colonIdx).trim()
            val right = line.substring(colonIdx + 2).trim()
            if (left.contains(" @ ")) {
                val parts = left.split(" @ ", limit = 2)
                return Quad(parts[0].trim(), parts[1].trim(), true, right)
            }
            val conv = defaultConversation.takeIf {
                it.isNotBlank() && !it.equals("WhatsApp", ignoreCase = true) && !summaryBoilerplateRegex.matches(it)
            } ?: left
            val isGroup = !conv.equals(left, ignoreCase = true)
            return Quad(left, conv, isGroup, right)
        }
        return Quad(
            defaultConversation.ifBlank { "WhatsApp Contact" },
            defaultConversation.ifBlank { "WhatsApp Chat" },
            false,
            line
        )
    }

    private fun extractSenderFromColonPrefix(text: String, conversationName: String): String? {
        val colonIdx = text.indexOf(": ")
        if (colonIdx in 1..40) {
            val candidate = text.substring(0, colonIdx).trim()
            if (!candidate.equals(conversationName, ignoreCase = true)) {
                return candidate
            }
        }
        return null
    }

    private fun stripLeadingSenderIfRedundant(text: String, sender: String, isGroup: Boolean): String {
        if (!isGroup) return text
        val prefix = "$sender: "
        return if (text.startsWith(prefix) && text.length > prefix.length) {
            text.removePrefix(prefix).trim()
        } else {
            text
        }
    }
}
