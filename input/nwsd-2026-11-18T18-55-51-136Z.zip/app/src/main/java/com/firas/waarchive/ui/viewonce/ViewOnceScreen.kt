package com.firas.waarchive.ui.viewonce

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Photo
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.firas.waarchive.models.ViewOnceEventUi
import com.firas.waarchive.models.ViewOnceMediaKind
import com.firas.waarchive.ui.components.EmptyArchiveState
import com.firas.waarchive.ui.components.LimitationInfoBanner
import com.firas.waarchive.ui.components.StatusTag
import com.firas.waarchive.ui.components.formatTimestamp
import com.firas.waarchive.ui.theme.AmberWarning
import com.firas.waarchive.ui.theme.SkyMedia
import com.firas.waarchive.ui.theme.VioletViewOnce

@Composable
fun ViewOnceScreen(
    events: List<ViewOnceEventUi>,
    onDeleteEvent: (Long) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            LimitationInfoBanner(
                title = "Technical Limitation — View Once Media",
                body = "This app only records View Once events when WhatsApp explicitly exposes a View Once marker in notification metadata. In many WhatsApp versions, View Once notifications only say \"Photo\" without a View Once flag (those appear under All Messages / Diagnostics). Original View Once photos and videos are encrypted inside WhatsApp's private sandbox and CANNOT be saved or recovered via Android NotificationListenerService."
            )
        }

        if (events.isEmpty()) {
            item {
                EmptyArchiveState(
                    icon = Icons.Rounded.VisibilityOff,
                    title = "No Confirmed View Once Events",
                    subtitle = "Confirmed View Once notification metadata appears here only when WhatsApp explicitly discloses a View Once marker. Check Diagnostics to inspect raw incoming media notification flags."
                )
            }
        } else {
            items(events, key = { it.id }) { event ->
                ViewOnceCard(
                    event = event,
                    onDelete = { onDeleteEvent(event.id) }
                )
            }
        }
    }
}

@Composable
private fun ViewOnceCard(
    event: ViewOnceEventUi,
    onDelete: () -> Unit
) {
    val kindIcon = when (event.mediaKind) {
        ViewOnceMediaKind.PHOTO -> Icons.Rounded.Photo
        ViewOnceMediaKind.VIDEO -> Icons.Rounded.Videocam
        ViewOnceMediaKind.UNKNOWN -> Icons.Rounded.VisibilityOff
    }
    val kindLabel = when (event.mediaKind) {
        ViewOnceMediaKind.PHOTO -> "VIEW ONCE PHOTO"
        ViewOnceMediaKind.VIDEO -> "VIEW ONCE VIDEO"
        ViewOnceMediaKind.UNKNOWN -> "VIEW ONCE MEDIA"
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, VioletViewOnce.copy(alpha = 0.45f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = kindIcon,
                        contentDescription = null,
                        tint = VioletViewOnce,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = event.senderName,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (event.isGroupChat) "Group: ${event.conversationName}" else event.conversationName,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Rounded.DeleteOutline,
                        contentDescription = "Delete View Once event",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatusTag(label = kindLabel, color = VioletViewOnce)
                StatusTag(
                    label = if (event.isMediaContentAvailable) "MEDIA AVAILABLE" else "IMAGE UNAVAILABLE",
                    color = if (event.isMediaContentAvailable) SkyMedia else AmberWarning
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Captured Notice: \"${event.rawNotice}\"",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Event Time: ${formatTimestamp(event.notificationTimestamp)}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = event.limitationNote,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
