package com.firas.waarchive.models

enum class MessageCategory {
    TEXT,
    IMAGE,
    VIDEO,
    AUDIO,
    VOICE_NOTE,
    DOCUMENT,
    STICKER,
    VIEW_ONCE_PHOTO,
    VIEW_ONCE_VIDEO,
    VIEW_ONCE_UNKNOWN,
    DELETED_NOTICE,
    SYSTEM
}

enum class MediaType {
    PHOTO,
    VIDEO
}

enum class ViewOnceMediaKind {
    PHOTO,
    VIDEO,
    UNKNOWN
}

enum class DeletionMatchConfidence {
    HIGH,
    MEDIUM,
    UNMATCHED
}

enum class DateRangeFilter {
    ALL_TIME,
    TODAY,
    LAST_7_DAYS,
    LAST_30_DAYS
}

enum class NotificationDiagnosticStatus {
    NOTIFICATION_RECEIVED,
    WHATSAPP_IDENTIFIED,
    MESSAGE_TEXT_EXTRACTED,
    MESSAGE_SAVED_SUCCESSFULLY,
    NO_MESSAGE_TEXT_EXPOSED,
    POSSIBLE_MEDIA_NOTIFICATION,
    VIEW_ONCE_IDENTIFIED,
    DELETION_NOTICE_RECORDED,
    DATABASE_SAVE_FAILED
}
