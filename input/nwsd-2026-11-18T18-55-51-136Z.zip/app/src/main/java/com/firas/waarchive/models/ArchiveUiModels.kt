package com.firas.waarchive.models

data class ArchivedMessageUi(
    val id: Long,
    val notificationKey: String,
    val notificationId: Int,
    val conversationKey: String,
    val notificationTitle: String,
    val senderName: String,
    val conversationName: String,
    val isGroupChat: Boolean,
    val messageText: String,
    val bigText: String?,
    val category: MessageCategory,
    val notificationTimestamp: Long,
    val archivedAt: Long,
    val isDeleted: Boolean,
    val linkedDeletionEventId: Long?,
    val deletionDetectedAt: Long?,
    val sourcePackage: String
)

data class DeletionEventUi(
    val id: Long,
    val notificationKey: String,
    val conversationKey: String,
    val senderName: String,
    val conversationName: String,
    val noticeText: String,
    val detectedAt: Long,
    val matchedMessageId: Long?,
    val matchConfidence: DeletionMatchConfidence,
    val matchedOriginalText: String?
)

data class ViewOnceEventUi(
    val id: Long,
    val notificationKey: String,
    val senderName: String,
    val conversationName: String,
    val isGroupChat: Boolean,
    val mediaKind: ViewOnceMediaKind,
    val rawNotice: String,
    val notificationTimestamp: Long,
    val archivedAt: Long,
    val isMediaContentAvailable: Boolean,
    val limitationNote: String
)

data class NormalMediaUi(
    val id: Long,
    val contentHash: String,
    val originalFileName: String,
    val sourceDocumentUri: String,
    val privateFilePath: String,
    val mediaType: MediaType,
    val mimeType: String,
    val fileSizeBytes: Long,
    val senderAssociation: String?,
    val fileLastModified: Long,
    val archivedAt: Long
)

data class ConversationSummaryUi(
    val conversationKey: String,
    val displayName: String,
    val isGroup: Boolean,
    val messageCount: Int,
    val lastMessageAt: Long,
    val deletedCount: Int,
    val viewOnceCount: Int
)

data class DiagnosticLogUi(
    val id: Long,
    val timestamp: Long,
    val level: String,
    val tag: String,
    val message: String
)

data class NotificationDiagnosticUi(
    val id: Long,
    val timestamp: Long,
    val sourcePackage: String,
    val isWhatsAppPackage: Boolean,
    val notificationKey: String,
    val notificationId: Int,
    val isGroupSummary: Boolean,
    val notificationTitle: String,
    val hasExtraText: Boolean,
    val hasExtraBigText: Boolean,
    val hasExtraTextLines: Boolean,
    val messagingStyleCount: Int,
    val extractedTextCount: Int,
    val databaseSaveSucceeded: Boolean,
    val savedRecordCount: Int,
    val status: NotificationDiagnosticStatus,
    val reasonDetail: String
)

data class ListenerStatus(
    val isPermissionGranted: Boolean = false,
    val isServiceConnected: Boolean = false,
    val isPostNotificationsGranted: Boolean = false,
    val lastConnectedAt: Long? = null,
    val lastEventAt: Long? = null,
    val lastSuccessfulArchiveAt: Long? = null,
    val observedNotificationCount: Int = 0
)

data class DashboardStats(
    val totalMessages: Int = 0,
    val deletedRecords: Int = 0,
    val viewOnceEvents: Int = 0,
    val archivedMediaCount: Int = 0,
    val totalObservations: Int = 0,
    val conversationsCount: Int = 0
)

data class ArchiveFilterState(
    val searchQuery: String = "",
    val selectedConversation: String? = null,
    val selectedSender: String? = null,
    val onlyGroupChats: Boolean? = null,
    val selectedCategory: MessageCategory? = null,
    val onlyDeleted: Boolean = false,
    val dateRange: DateRangeFilter = DateRangeFilter.ALL_TIME
)
