package com.firas.waarchive.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.firas.waarchive.models.ViewOnceMediaKind

@Entity(
    tableName = "view_once_events",
    indices = [
        Index(value = ["dedupHash"], unique = true),
        Index(value = ["notificationTimestamp"])
    ]
)
data class ViewOnceEventEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val dedupHash: String,
    val notificationKey: String,
    val encryptedSenderName: String,
    val encryptedConversationName: String,
    val isGroupChat: Boolean,
    val mediaKind: ViewOnceMediaKind,
    val encryptedRawNotice: String,
    val notificationTimestamp: Long,
    val archivedAt: Long,
    val isMediaContentAvailable: Boolean = false,
    val limitationNote: String
)
