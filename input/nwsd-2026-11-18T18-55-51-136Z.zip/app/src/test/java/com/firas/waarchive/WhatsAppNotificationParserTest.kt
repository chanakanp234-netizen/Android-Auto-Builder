package com.firas.waarchive

import com.firas.waarchive.models.ViewOnceMediaKind
import com.firas.waarchive.notifications.WhatsAppNotificationParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WhatsAppNotificationParserTest {

    @Test
    fun testA_and_testC_deletionPhraseDetection() {
        assertTrue(WhatsAppNotificationParser.isExplicitDeletionNotice("This message was deleted"))
        assertTrue(WhatsAppNotificationParser.isExplicitDeletionNotice("You deleted this message"))
        assertFalse(WhatsAppNotificationParser.isExplicitDeletionNotice("Hey, are you free tonight?"))
    }

    @Test
    fun testB_groupConversationTitleNormalization() {
        assertEquals(
            "Family Group",
            WhatsAppNotificationParser.cleanConversationName("Family Group (3 messages): Alice")
        )
        assertEquals(
            "Project Team",
            WhatsAppNotificationParser.cleanConversationName("Project Team (12 messages)")
        )
    }

    @Test
    fun testD_boilerplateSummaryDetection() {
        assertTrue(WhatsAppNotificationParser.isBoilerplateSystemText("2 new messages"))
        assertTrue(WhatsAppNotificationParser.isBoilerplateSystemText("5 new messages from 2 chats"))
        assertTrue(WhatsAppNotificationParser.isBoilerplateSystemText("Checking for new messages"))
        assertFalse(WhatsAppNotificationParser.isBoilerplateSystemText("See you at 6pm"))
    }

    @Test
    fun testE_viewOnceExplicitDetectionVsOrdinaryPhoto() {
        assertEquals(
            ViewOnceMediaKind.PHOTO,
            WhatsAppNotificationParser.detectViewOnceKind("📷 Photo (View once)", null)
        )
        assertEquals(
            ViewOnceMediaKind.VIDEO,
            WhatsAppNotificationParser.detectViewOnceKind("🎥 View once video", null)
        )
        // Ordinary "📷 Photo" without explicit View Once marker must NOT be falsely classified as View Once
        assertNull(
            WhatsAppNotificationParser.detectViewOnceKind("📷 Photo", "image/jpeg")
        )
    }
}
