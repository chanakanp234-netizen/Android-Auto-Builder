# Real-World Device Test Plan — WA Message Archive Pro

Target device: **Infinix Smart 8 (X6525) · Android 13 (XOS 13) · Official WhatsApp (`com.whatsapp`) · No Root**

> **Verification Status Note**: Unit compilation and `./gradlew assembleDebug` could not run inside the web build sandbox because JDK 17 and the Android SDK are absent there. Build the APK via `xtobi/Android-Auto-Builder`, install on your Infinix Smart 8, enable **Special Notification Access**, and run Tests A–E below.

---

## TEST A — Normal Text Message
- **Procedure**: With WhatsApp closed/backgrounded on the Infinix Smart 8, send `"Test message alpha"` from another phone.
- **Expected Result**: App archives sender name, conversation name, `"Test message alpha"`, and timestamp in **All Messages**, and Diagnostics logs `MESSAGE_SAVED_SUCCESSFULLY` with `hasExtraText = true` / `databaseSaveSucceeded = true`.
- **Implementation Behavior**: `WhatsAppNotificationParser` extracts via `NotificationCompat.MessagingStyle`, direct `Bundle` array inspection (avoiding Android 13 `getParcelableArray(key, Class)` pitfall), `EXTRA_TEXT_LINES`, `EXTRA_BIG_TEXT`, and `EXTRA_TEXT`. `ArchiveProcessor` serializes writes with a `Mutex` and persists encrypted records to Room.
- **Status**: Pending real-device verification.
- **Platform Limitation**: Messages received while that exact WhatsApp chat is actively open on screen do not trigger Android notifications.

## TEST B — Group Message
- **Procedure**: Have a member send `"Group ping 123"` in a WhatsApp group while the chat is not open.
- **Expected Result**: App archives the group name as conversation, the individual member as sender, `"Group ping 123"`, and timestamp.
- **Implementation Behavior**: Normalizes `"Group Name (N messages): Sender"` and `EXTRA_CONVERSATION_TITLE` so `conversationKey` remains consistent across single and bundled group notifications, and strips redundant `"Sender: "` prefixes cleanly.
- **Status**: Pending real-device verification.
- **Platform Limitation**: Muted groups with disabled notifications do not emit notification content.

## TEST C — Delete for Everyone
- **Procedure**: Send `"Temporary secret text"` from another phone, confirm it appears in **All Messages** (or `MESSAGE_SAVED_SUCCESSFULLY` in **Diagnostics**), then choose **Delete for everyone** on the sender phone.
- **Expected Result**: The original `"Temporary secret text"` remains intact in **All Messages** with a `DELETED LATER` badge, and **Deleted Messages** records the deletion notice paired with the original archived text.
- **Implementation Behavior**: Original message rows are never overwritten on notification update (`OnConflictStrategy.IGNORE` + separate `deletion_events` table). Correlation prioritizes exact timestamp match (`±3s` for multi-message `MessagingStyle` stacks), `notificationKey`, and sender within 48 hours. `onNotificationRemoved()` never marks a message deleted.
- **Status**: Pending real-device verification.
- **Platform Limitation**: If WhatsApp never exposed the original text in a notification before deletion (e.g., chat was open or previews hidden), the original text cannot be reconstructed afterward.

## TEST D — Notification Preview Disabled
- **Procedure**: Enable WhatsApp fingerprint lock / disable notification previews so WhatsApp only posts `"2 new messages"` or empty `EXTRA_TEXT`, then send a message.
- **Expected Result**: App does NOT save `"2 new messages"` or empty strings as fake archived messages; **Diagnostics** records `NO_MESSAGE_TEXT_EXPOSED` with the exact reason (`Summary notification boilerplate` or `No readable text in EXTRA_TEXT / MessagingStyle`).
- **Implementation Behavior**: `isBoilerplateSystemText()` filters summary boilerplate while logging a transparent `NotificationDiagnosticEntity` explaining why no message text was available.
- **Status**: Pending real-device verification.
- **Platform Limitation**: Android `NotificationListenerService` cannot read hidden message text when previews are suppressed by WhatsApp or Android lockscreen settings.

## TEST E — View Once Photo
- **Procedure**: Send a View Once photo from another phone and inspect **View Once Events** and **Diagnostics**.
- **Expected Result**:
  - If WhatsApp explicitly exposes a View Once marker in notification metadata, **View Once Events** saves sender, chat, timestamp, and `VIEW ONCE PHOTO`, and explicitly marks `IMAGE UNAVAILABLE`.
  - If WhatsApp only posts `"📷 Photo"` without any View Once indicator, **Diagnostics** logs `POSSIBLE_MEDIA_NOTIFICATION` and archives the notification text honestly without falsely claiming it is View Once or inventing a photo.
- **Implementation Behavior**: Never bypasses WhatsApp privacy protections, never accesses `/data/data/com.whatsapp`, and never saves an unrelated thumbnail as the View Once photo.
- **Status**: Pending real-device verification.
- **Platform Limitation**: Official Android APIs (`NotificationListenerService`) never receive protected View Once image or video bytes.
