package com.ins.leadskeyboard;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.inputmethodservice.InputMethodService;
import android.net.Uri;
import android.os.Build;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import java.util.ArrayList;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class InsInputMethodService extends InputMethodService {
    private LinearLayout root;
    private boolean sinhala=false, shifted=false, symbols=false, clipboardPage=false;
    private String pendingMark="";
    private int bg,keyBg,keyFg,specialBg,accent,keyHeight;
    private ClipboardManager clipboard;
    private ClipboardManager.OnPrimaryClipChangedListener clipListener;
    private final String[] rows={"qwertyuiop","asdfghjkl","zxcvbnm"};
    // Wijesekara-inspired Sinhala key layers. Users can switch language from the toolbar.
    private final String[][] si={
        {"ු|ූ","අ|උ","ැ|ෑ","ර|ඍ","එ|ඔ","හ|ශ","ම|ඹ","ස|ෂ","ද|ධ","ච|ඡ"},
        {"්|ෟ","ි|ී","ා|ෘ","ෙ|ෆ","ට|ඨ","ය|්‍ය","ව|ළු","න|ණ","ක|ඛ"},
        {"ඤ|ඥ","ං|ඃ","ජ|ඦ","ඩ|ඬ","ඉ|ඊ","බ|භ","ප|ඵ"}
    };

    @Override public void onCreate() {
        super.onCreate();
        clipboard=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        clipListener=()->captureClipboard();
    }
    @Override public View onCreateInputView(){ buildKeyboard(); return root; }
    @Override public void onStartInputView(EditorInfo info, boolean restarting){
        super.onStartInputView(info,restarting);
        if(clipboard!=null) clipboard.addPrimaryClipChangedListener(clipListener);
        buildKeyboard();
    }
    @Override public void onFinishInputView(boolean finishingInput){
        if(clipboard!=null && clipListener!=null) clipboard.removePrimaryClipChangedListener(clipListener);
        super.onFinishInputView(finishingInput);
    }

    private void colors(){
        // INS Colorful mobile theme: bright, friendly, high-contrast touch keys.
        bg=0xfff4f6ff;
        keyBg=0xffffffff;
        keyFg=0xff26324a;
        specialBg=0xffe5eaff;
        accent=0xffe83e73;
        int h=getSharedPreferences("ins_keyboard",MODE_PRIVATE).getInt("height",2);
        keyHeight=h==0?58:(h==2?66:62);
    }
    private void buildKeyboard(){
        colors();
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(6,5,6,8);
        GradientDrawable panel=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{0xfff7f8ff,0xffedf2ff});
        panel.setCornerRadius(dp(18)); root.setBackground(panel);
        if(Build.VERSION.SDK_INT>=20){
            root.setOnApplyWindowInsetsListener((v,insets)->{
                int bottom=0;
                if(Build.VERSION.SDK_INT>=30) bottom=insets.getInsets(WindowInsets.Type.navigationBars()).bottom;
                else if(Build.VERSION.SDK_INT>=20) bottom=insets.getSystemWindowInsetBottom();
                v.setPadding(5,5,5,Math.max(8,bottom)); return insets;
            });
        }
        if(clipboardPage){ buildClipboardPage(); return; }
        // One compact toolbar preserves vertical room for larger, easier-to-touch letter keys.
        LinearLayout top=row();
        addWide(top,"INS LEADS",0xffe83e73,()->openLeads(),1.25f);
        addWide(top,"▤ Clipboard",0xff7c63e8,()->{clipboardPage=true;buildKeyboard();},1.05f);
        addWide(top,sinhala?"සිං":"EN",0xff20a7a0,()->{sinhala=!sinhala;pendingMark="";buildKeyboard();},0.58f);
        addWide(top,"☺",0xffffa43a,()->insert("😊"),0.42f);
        addWide(top,"⚙",0xff4d83df,()->openSettings(),0.42f);
        root.addView(top,lp(-1,46));
        addNumberRow();
        if(symbols) buildSymbols(); else buildLetters();
        LinearLayout bottom=row(); addSpecial(bottom,"?123",52,()->{symbols=!symbols;buildKeyboard();}); addSpecial(bottom,"☺",48,()->insert("😊"));
        Button space=key(sinhala?"සිංහල  •  Space":"English  •  Space",0xffdce8ff,keyFg,13); bottom.addView(space,weight(1,Math.max(60,keyHeight-4),3)); space.setOnClickListener(v->insert(" "));
        addSpecial(bottom,".,?",48,()->insert(".")); addSpecial(bottom,"↵",52,()->sendEnter()); root.addView(bottom);
    }
    private void buildClipboardPage(){
        LinearLayout head=row(); addWide(head,"← Back",specialBg,()->{clipboardPage=false;buildKeyboard();},1); addWide(head,"Clear All",accent,()->{saveHistory(new JSONArray());buildKeyboard();},1); root.addView(head,lp(-1,52));
        TextView title=new TextView(this);title.setText("Clipboard history  •  up to 30 items\nTap to paste  •  Long-press to delete");title.setTextColor(keyFg);title.setTextSize(14);title.setPadding(10,12,10,12);root.addView(title);
        ScrollView scroll=new ScrollView(this); LinearLayout list=new LinearLayout(this);list.setOrientation(1);
        JSONArray data=loadHistory();
        for(int i=0;i<data.length();i++){
            final String item=data.optString(i,""); if(item.isEmpty())continue;
            LinearLayout line=row(); TextView txt=new TextView(this);txt.setText(item);txt.setTextColor(keyFg);txt.setTextSize(15);txt.setMaxLines(3);txt.setPadding(12,12,8,12);txt.setBackgroundTintList(ColorStateList.valueOf(keyBg));txt.setBackgroundColor(keyBg);line.addView(txt,weight(1,-2,1));
            Button del=key("✕",specialBg,keyFg,18);line.addView(del,lp(54,54));del.setOnClickListener(v->{removeHistory(item);buildKeyboard();});
            txt.setOnClickListener(v->{insert(item);clipboardPage=false;buildKeyboard();}); txt.setOnLongClickListener(v->{removeHistory(item);buildKeyboard();return true;});
            LinearLayout.LayoutParams p=lp(-1,-2);p.setMargins(2,3,2,3);list.addView(line,p);
        }
        if(data.length()==0){TextView empty=new TextView(this);empty.setText("No copied messages yet. Copy text while INS Keyboard is open.");empty.setTextColor(keyFg);empty.setPadding(16,24,16,24);list.addView(empty);}
        scroll.addView(list);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
    }
    private void buildLetters(){
        for(int r=0;r<3;r++){
            LinearLayout line=row(); String letters=rows[r];
            if(r==2)addSpecial(line,"⇧",58,()->{shifted=!shifted;buildKeyboard();});
            for(int i=0;i<letters.length();i++){
                final int rr=r,ii=i; String label;
                if(sinhala){String[] pair=si[r][i].split("\\|");label=pair[shifted?1:0];}
                else {String c=String.valueOf(letters.charAt(i));label=shifted?c.toUpperCase(Locale.ROOT):c;}
                Button b=key(label,letterColor(r,i),keyFg,sinhala?18:22);line.addView(b,weight(1,keyHeight,3));
                b.setOnClickListener(v->{if(sinhala){String[] pair=si[rr][ii].split("\\|");handleSinhala(pair[shifted?1:0]);}else{String c=String.valueOf(letters.charAt(ii));insert(shifted?c.toUpperCase(Locale.ROOT):c);}if(shifted){shifted=false;buildKeyboard();}});
            }
            if(r==2)addSpecial(line,"⌫",62,()->backspace());
            root.addView(line,lp(-1,keyHeight+2));
        }
    }
    private void buildSymbols(){
        String[][] data={{"1","2","3","4","5","6","7","8","9","0"},{"@","#","$","%","&","-","+","(",")","/"},{"*","\"","'",":",";","!","?",",",".","="}};
        for(String[] rr:data){LinearLayout line=row();for(String s:rr){Button b=key(s,keyBg,keyFg,20);line.addView(b,weight(1,keyHeight,3));b.setOnClickListener(v->insert(s));}root.addView(line);}
        LinearLayout line=row();addSpecial(line,"ABC",72,()->{symbols=false;buildKeyboard();});addSpecial(line,"⌫",62,()->backspace());root.addView(line);
    }
    private void addNumberRow(){LinearLayout line=row();for(String n:new String[]{"1","2","3","4","5","6","7","8","9","0"}){Button b=key(n,numberColor(Integer.parseInt(n)),keyFg,20);line.addView(b,weight(1,46,3));b.setOnClickListener(v->insert(n));}root.addView(line,lp(-1,50));}
    private void handleSinhala(String s){
        if(s.equals("ැ")||s.equals("ෑ")||s.equals("ෙ")){pendingMark=s;return;}
        if(!pendingMark.isEmpty()){String mark=pendingMark;pendingMark="";insert(s+mark);return;}
        insert(s);
    }
    private void insert(String s){InputConnection ic=getCurrentInputConnection();if(ic!=null)ic.commitText(s,1);}
    private void backspace(){InputConnection ic=getCurrentInputConnection();if(ic==null)return;if(!pendingMark.isEmpty()){pendingMark="";return;}CharSequence selected=ic.getSelectedText(0);if(!TextUtils.isEmpty(selected))ic.commitText("",1);else ic.deleteSurroundingText(1,0);}
    private void sendEnter(){InputConnection ic=getCurrentInputConnection();if(ic==null)return;int action=getCurrentInputEditorInfo()!=null?getCurrentInputEditorInfo().imeOptions&EditorInfo.IME_MASK_ACTION:EditorInfo.IME_ACTION_NONE;if(action!=EditorInfo.IME_ACTION_NONE&&action!=EditorInfo.IME_ACTION_UNSPECIFIED)ic.performEditorAction(action);else ic.commitText("\n",1);}
    private void captureClipboard(){
        try{if(clipboard==null||!clipboard.hasPrimaryClip())return;ClipData clip=clipboard.getPrimaryClip();if(clip==null||clip.getItemCount()==0)return;CharSequence cs=clip.getItemAt(0).coerceToText(this);if(cs==null)return;String text=cs.toString().trim();if(text.isEmpty())return;JSONArray old=loadHistory();ArrayList<String> items=new ArrayList<>();items.add(text);for(int i=0;i<old.length()&&items.size()<30;i++){String s=old.optString(i,"");if(!s.equals(text)&&!s.isEmpty())items.add(s);}JSONArray out=new JSONArray();for(String s:items)out.put(s);saveHistory(out);}catch(Exception ignored){}
    }
    private JSONArray loadHistory(){try{return new JSONArray(getSharedPreferences("ins_keyboard",MODE_PRIVATE).getString("clipboard_history","[]"));}catch(Exception e){return new JSONArray();}}
    private void saveHistory(JSONArray a){getSharedPreferences("ins_keyboard",MODE_PRIVATE).edit().putString("clipboard_history",a.toString()).apply();}
    private void removeHistory(String item){JSONArray old=loadHistory(),out=new JSONArray();for(int i=0;i<old.length();i++){String s=old.optString(i,"");if(!s.equals(item))out.put(s);}saveHistory(out);}
    private void openLeads(){String site=getSharedPreferences("ins_keyboard",MODE_PRIVATE).getString("app_url","");if(TextUtils.isEmpty(site)){Toast.makeText(this,"Settings තුළ Website URL එක Save කරන්න",Toast.LENGTH_LONG).show();openSettings();return;}String phone="";try{if(clipboard!=null&&clipboard.hasPrimaryClip()){CharSequence c=clipboard.getPrimaryClip().getItemAt(0).coerceToText(this);if(c!=null){Matcher m=Pattern.compile("(?:\\+?94|0)?\\s*7[0-9][\\s-]?[0-9]{3}[\\s-]?[0-9]{4}").matcher(c.toString());if(m.find())phone=m.group().replaceAll("[^0-9+]","");}}}catch(Exception ignored){}try{Uri.Builder u=Uri.parse(site).buildUpon();if(!phone.isEmpty())u.appendQueryParameter("phone",phone);u.appendQueryParameter("ins_keyboard","1");Intent i=new Intent(Intent.ACTION_VIEW,u.build());i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);}catch(Exception e){Toast.makeText(this,"INS website could not open",Toast.LENGTH_SHORT).show();}}
    private void openSettings(){Intent i=new Intent(this,SettingsActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER);return l;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private LinearLayout.LayoutParams weight(float w,int h,int margin){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,h,w);p.setMargins(margin+1,4,margin+1,4);return p;}
    private int[] keyPalette={0xffffe0e8,0xffffedcf,0xffe4f7e9,0xffdff2ff,0xffeee5ff,0xfffff0d9};
    private int letterColor(int row,int col){return keyPalette[(row*3+col)%keyPalette.length];}
    private int numberColor(int n){return new int[]{0xffffe4ed,0xffffedcf,0xffe4f7e9,0xffdff2ff,0xffeee5ff,0xfffff0d9}[n%6];}
    private Button key(String text,int color,int fg,int size){
        Button b=new Button(this); b.setText(text); b.setTextColor(fg); b.setTextSize(size);
        b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);
        b.setPadding(2,0,2,0); b.setMinWidth(0); b.setMinimumWidth(0); b.setMinHeight(0); b.setMinimumHeight(0);
        GradientDrawable shape=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{lighten(color),color});
        shape.setCornerRadius(dp(13));
        shape.setStroke(dp(1), blend(color,0xffaab6cf,0.32f));
        b.setBackground(shape); b.setElevation(dp(2));
        return b;
    }
    private int lighten(int color){
        int r=Color.red(color),g=Color.green(color),b=Color.blue(color);
        return Color.rgb((r+255)/2,(g+255)/2,(b+255)/2);
    }
    private int blend(int a,int b,float ratio){
        return Color.rgb((int)(Color.red(a)*(1-ratio)+Color.red(b)*ratio),
            (int)(Color.green(a)*(1-ratio)+Color.green(b)*ratio),
            (int)(Color.blue(a)*(1-ratio)+Color.blue(b)*ratio));
    }
    private int dp(float value){return (int)(value*getResources().getDisplayMetrics().density+0.5f);}
    private void addTool(LinearLayout line,String label,Runnable action){Button b=key(label,specialBg,keyFg,16);line.addView(b,weight(1,40,2));b.setOnClickListener(v->action.run());}
    private void addSpecial(LinearLayout line,String label,int width,Runnable action){Button b=key(label,specialBg,keyFg,18);line.addView(b,lp(width,keyHeight));b.setOnClickListener(v->action.run());}
    private void addWide(LinearLayout line,String label,int color,Runnable action,float weight){Button b=key(label,color,Color.WHITE,label.equals("INS LEADS")?14:13);line.addView(b,new LinearLayout.LayoutParams(0,-1,weight));b.setOnClickListener(v->action.run());LinearLayout.LayoutParams p=(LinearLayout.LayoutParams)b.getLayoutParams();p.setMargins(3,2,3,2);b.setLayoutParams(p);}
}
