# INS Professional Keyboard V3

මෙය INS Keyboard Android IME source project V3 එකයි.

## V3 වෙනස්කම්
- එක් එක් අකුරු යතුර වෙනම rounded box එකකින් පෙන්වයි.
- Tall / Standard / Compact key height settings (default Tall).
- ඉහළින් විශාල INS LEADS සහ Clipboard බොත්තම්.
- Clipboard History: Keyboard active විට Android clipboard change event එකක් ලැබුණු විට text item එක locally save කරයි.
- Clipboard එකේ අවසන් items 30ක් දක්වා තබාගනී.
- එක් එක් item එක Paste හෝ Delete කළ හැකියි; Clear all ද ඇත.
- Android navigation area සඳහා bottom inset padding සහ keyboard bottom spacing එක වැඩිදියුණු කර ඇත.
- Sinhala / English switch, number row, emoji, symbols, Shift, Backspace, Enter.
- Existing INS Leads shortcut තබා ඇත.

## Build
මෙම ZIP එක සම්පූර්ණ Android Gradle project එකකි. ZIP එක `Android-Auto-Builder` repository හි `input/` folder එකට upload කර `main` branch එකට commit කරන්න. GitHub Actions build සාර්ථක වුවහොත් `android-debug-apk` artifact එක download කරන්න.

## වැදගත් සීමාවන්
- මෙම source එක මෙහි Android SDK/Gradle build environment එකක් නොමැති නිසා local APK ලෙස build කර පරීක්ෂා කර නැත. GitHub Actions build සහ සැබෑ Android phone පරීක්ෂාව අවශ්‍යයි.
- Clipboard history එක Keyboard activeව තිබෙන අතර Android clipboard change callback එක ලබාදෙන අවස්ථාවලදී පමණක් එකතු වේ. Android privacy restrictions නිසා Keyboard එක වසා තිබියදී සිදුවන සෑම copy event එකක්ම ලබාගත හැකි බවට සහතිකයක් නැත.
- Clipboard items මෙම device එකේ app-private preferences තුළ locally ගබඩා කරයි; server එකකට යවන්නේ නැත.
- Wijesekara mapping එකේ advanced layers, full Sinhala predictive dictionary සහ autocorrect තවම සම්පූර්ණ නැත.
- APK update කිරීමේදී package name සහ signing key එක පෙර build එකට ගැළපිය යුතුය. එසේ නොවේ නම් පැරණි app එක uninstall කිරීමට සිදුවිය හැකියි.
