package com.ins.leadskeyboard;

import android.inputmethodservice.InputMethodService;
import android.view.*;
import android.view.inputmethod.*;
import android.content.*;
import android.content.ClipboardManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.widget.*;
import android.text.TextUtils;
import java.util.*;

public class InsInputMethodService extends InputMethodService {
    private LinearLayout root;
    private boolean sinhala=false, shifted=false, symbols=false;
    private String pendingMark="";
    private int bg, keyBg, keyFg, specialBg, accent;
    private final String[] EN1={"qwertyuiop","asdfghjkl","zxcvbnm"};
    // SLS 1134 / Wijesekara-based QWERTY mapping. Lower/upper states follow the standard key layers.
    private final String[][] SI={
      {"ු|ූ","අ|උ","ැ|ෑ","ර|ඍ","එ|ඔ","හ|ශ","ම|ඹ","ස|ෂ","ද|ධ","ච|ඡ"},
      {"්|ෟ","ි|ී","ා|ෘ","ෙ|ෆ","ට|ඨ","ය|්‍ය","ව|ළු","න|ණ","ක|ඛ"},
      {"ඤ|ඥ","ං|ඃ","ජ|ඦ","ඩ|ඬ","ඉ|ඊ","බ|භ","ප|ඵ"}
    };
    private final String[] SI_KEYS={"qwertyuiop","asdfghjkl","zxcvbnm"};
    private final String[] QUICK_SI={"මම","ඔබ","අපි"};
    private final String[] QUICK_EN={"the","you","and"};
    private int keyHeight=58;
    private ClipboardManager clipboardManager;
    private ClipboardManager.OnPrimaryClipChangedListener clipListener;
    private boolean showClipboard=false;
    private static final String CLIP_PREF="clipboard_history";
    private static final int MAX_CLIPS=30;

    @Override public View onCreateInputView(){
        clipboardManager=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        clipListener=()->captureClipboard();
        buildKeyboard(); return root;
    }
    @Override public void onStartInputView(EditorInfo info, boolean restarting){
        super.onStartInputView(info,restarting);
        if(clipboardManager!=null && clipListener!=null){try{clipboardManager.removePrimaryClipChangedListener(clipListener);clipboardManager.addPrimaryClipChangedListener(clipListener);}catch(Exception ignored){}}
        buildKeyboard();
    }
    @Override public void onFinishInputView(boolean finishingInput){
        if(clipboardManager!=null && clipListener!=null){try{clipboardManager.removePrimaryClipChangedListener(clipListener);}catch(Exception ignored){}}
        super.onFinishInputView(finishingInput);
    }
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private ArrayList<String> clips(){ArrayList<String> out=new ArrayList<>();String raw=getSharedPreferences("ins_keyboard",MODE_PRIVATE).getString(CLIP_PREF,"[]");try{org.json.JSONArray a=new org.json.JSONArray(raw);for(int i=0;i<a.length();i++){String t=a.optString(i,"");if(!t.isEmpty())out.add(t);}}catch(Exception ignored){}return out;}
    private void saveClips(ArrayList<String> list){org.json.JSONArray a=new org.json.JSONArray();for(String t:list)a.put(t);getSharedPreferences("ins_keyboard",MODE_PRIVATE).edit().putString(CLIP_PREF,a.toString()).apply();}
    private void captureClipboard(){try{if(clipboardManager==null||!clipboardManager.hasPrimaryClip())return;CharSequence c=clipboardManager.getPrimaryClip().getItemAt(0).coerceToText(this);if(c==null)return;String t=c.toString().trim();if(t.isEmpty())return;ArrayList<String> list=clips();list.remove(t);list.add(0,t);while(list.size()>MAX_CLIPS)list.remove(list.size()-1);saveClips(list);if(showClipboard)buildKeyboard();}catch(Exception ignored){}}
    private void showClipboardPanel(){showClipboard=true;buildKeyboard();}
    private void hideClipboardPanel(){showClipboard=false;buildKeyboard();}
    private void deleteClip(String value){ArrayList<String> list=clips();list.remove(value);saveClips(list);buildKeyboard();}
    private void clearClips(){saveClips(new ArrayList<>());buildKeyboard();}
    private void pasteClip(String value){insert(value);showClipboard=false;buildKeyboard();}
    private void colors(){boolean dark=getSharedPreferences("ins_keyboard",MODE_PRIVATE).getBoolean("dark",true); if(dark){bg=0xff17191d;keyBg=0xff292c31;keyFg=0xfff5f6f8;specialBg=0xff41454d;accent=0xffc5223b;}else{bg=0xffe9edf2;keyBg=Color.WHITE;keyFg=0xff202938;specialBg=0xffd5dce6;accent=0xffb4232f;} int h=getSharedPreferences("ins_keyboard",MODE_PRIVATE).getInt("height",2);keyHeight=h==0?46:(h==2?56:51);}
    private void buildKeyboard(){
        colors();
        root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(5),dp(5),dp(5),dp(12));root.setBackgroundColor(bg);root.setClipToPadding(false);
        root.setOnApplyWindowInsetsListener((v,insets)->{int bottom=0;if(android.os.Build.VERSION.SDK_INT>=29)bottom=insets.getSystemWindowInsetBottom();v.setPadding(dp(5),dp(5),dp(5),Math.max(dp(12),bottom+dp(8)));return insets;});
        try{if(getWindow()!=null){getWindow().setNavigationBarColor(bg);if(android.os.Build.VERSION.SDK_INT>=29)getWindow().setNavigationBarContrastEnforced(false);}}catch(Exception ignored){}
        LinearLayout top=row();
        addWideTool(top,"INS LEADS",()->openLeads(),accent,0xffFFFFFF,1.15f);
        addWideTool(top,showClipboard?"⌨ Keyboard":"▤ Clipboard",()->{showClipboard=!showClipboard;buildKeyboard();},specialBg,keyFg,1.15f);
        addWideTool(top,"⌄",()->openSettings(),specialBg,keyFg,0.38f);root.addView(top,new LinearLayout.LayoutParams(-1,dp(44)));
        if(showClipboard){buildClipboardPanel();return;}
        LinearLayout tools=row();addTool(tools,"☺",()->insert("😊"));addTool(tools,"GIF",()->insert("😊"));addTool(tools,"▤",()->showClipboardPanel());addTool(tools,sinhala?"සිංහල":"EN",()->{sinhala=!sinhala;symbols=false;pendingMark="";buildKeyboard();});addTool(tools,"🎙",()->Toast.makeText(this,"Voice typing is available through Android",Toast.LENGTH_SHORT).show());addTool(tools,"⚙",()->openSettings());root.addView(tools,new LinearLayout.LayoutParams(-1,dp(34)));
        LinearLayout suggestions=row();String[] quick=sinhala?QUICK_SI:QUICK_EN;for(String w:quick){Button b=key(w,keyBg,keyFg,15);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(30),1);p.setMargins(dp(2),dp(1),dp(2),dp(2));suggestions.addView(b,p);b.setOnClickListener(v->insert(w+" "));}root.addView(suggestions);
        addNumberRow();
        if(symbols) buildSymbols(); else buildLetters();
        LinearLayout bottom=row();
        addBottomKey(bottom,"?123",()->{symbols=!symbols;pendingMark="";buildKeyboard();},0.85f);
        addBottomKey(bottom,"☺",()->insert("😊"),0.72f);
        addBottomKey(bottom,sinhala?"සිං":"EN",()->{sinhala=!sinhala;pendingMark="";buildKeyboard();},0.8f);
        Button space=key(sinhala?"සිංහල  •  Space":"English  •  Space",keyBg,keyFg,14);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(50),3.2f);sp.setMargins(dp(2),dp(3),dp(2),dp(3));bottom.addView(space,sp);space.setOnClickListener(v->insert(" "));
        addBottomKey(bottom,". , ?",()->insert("."),0.8f);
        addBottomKey(bottom,"↵",()->{InputConnection ic=getCurrentInputConnection();if(ic!=null)ic.commitText("\n",1);},0.85f);
        root.addView(bottom,new LinearLayout.LayoutParams(-1,dp(56)));
    }
    private void buildClipboardPanel(){
        LinearLayout head=row();TextView title=new TextView(this);title.setText("Clipboard History  •  "+clips().size()+"/"+MAX_CLIPS);title.setTextColor(keyFg);title.setTextSize(16);title.setTypeface(null,1);head.addView(title,new LinearLayout.LayoutParams(0,dp(36),1));Button clear=key("Clear all",accent,Color.WHITE,12);head.addView(clear,new LinearLayout.LayoutParams(dp(88),dp(38)));clear.setOnClickListener(v->clearClips());Button done=key("Done",specialBg,keyFg,12);head.addView(done,new LinearLayout.LayoutParams(dp(65),dp(38)));done.setOnClickListener(v->hideClipboardPanel());root.addView(head);
        ScrollView scroll=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(1);ArrayList<String> items=clips();
        if(items.isEmpty()){TextView empty=new TextView(this);empty.setText("No copied messages yet. Copy text in WhatsApp while INS Keyboard is active.");empty.setTextColor(keyFg);empty.setTextSize(14);empty.setPadding(dp(12),dp(18),dp(12),dp(18));list.addView(empty);}else for(String item:items){LinearLayout line=row();TextView text=new TextView(this);text.setText(item);text.setTextColor(keyFg);text.setTextSize(14);text.setMaxLines(2);text.setEllipsize(android.text.TextUtils.TruncateAt.END);text.setGravity(Gravity.CENTER_VERTICAL);text.setPadding(dp(10),dp(5),dp(5),dp(5));line.addView(text,new LinearLayout.LayoutParams(0,dp(54),1));Button paste=key("Paste",accent,Color.WHITE,12);line.addView(paste,new LinearLayout.LayoutParams(dp(62),dp(46)));paste.setOnClickListener(v->pasteClip(item));Button del=key("✕",specialBg,keyFg,15);line.addView(del,new LinearLayout.LayoutParams(dp(44),dp(46)));del.setOnClickListener(v->deleteClip(item));list.addView(line);View divider=new View(this);divider.setBackgroundColor(specialBg);list.addView(divider,new LinearLayout.LayoutParams(-1,dp(1)));}
        scroll.addView(list);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
    }
    private void addWideTool(LinearLayout row,String label,Runnable action,int color,int fg,float weight){Button b=key(label,color,fg,label.length()>9?15:17);b.setTypeface(null,1);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,weight);p.setMargins(dp(2),dp(2),dp(2),dp(3));row.addView(b,p);b.setOnClickListener(v->action.run());}
    private void addBottomKey(LinearLayout row,String label,Runnable action,float weight){Button b=key(label,specialBg,keyFg,15);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(50),weight);p.setMargins(dp(2),dp(3),dp(2),dp(3));row.addView(b,p);b.setOnClickListener(v->action.run());}
    private void buildLetters(){
        for(int r=0;r<3;r++){
            LinearLayout line=row(); String letters=SI_KEYS[r];
            if(r==2) addSpecial(line,"⇧",48,()->{shifted=!shifted;buildKeyboard();});
            for(int i=0;i<letters.length();i++){
                final int rr=r,ii=i; String label;
                if(sinhala){String[] pair=SI[r][i].split("\\|");label=shifted?pair[1]:pair[0];}
                else label=String.valueOf(letters.charAt(i));
                Button b=key(label,keyBg,keyFg,sinhala?20:23);
                LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(keyHeight),1);p.setMargins(dp(3),dp(3),dp(3),dp(3));line.addView(b,p);
                b.setOnClickListener(v->{if(sinhala){String[] pair=SI[rr][ii].split("\\|");handleSinhala(pair[shifted?1:0]);}else{String value=String.valueOf(letters.charAt(ii));insert(shifted?value.toUpperCase(Locale.ROOT):value);}if(shifted){shifted=false;buildKeyboard();}});
            }
            if(r==2) addSpecial(line,"⌫",58,()->backspace());
            root.addView(line);
        }
    }
    private void buildSymbols(){String[][] rows={{"1","2","3","4","5","6","7","8","9","0"},{"@","#","$","%","&","-","+","(",")","/"},{"*","\"","'",":",";","!","?",",",".","="}};for(String[] rr:rows){LinearLayout l=row();for(String s:rr){Button b=key(s,keyBg,keyFg,18);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(keyHeight),1);p.setMargins(2,3,2,3);l.addView(b,p);b.setOnClickListener(v->insert(s));}root.addView(l);}LinearLayout l=row();addSpecial(l,"ABC",70,()->{symbols=false;buildKeyboard();});addSpecial(l,"⌫",58,()->backspace());root.addView(l);}
    private void addNumberRow(){LinearLayout l=row();for(String n:new String[]{"1","2","3","4","5","6","7","8","9","0"}){Button b=key(n,specialBg,keyFg,19);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(36),1);p.setMargins(dp(2),dp(2),dp(2),dp(3));l.addView(b,p);b.setOnClickListener(v->insert(n));}root.addView(l);}
    private void handleSinhala(String s){
        // Pre-base dependent vowel signs are held until the next base consonant, then committed in Unicode order.
        if(s.equals("ැ")||s.equals("ෑ")||s.equals("ෙ")){pendingMark=s;return;}
        if(s.equals("්‍ය")){insert("්\u200dය");return;}
        if(s.equals("ළු")){insert("ළු");return;}
        if(!pendingMark.isEmpty()){String mark=pendingMark;pendingMark="";insert(s+mark);return;}
        insert(s);
    }
    private void insert(String s){InputConnection ic=getCurrentInputConnection();if(ic!=null)ic.commitText(s,1);}
    private void backspace(){InputConnection ic=getCurrentInputConnection();if(ic==null)return;if(!pendingMark.isEmpty()){pendingMark="";return;}ic.deleteSurroundingText(1,0);}
    private void pasteClipboard(){try{ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);if(cm!=null&&cm.hasPrimaryClip()&&cm.getPrimaryClip().getItemCount()>0){CharSequence t=cm.getPrimaryClip().getItemAt(0).coerceToText(this);if(t!=null)insert(t.toString());}}catch(Exception e){Toast.makeText(this,"Clipboard unavailable",Toast.LENGTH_SHORT).show();}}
    private void openLeads(){String site=getSharedPreferences("ins_keyboard",MODE_PRIVATE).getString("app_url","");if(TextUtils.isEmpty(site)){Toast.makeText(this,"Settings තුළ Website URL එක Save කරන්න",Toast.LENGTH_LONG).show();openSettings();return;}String phone="";try{ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);if(cm!=null&&cm.hasPrimaryClip()&&cm.getPrimaryClip().getItemCount()>0){CharSequence c=cm.getPrimaryClip().getItemAt(0).coerceToText(this);if(c!=null){String raw=c.toString();java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?:\\+?94|0)?\\s*7[0-9][\\s-]?[0-9]{3}[\\s-]?[0-9]{4}").matcher(raw);if(m.find())phone=m.group().replaceAll("[^0-9+]","");}}}catch(Exception ignored){}try{Uri.Builder u=Uri.parse(site).buildUpon();if(!phone.isEmpty())u.appendQueryParameter("phone",phone);u.appendQueryParameter("ins_keyboard","1");Intent i=new Intent(Intent.ACTION_VIEW,u.build());i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);}catch(Exception e){Toast.makeText(this,"INS website could not open",Toast.LENGTH_SHORT).show();}}
    private void openSettings(){Intent i=new Intent(this,SettingsActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER);return l;}
    private Button key(String text,int color,int fg,int size){Button b=new Button(this);b.setText(text);b.setTextColor(fg);b.setTextSize(size);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.NORMAL);b.setPadding(0,0,0,0);b.setMinWidth(0);b.setMinimumWidth(0);b.setMinHeight(0);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));return b;}
    private void addTool(LinearLayout row,String label,Runnable action){Button b=key(label,specialBg,keyFg,label.length()>3?12:18);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);p.setMargins(dp(2),dp(2),dp(2),dp(3));row.addView(b,p);b.setOnClickListener(v->action.run());}
    private void addSpecial(LinearLayout row,String label,int width,Runnable action){Button b=key(label,specialBg,keyFg,17);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(width),dp(keyHeight));p.setMargins(dp(2),dp(3),dp(2),dp(3));row.addView(b,p);b.setOnClickListener(v->action.run());}
}
