package com.ins.leadskeyboard;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.provider.Settings;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.graphics.Color;

public class SettingsActivity extends Activity {
    private SharedPreferences prefs;
    private EditText url;
    private int red = Color.rgb(180,35,47);
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("ins_keyboard", MODE_PRIVATE);
        LinearLayout page = new LinearLayout(this); page.setOrientation(1); page.setPadding(24,28,24,24); page.setBackgroundColor(0xfff4f5f7);
        TextView title = new TextView(this); title.setText("INS KEYBOARD"); title.setTextSize(25); title.setTextColor(red); title.setTypeface(null,1); page.addView(title);
        TextView sub = new TextView(this); sub.setText("Professional Sinhala Wijesekara + English keyboard"); sub.setTextSize(14); sub.setTextColor(0xff566174); sub.setPadding(0,4,0,20); page.addView(sub);
        TextView label = new TextView(this); label.setText("INS Lead Management Website URL"); label.setTextColor(0xff202938); label.setTextSize(14); page.addView(label);
        url = new EditText(this); url.setSingleLine(true); url.setHint("https://your-ins-leads-site.com"); url.setText(prefs.getString("app_url", "")); page.addView(url);
        Button save = action("Save Website URL"); save.setOnClickListener(v -> { String s=url.getText().toString().trim(); if(!s.startsWith("https://")){url.setError("HTTPS URL එකක් ඇතුළත් කරන්න");return;} prefs.edit().putString("app_url",s).apply(); Toast.makeText(this,"Website URL saved",Toast.LENGTH_SHORT).show(); }); page.addView(save);
        TextView themeLabel = new TextView(this); themeLabel.setText("Keyboard appearance"); themeLabel.setTextSize(16); themeLabel.setTextColor(0xff202938); themeLabel.setPadding(0,20,0,4); page.addView(themeLabel);
        RadioGroup themes = new RadioGroup(this); themes.setOrientation(RadioGroup.HORIZONTAL);
        RadioButton dark = new RadioButton(this); dark.setText("Dark"); dark.setId(1); themes.addView(dark);
        RadioButton light = new RadioButton(this); light.setText("Light"); light.setId(2); themes.addView(light);
        themes.check(prefs.getBoolean("dark",true)?1:2); themes.setOnCheckedChangeListener((g,id)->prefs.edit().putBoolean("dark",id==1).apply()); page.addView(themes);
        TextView heightLabel = new TextView(this); heightLabel.setText("Keyboard height"); heightLabel.setTextSize(16); heightLabel.setTextColor(0xff202938); heightLabel.setPadding(0,16,0,0); page.addView(heightLabel);
        SeekBar height = new SeekBar(this); height.setMax(2); height.setProgress(prefs.getInt("height",1)); height.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean u){if(u)prefs.edit().putInt("height",p).apply();}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}}); page.addView(height);
        TextView hint = new TextView(this); hint.setText("Height: Compact  •  Standard  •  Tall"); hint.setTextColor(0xff687386); page.addView(hint);
        Button enable = action("1. Enable INS Keyboard"); enable.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))); page.addView(enable);
        Button select = action("2. Select INS Keyboard"); select.setOnClickListener(v->((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showInputMethodPicker()); page.addView(select);
        TextView privacy = new TextView(this); privacy.setText("Privacy: keystrokes are not collected or sent to INS. Clipboard content is read only when you tap INS LEADS, to find a copied phone number."); privacy.setTextSize(12); privacy.setTextColor(0xff687386); privacy.setPadding(0,20,0,0); page.addView(privacy);
        setContentView(page);
    }
    private Button action(String text){Button b=new Button(this);b.setText(text);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(red));return b;}
}
