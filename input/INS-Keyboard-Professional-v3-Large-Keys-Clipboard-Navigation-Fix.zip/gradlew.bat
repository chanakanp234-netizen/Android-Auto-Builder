@echo off
echo Use gradlew on Linux or GitHub Actions.
exit /b 1
