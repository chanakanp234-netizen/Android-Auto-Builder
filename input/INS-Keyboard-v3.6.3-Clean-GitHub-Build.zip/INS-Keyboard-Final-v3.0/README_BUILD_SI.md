INS Keyboard v3.6.3 - Clean GitHub Build

1. Extract this ZIP.
2. Upload the CONTENTS of the INS-Keyboard-Final-v3.0 folder to the root of your own GitHub repository (including the hidden .github folder).
3. Ensure the repository default branch is main or master.
4. Open GitHub Actions. The workflow "Build INS Keyboard APK" runs automatically after push. You can also select it and choose Run workflow.
5. When complete, open the successful run and download the artifact named INS-Keyboard-v3.6.3-debug-apk.

This workflow installs Gradle 8.9 directly and does not depend on gradlew or gradle-wrapper.jar.
The floating bubble service remains in the project. Clipboard reading is attempted from a foreground Activity after the user taps the floating button; Android may still limit clipboard access depending on OS version and device policy.

Do not uninstall the currently working app until the new APK has been installed and tested.
