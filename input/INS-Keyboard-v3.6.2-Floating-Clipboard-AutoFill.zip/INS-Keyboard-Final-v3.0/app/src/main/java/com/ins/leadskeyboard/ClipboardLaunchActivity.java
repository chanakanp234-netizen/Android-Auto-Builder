package com.ins.leadskeyboard;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Reads clipboard only after the user explicitly taps the floating INS button.
 * The foreground Activity waits until it has window focus before reading.
 */
public class ClipboardLaunchActivity extends Activity {
    public static final String EXTRA_SITE = "site_url";
    private static final Pattern LK_MOBILE = Pattern.compile("(?:\+?94|0)?[\s().-]*7(?:[\s().-]*[0-9]){8}");
    private boolean handled = false;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        String site = getIntent().getStringExtra(EXTRA_SITE);
        if (TextUtils.isEmpty(site) || !site.startsWith("https://")) {
            finish();
            return;
        }
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (!hasFocus || handled) return;
        handled = true;
        // At this point this app's Activity is foreground and focused, so Android
        // clipboard privacy rules permit a user-initiated clipboard read.
        String site = getIntent().getStringExtra(EXTRA_SITE);
        String phone = readAndNormalizePhone();
        Uri.Builder url = Uri.parse(site).buildUpon().appendQueryParameter("ins_keyboard", "1");
        if (!TextUtils.isEmpty(phone)) url.appendQueryParameter("phone", phone);
        try {
            Intent browser = new Intent(Intent.ACTION_VIEW, url.build());
            browser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(browser);
        } catch (Exception e) {
            Toast.makeText(this, "INS Leads website එක විවෘත කළ නොහැක", Toast.LENGTH_SHORT).show();
        }
        finish();
    }

    private String readAndNormalizePhone() {
        try {
            ClipboardManager manager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (manager == null || !manager.hasPrimaryClip()) return "";
            ClipData clip = manager.getPrimaryClip();
            if (clip == null || clip.getItemCount() == 0) return "";
            CharSequence value = clip.getItemAt(0).coerceToText(this);
            if (value == null) return "";
            Matcher matcher = LK_MOBILE.matcher(value.toString());
            if (!matcher.find()) return "";
            String digits = matcher.group().replaceAll("[^0-9]", "");
            if (digits.startsWith("0094") && digits.length() == 13) digits = "0" + digits.substring(4);
            else if (digits.startsWith("94") && digits.length() == 11) digits = "0" + digits.substring(2);
            else if (digits.length() == 9) digits = "0" + digits;
            if (digits.length() == 10 && digits.startsWith("07")) return digits;
        } catch (Exception ignored) { }
        return "";
    }
}
